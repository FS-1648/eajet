"""
智能电力系统故障预测应用程序主程序入口
"""
import os
import sys
import json
import asyncio
import logging
from typing import Dict, Any, List, Optional
from datetime import datetime

import uvicorn
from fastapi import FastAPI, HTTPException, Depends, Query, Path, BackgroundTasks
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel

from src.data_acquisition.core.data_source_manager import DataSourceManager
from src.data_acquisition.core.data_source import DataSourceConfig
from src.data_preprocessing.core.preprocessing_pipeline import PreprocessingPipeline
from src.data_preprocessing.core.data_classifier import ClassificationConfig
from src.fault_probability.core.probability_model import ProbabilityModelConfig
from src.aging_prediction.core.aging_curve_model import AgingCurveConfig
from src.model_training.core.model_trainer import TrainingConfig

# 配置日志
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.StreamHandler(sys.stdout)
    ]
)

logger = logging.getLogger("power_system_app")

# 创建FastAPI应用
app = FastAPI(
    title="电力系统故障预测应用程序",
    description="基于多源数据分析的电力系统故障预测应用程序",
    version="1.0.0"
)

# 添加CORS中间件
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# 全局变量
DATA_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
CONFIG_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "config")
MODEL_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "models")

# 确保目录存在
os.makedirs(DATA_DIR, exist_ok=True)
os.makedirs(CONFIG_DIR, exist_ok=True)
os.makedirs(MODEL_DIR, exist_ok=True)

# 全局管理器实例
data_source_manager = None
preprocessing_pipeline = None
probability_models = {}
aging_models = {}
model_trainer = None

# 模型配置
app_config = {
    "data_sources": {},
    "preprocessing": {},
    "probability_models": {},
    "aging_models": {},
    "training": {}
}

# 数据模型
class SystemStatus(BaseModel):
    """系统状态"""
    status: str
    version: str
    uptime: float
    data_sources: int
    preprocessing_processors: int
    probability_models: int
    aging_models: int
    trained_models: int
    last_update: str

class ConfigUpdate(BaseModel):
    """配置更新"""
    config_type: str
    config_id: str
    config_data: Dict[str, Any]

class TrainingRequest(BaseModel):
    """模型训练请求"""
    data_source_id: str
    target_column: str
    model_type: str
    model_params: Optional[Dict[str, Any]] = None
    feature_columns: Optional[List[str]] = None

class PredictionRequest(BaseModel):
    """预测请求"""
    device_id: str
    data_source_id: str
    model_id: str
    days_ahead: int = 7

# 依赖注入函数
async def get_data_source_manager():
    """获取数据源管理器"""
    global data_source_manager
    if data_source_manager is None:
        from src.data_acquisition.core.data_source_manager import DataSourceManager
        data_source_manager = DataSourceManager()
        await load_data_sources()
    return data_source_manager

async def get_preprocessing_pipeline():
    """获取预处理流水线"""
    global preprocessing_pipeline
    if preprocessing_pipeline is None:
        from src.data_preprocessing.core.preprocessing_pipeline import PreprocessingPipeline
        preprocessing_pipeline = PreprocessingPipeline()
        preprocessing_pipeline.discover_processor_types()
        await load_preprocessing_pipeline()
    return preprocessing_pipeline

async def get_probability_model(model_id: str):
    """获取概率模型"""
    global probability_models
    if model_id not in probability_models:
        await load_probability_models()
    return probability_models.get(model_id)

async def get_aging_model(model_id: str):
    """获取老化曲线模型"""
    global aging_models
    if model_id not in aging_models:
        await load_aging_models()
    return aging_models.get(model_id)

async def get_model_trainer():
    """获取模型训练器"""
    global model_trainer
    if model_trainer is None:
        from src.model_training.trainers.universal_trainer import UniversalModelTrainer
        trainer_config = TrainingConfig(
            trainer_id="universal_trainer",
            trainer_type="universal",
            name="通用模型训练器",
            parameters={
                "auto_tune": True,
                "cv_folds": 5,
                "feature_selection": True
            }
        )
        model_trainer = UniversalModelTrainer(trainer_config)
        await load_trained_models()
    return model_trainer

# 启动时加载配置
async def load_config():
    """加载应用配置"""
    global app_config
    config_path = os.path.join(CONFIG_DIR, "app_config.json")
    if os.path.exists(config_path):
        try:
            with open(config_path, "r", encoding="utf-8") as f:
                app_config = json.load(f)
            logger.info("成功加载应用配置")
        except Exception as e:
            logger.error(f"加载应用配置失败: {e}")
    else:
        logger.info("应用配置文件不存在，使用默认配置")
        # 保存默认配置
        await save_config()

async def save_config():
    """保存应用配置"""
    global app_config
    config_path = os.path.join(CONFIG_DIR, "app_config.json")
    try:
        with open(config_path, "w", encoding="utf-8") as f:
            json.dump(app_config, f, indent=2, ensure_ascii=False)
        logger.info("成功保存应用配置")
    except Exception as e:
        logger.error(f"保存应用配置失败: {e}")

async def load_data_sources():
    """加载数据源配置"""
    global data_source_manager, app_config
    try:
        for source_id, source_config in app_config.get("data_sources", {}).items():
            config = DataSourceConfig(**source_config)
            await data_source_manager.add_data_source(config)
        logger.info(f"成功加载 {len(app_config.get('data_sources', {}))} 个数据源")
    except Exception as e:
        logger.error(f"加载数据源失败: {e}")

async def load_preprocessing_pipeline():
    """加载预处理流水线"""
    global preprocessing_pipeline, app_config
    try:
        pipeline_path = os.path.join(MODEL_DIR, "preprocessing_pipeline")
        if os.path.exists(pipeline_path):
            success = await preprocessing_pipeline.load_pipeline_state(pipeline_path)
            if success:
                logger.info("成功加载预处理流水线")
            else:
                logger.warning("加载预处理流水线失败，使用默认流水线")
        else:
            logger.info("预处理流水线不存在，使用默认流水线")
    except Exception as e:
        logger.error(f"加载预处理流水线失败: {e}")

async def load_probability_models():
    """加载概率模型"""
    global probability_models, app_config
    try:
        for model_id, model_config in app_config.get("probability_models", {}).items():
            config = ProbabilityModelConfig(**model_config)
            
            if config.model_type == "multi_factor":
                from src.fault_probability.models.multi_factor_model import MultiFactorProbabilityModel
                model = MultiFactorProbabilityModel(config)
                
                # 加载模型状态
                model_path = os.path.join(MODEL_DIR, f"probability_{model_id}")
                if os.path.exists(model_path):
                    success = await model.load_model(model_path)
                    if success:
                        probability_models[model_id] = model
                        logger.info(f"成功加载概率模型: {model_id}")
                    else:
                        logger.warning(f"加载概率模型失败: {model_id}")
            else:
                logger.warning(f"不支持的概率模型类型: {config.model_type}")
        
        logger.info(f"成功加载 {len(probability_models)} 个概率模型")
    except Exception as e:
        logger.error(f"加载概率模型失败: {e}")

async def load_aging_models():
    """加载老化曲线模型"""
    global aging_models, app_config
    try:
        for model_id, model_config in app_config.get("aging_models", {}).items():
            config = AgingCurveConfig(**model_config)
            
            if config.model_type == "health_index":
                from src.aging_prediction.models.health_index_model import HealthIndexAgingModel
                model = HealthIndexAgingModel(config)
                
                # 加载模型状态
                model_path = os.path.join(MODEL_DIR, f"aging_{model_id}")
                if os.path.exists(model_path):
                    success = await model.load_model(model_path)
                    if success:
                        aging_models[model_id] = model
                        logger.info(f"成功加载老化曲线模型: {model_id}")
                    else:
                        logger.warning(f"加载老化曲线模型失败: {model_id}")
            else:
                logger.warning(f"不支持的老化曲线模型类型: {config.model_type}")
        
        logger.info(f"成功加载 {len(aging_models)} 个老化曲线模型")
    except Exception as e:
        logger.error(f"加载老化曲线模型失败: {e}")

async def load_trained_models():
    """加载训练好的模型"""
    global model_trainer
    try:
        trained_models_dir = os.path.join(MODEL_DIR, "trained_models")
        if os.path.exists(trained_models_dir):
            model_dirs = [d for d in os.listdir(trained_models_dir) if os.path.isdir(os.path.join(trained_models_dir, d))]
            
            for model_id in model_dirs:
                model_path = os.path.join(trained_models_dir, model_id)
                success = await model_trainer.load_model(model_id, model_path)
                if success:
                    logger.info(f"成功加载训练模型: {model_id}")
                else:
                    logger.warning(f"加载训练模型失败: {model_id}")
            
            logger.info(f"成功加载 {len(model_dirs)} 个训练模型")
        else:
            logger.info("训练模型目录不存在")
    except Exception as e:
        logger.error(f"加载训练模型失败: {e}")

# 路由定义
@app.get("/", tags=["系统"])
async def root():
    """系统根路径"""
    return {
        "name": "电力系统故障预测应用程序",
        "version": "1.0.0",
        "description": "基于多源数据分析的电力系统故障预测应用程序",
        "status": "运行中"
    }

@app.get("/status", response_model=SystemStatus, tags=["系统"])
async def get_system_status(
    data_source_manager=Depends(get_data_source_manager),
    preprocessing_pipeline=Depends(get_preprocessing_pipeline),
    model_trainer=Depends(get_model_trainer)
):
    """获取系统状态"""
    # 计算系统运行时间
    start_time = datetime.fromtimestamp(os.path.getctime(__file__))
    uptime = (datetime.now() - start_time).total_seconds()
    
    # 获取各模块状态
    data_sources = len(await data_source_manager.get_all_data_sources())
    preprocessing_processors = len(preprocessing_pipeline.processors)
    
    return SystemStatus(
        status="运行中",
        version="1.0.0",
        uptime=uptime,
        data_sources=data_sources,
        preprocessing_processors=preprocessing_processors,
        probability_models=len(probability_models),
        aging_models=len(aging_models),
        trained_models=len(model_trainer.models),
        last_update=datetime.now().isoformat()
    )

@app.post("/config/update", tags=["配置"])
async def update_config(
    config_update: ConfigUpdate,
    background_tasks: BackgroundTasks
):
    """更新系统配置"""
    global app_config
    
    try:
        # 更新配置
        if config_update.config_type not in app_config:
            app_config[config_update.config_type] = {}
        
        app_config[config_update.config_type][config_update.config_id] = config_update.config_data
        
        # 保存配置
        background_tasks.add_task(save_config)
        
        return {
            "success": True,
            "message": f"成功更新配置: {config_update.config_type}/{config_update.config_id}"
        }
    except Exception as e:
        logger.error(f"更新配置失败: {e}")
        raise HTTPException(status_code=500, detail=f"更新配置失败: {str(e)}")

@app.get("/config", tags=["配置"])
async def get_config():
    """获取系统配置"""
    return app_config

# 数据源管理API
@app.get("/api/data_sources", tags=["数据源"])
async def get_all_data_sources(
    data_source_manager=Depends(get_data_source_manager)
):
    """获取所有数据源"""
    sources = await data_source_manager.get_all_data_sources()
    return {
        "success": True,
        "data_sources": [source.dict() for source in sources]
    }

@app.post("/api/data_sources", tags=["数据源"])
async def add_data_source(
    config: DataSourceConfig,
    background_tasks: BackgroundTasks,
    data_source_manager=Depends(get_data_source_manager)
):
    """添加数据源"""
    try:
        source_id = await data_source_manager.add_data_source(config)
        
        # 更新配置
        app_config["data_sources"][source_id] = config.dict()
        background_tasks.add_task(save_config)
        
        return {
            "success": True,
            "message": f"成功添加数据源: {source_id}",
            "source_id": source_id
        }
    except Exception as e:
        logger.error(f"添加数据源失败: {e}")
        raise HTTPException(status_code=500, detail=f"添加数据源失败: {str(e)}")

@app.get("/api/data_sources/{source_id}/data", tags=["数据源"])
async def collect_data(
    source_id: str,
    start_time: Optional[datetime] = None,
    end_time: Optional[datetime] = None,
    data_source_manager=Depends(get_data_source_manager)
):
    """从数据源采集数据"""
    try:
        data_points = await data_source_manager.collect_data_from_source(
            source_id=source_id,
            start_time=start_time,
            end_time=end_time
        )
        
        return {
            "success": True,
            "message": f"成功从数据源 {source_id} 采集数据",
            "data_points": [dp.dict() for dp in data_points]
        }
    except Exception as e:
        logger.error(f"从数据源采集数据失败: {e}")
        raise HTTPException(status_code=500, detail=f"从数据源采集数据失败: {str(e)}")

# 预处理流水线API
@app.get("/api/preprocessing/pipeline", tags=["预处理"])
async def get_preprocessing_pipeline_info(
    preprocessing_pipeline=Depends(get_preprocessing_pipeline)
):
    """获取预处理流水线信息"""
    pipeline_info = preprocessing_pipeline.get_pipeline_info()
    return {
        "success": True,
        "pipeline": pipeline_info
    }

@app.post("/api/preprocessing/process", tags=["预处理"])
async def process_data(
    data_source_id: str,
    preprocessing_pipeline=Depends(get_preprocessing_pipeline),
    data_source_manager=Depends(get_data_source_manager)
):
    """处理数据"""
    try:
        # 从数据源获取数据
        data_points = await data_source_manager.collect_data_from_source(data_source_id)
        
        if not data_points:
            return {
                "success": False,
                "message": f"数据源 {data_source_id} 没有数据"
            }
        
        # 转换为DataFrame
        import pandas as pd
        data = pd.DataFrame([dp.dict() for dp in data_points])
        
        # 处理数据
        processed_data, results = await preprocessing_pipeline.process_data(data)
        
        # 保存处理后的数据
        output_path = os.path.join(DATA_DIR, f"processed_{data_source_id}.csv")
        processed_data.to_csv(output_path, index=False)
        
        return {
            "success": True,
            "message": f"成功处理数据源 {data_source_id} 的数据",
            "results": {k: v.dict() for k, v in results.items()},
            "output_path": output_path,
            "row_count": len(processed_data)
        }
    except Exception as e:
        logger.error(f"处理数据失败: {e}")
        raise HTTPException(status_code=500, detail=f"处理数据失败: {str(e)}")

# 概率模型API
@app.get("/api/probability/models", tags=["概率模型"])
async def get_probability_models():
    """获取所有概率模型"""
    global probability_models
    return {
        "success": True,
        "models": {
            model_id: model.get_model_info() 
            for model_id, model in probability_models.items()
        }
    }

@app.post("/api/probability/calculate", tags=["概率模型"])
async def calculate_probability(
    model_id: str,
    data_source_id: str,
    data_source_manager=Depends(get_data_source_manager),
    preprocessing_pipeline=Depends(get_preprocessing_pipeline)
):
    """计算故障概率"""
    try:
        # 获取概率模型
        model = await get_probability_model(model_id)
        if model is None:
            raise HTTPException(status_code=404, detail=f"概率模型 {model_id} 不存在")
        
        # 从数据源获取数据
        data_points = await data_source_manager.collect_data_from_source(data_source_id)
        
        if not data_points:
            return {
                "success": False,
                "message": f"数据源 {data_source_id} 没有数据"
            }
        
        # 转换为DataFrame
        import pandas as pd
        data = pd.DataFrame([dp.dict() for dp in data_points])
        
        # 预处理数据
        processed_data, _ = await preprocessing_pipeline.process_data(data)
        
        # 计算概率
        result = await model.calculate_probability(processed_data)
        
        return {
            "success": True,
            "message": f"成功计算故障概率",
            "result": result.dict()
        }
    except Exception as e:
        logger.error(f"计算故障概率失败: {e}")
        raise HTTPException(status_code=500, detail=f"计算故障概率失败: {str(e)}")

# 老化曲线模型API
@app.get("/api/aging/models", tags=["老化曲线"])
async def get_aging_models():
    """获取所有老化曲线模型"""
    global aging_models
    return {
        "success": True,
        "models": {
            model_id: model.get_model_info() 
            for model_id, model in aging_models.items()
        }
    }

@app.post("/api/aging/predict", tags=["老化曲线"])
async def predict_aging(
    prediction_request: PredictionRequest,
    data_source_manager=Depends(get_data_source_manager),
    preprocessing_pipeline=Depends(get_preprocessing_pipeline)
):
    """预测设备老化"""
    try:
        # 获取老化曲线模型
        model = await get_aging_model(prediction_request.model_id)
        if model is None:
            raise HTTPException(status_code=404, detail=f"老化曲线模型 {prediction_request.model_id} 不存在")
        
        # 从数据源获取数据
        data_points = await data_source_manager.collect_data_from_source(
            prediction_request.data_source_id,
            device_ids=[prediction_request.device_id]
        )
        
        if not data_points:
            return {
                "success": False,
                "message": f"数据源 {prediction_request.data_source_id} 没有设备 {prediction_request.device_id} 的数据"
            }
        
        # 转换为DataFrame
        import pandas as pd
        data = pd.DataFrame([dp.dict() for dp in data_points])
        
        # 预处理数据
        processed_data, _ = await preprocessing_pipeline.process_data(data)
        
        # 预测老化
        result = await model.predict_health_index(
            processed_data,
            prediction_request.device_id,
            prediction_request.days_ahead
        )
        
        return {
            "success": True,
            "message": f"成功预测设备 {prediction_request.device_id} 的老化曲线",
            "result": result.dict()
        }
    except Exception as e:
        logger.error(f"预测设备老化失败: {e}")
        raise HTTPException(status_code=500, detail=f"预测设备老化失败: {str(e)}")

# 模型训练API
@app.get("/api/training/models", tags=["模型训练"])
async def get_trained_models(
    model_trainer=Depends(get_model_trainer)
):
    """获取所有训练好的模型"""
    return {
        "success": True,
        "models": {
            model_id: model_trainer.get_model_info(model_id)
            for model_id in model_trainer.models
        }
    }

@app.post("/api/training/train", tags=["模型训练"])
async def train_model(
    training_request: TrainingRequest,
    background_tasks: BackgroundTasks,
    model_trainer=Depends(get_model_trainer),
    data_source_manager=Depends(get_data_source_manager),
    preprocessing_pipeline=Depends(get_preprocessing_pipeline)
):
    """训练模型"""
    try:
        # 从数据源获取数据
        data_points = await data_source_manager.collect_data_from_source(
            training_request.data_source_id
        )
        
        if not data_points:
            return {
                "success": False,
                "message": f"数据源 {training_request.data_source_id} 没有数据"
            }
        
        # 转换为DataFrame
        import pandas as pd
        data = pd.DataFrame([dp.dict() for dp in data_points])
        
        # 预处理数据
        processed_data, _ = await preprocessing_pipeline.process_data(data)
        
        # 检查目标列是否存在
        if training_request.target_column not in processed_data.columns:
            return {
                "success": False,
                "message": f"目标列 {training_request.target_column} 不存在"
            }
        
        # 训练模型
        result = await model_trainer.train_model(
            processed_data,
            training_request.target_column,
            training_request.model_type,
            training_request.model_params
        )
        
        if result.success:
            # 保存模型
            model_path = os.path.join(MODEL_DIR, "trained_models")
            os.makedirs(model_path, exist_ok=True)
            background_tasks.add_task(model_trainer.save_model, result.model_id, model_path)
        
        return {
            "success": result.success,
            "message": result.message,
            "result": result.dict()
        }
    except Exception as e:
        logger.error(f"训练模型失败: {e}")
        raise HTTPException(status_code=500, detail=f"训练模型失败: {str(e)}")

@app.post("/api/training/evaluate", tags=["模型训练"])
async def evaluate_model(
    model_id: str,
    data_source_id: str,
    target_column: str,
    model_trainer=Depends(get_model_trainer),
    data_source_manager=Depends(get_data_source_manager),
    preprocessing_pipeline=Depends(get_preprocessing_pipeline)
):
    """评估模型"""
    try:
        # 从数据源获取数据
        data_points = await data_source_manager.collect_data_from_source(
            data_source_id
        )
        
        if not data_points:
            return {
                "success": False,
                "message": f"数据源 {data_source_id} 没有数据"
            }
        
        # 转换为DataFrame
        import pandas as pd
        data = pd.DataFrame([dp.dict() for dp in data_points])
        
        # 预处理数据
        processed_data, _ = await preprocessing_pipeline.process_data(data)
        
        # 评估模型
        result = await model_trainer.evaluate_model(
            model_id,
            processed_data,
            target_column
        )
        
        return result
    except Exception as e:
        logger.error(f"评估模型失败: {e}")
        raise HTTPException(status_code=500, detail=f"评估模型失败: {str(e)}")

# 启动时加载配置
@app.on_event("startup")
async def startup_event():
    """应用启动时执行"""
    await load_config()

# 主函数
if __name__ == "__main__":
    # 启动FastAPI应用
    uvicorn.run(app, host="0.0.0.0", port=8000)
