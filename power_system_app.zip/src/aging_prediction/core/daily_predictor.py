"""
每日故障概率预测器 - 结合设备老化曲线和实时数据预测每日故障概率
"""
import os
import json
import pickle
from typing import Any, Dict, List, Optional, Union, Tuple
from datetime import datetime, timedelta

import numpy as np
import pandas as pd
from loguru import logger

from src.aging_prediction.core.aging_curve_model import AgingCurveModel, AgingCurvePrediction


class DailyPredictor:
    """每日故障概率预测器"""
    
    def __init__(self, aging_model: AgingCurveModel):
        """
        初始化每日故障概率预测器
        
        Args:
            aging_model: 老化曲线模型
        """
        self.aging_model = aging_model
        self.device_predictions = {}  # 设备ID -> 最新预测结果
        self.prediction_history = {}  # 设备ID -> {日期 -> 预测结果}
        self.alert_thresholds = {
            "high": 0.7,    # 高风险阈值
            "medium": 0.4,  # 中风险阈值
            "low": 0.2      # 低风险阈值
        }
    
    async def predict_daily_probability(self, 
                                       current_data: pd.DataFrame,
                                       device_id: str,
                                       days_ahead: int = 7) -> Dict[str, Any]:
        """
        预测设备未来几天的故障概率
        
        Args:
            current_data: 当前数据DataFrame
            device_id: 设备ID
            days_ahead: 预测未来天数
            
        Returns:
            Dict[str, Any]: 预测结果
        """
        try:
            # 使用老化曲线模型预测健康指数和故障概率
            prediction = await self.aging_model.predict_health_index(
                current_data=current_data,
                device_id=device_id,
                days_ahead=days_ahead
            )
            
            if not prediction.success:
                return {
                    "success": False,
                    "message": prediction.message,
                    "device_id": device_id
                }
            
            # 保存预测结果
            self.device_predictions[device_id] = prediction
            
            # 更新预测历史
            if device_id not in self.prediction_history:
                self.prediction_history[device_id] = {}
            
            current_date = datetime.now().strftime("%Y-%m-%d")
            self.prediction_history[device_id][current_date] = {
                "current_health_index": prediction.current_health_index,
                "predicted_health_indices": prediction.predicted_health_indices,
                "failure_probability": prediction.failure_probability
            }
            
            # 生成风险等级
            risk_levels = {}
            for date, prob in prediction.failure_probability.items():
                if prob >= self.alert_thresholds["high"]:
                    risk_levels[date] = "high"
                elif prob >= self.alert_thresholds["medium"]:
                    risk_levels[date] = "medium"
                elif prob >= self.alert_thresholds["low"]:
                    risk_levels[date] = "low"
                else:
                    risk_levels[date] = "normal"
            
            # 生成预测趋势
            trend = self._calculate_trend(prediction.failure_probability)
            
            # 生成预测结果
            result = {
                "success": True,
                "message": "Successfully predicted daily failure probability",
                "device_id": device_id,
                "current_date": current_date,
                "current_health_index": prediction.current_health_index,
                "daily_predictions": [
                    {
                        "date": date,
                        "health_index": prediction.predicted_health_indices.get(date, 0.0),
                        "failure_probability": prediction.failure_probability.get(date, 0.0),
                        "risk_level": risk_levels.get(date, "unknown"),
                        "confidence_interval": prediction.confidence_interval.get(date, (0.0, 0.0)) if prediction.confidence_interval else None
                    }
                    for date in sorted(prediction.failure_probability.keys())
                ],
                "trend": trend,
                "estimated_remaining_life": prediction.estimated_remaining_life,
                "metadata": prediction.metadata
            }
            
            return result
        
        except Exception as e:
            logger.error(f"Error predicting daily failure probability: {e}")
            return {
                "success": False,
                "message": f"Error predicting daily failure probability: {str(e)}",
                "device_id": device_id
            }
    
    def _calculate_trend(self, probabilities: Dict[str, float]) -> str:
        """
        计算故障概率趋势
        
        Args:
            probabilities: 日期 -> 故障概率的字典
            
        Returns:
            str: 趋势描述 ("increasing", "decreasing", "stable")
        """
        if not probabilities:
            return "unknown"
        
        # 按日期排序
        sorted_dates = sorted(probabilities.keys())
        if len(sorted_dates) < 2:
            return "stable"
        
        # 计算线性回归斜率
        x = np.arange(len(sorted_dates))
        y = np.array([probabilities[date] for date in sorted_dates])
        
        slope, _ = np.polyfit(x, y, 1)
        
        # 根据斜率判断趋势
        if slope > 0.01:
            return "increasing"
        elif slope < -0.01:
            return "decreasing"
        else:
            return "stable"
    
    async def get_device_prediction_history(self, device_id: str, days: int = 30) -> Dict[str, Any]:
        """
        获取设备预测历史
        
        Args:
            device_id: 设备ID
            days: 历史天数
            
        Returns:
            Dict[str, Any]: 预测历史
        """
        if device_id not in self.prediction_history:
            return {
                "success": False,
                "message": f"No prediction history found for device {device_id}",
                "device_id": device_id
            }
        
        # 获取最近days天的预测历史
        end_date = datetime.now()
        start_date = end_date - timedelta(days=days)
        
        filtered_history = {}
        for date_str, prediction in self.prediction_history[device_id].items():
            date = datetime.strptime(date_str, "%Y-%m-%d")
            if start_date <= date <= end_date:
                filtered_history[date_str] = prediction
        
        return {
            "success": True,
            "message": "Successfully retrieved prediction history",
            "device_id": device_id,
            "history": filtered_history
        }
    
    async def get_all_device_current_predictions(self) -> Dict[str, Any]:
        """
        获取所有设备的当前预测结果
        
        Returns:
            Dict[str, Any]: 所有设备的预测结果
        """
        results = {}
        
        for device_id, prediction in self.device_predictions.items():
            # 提取当前日期和未来第一天的预测
            current_date = datetime.now().strftime("%Y-%m-%d")
            tomorrow = (datetime.now() + timedelta(days=1)).strftime("%Y-%m-%d")
            
            results[device_id] = {
                "current_health_index": prediction.current_health_index,
                "tomorrow_probability": prediction.failure_probability.get(tomorrow, 0.0),
                "estimated_remaining_life": prediction.estimated_remaining_life
            }
        
        return {
            "success": True,
            "message": "Successfully retrieved all device predictions",
            "predictions": results
        }
    
    def set_alert_thresholds(self, thresholds: Dict[str, float]) -> bool:
        """
        设置告警阈值
        
        Args:
            thresholds: 告警阈值字典
            
        Returns:
            bool: 是否成功设置
        """
        try:
            if "high" in thresholds:
                self.alert_thresholds["high"] = thresholds["high"]
            if "medium" in thresholds:
                self.alert_thresholds["medium"] = thresholds["medium"]
            if "low" in thresholds:
                self.alert_thresholds["low"] = thresholds["low"]
            
            return True
        except Exception as e:
            logger.error(f"Error setting alert thresholds: {e}")
            return False
    
    async def save_state(self, path: str) -> bool:
        """
        保存预测器状态
        
        Args:
            path: 保存路径
            
        Returns:
            bool: 保存是否成功
        """
        try:
            os.makedirs(path, exist_ok=True)
            
            # 保存告警阈值
            with open(os.path.join(path, "alert_thresholds.json"), "w") as f:
                json.dump(self.alert_thresholds, f, indent=2)
            
            # 保存预测历史
            with open(os.path.join(path, "prediction_history.json"), "w") as f:
                json.dump(self.prediction_history, f, indent=2, default=str)
            
            return True
        
        except Exception as e:
            logger.error(f"Error saving daily predictor state: {e}")
            return False
    
    async def load_state(self, path: str) -> bool:
        """
        加载预测器状态
        
        Args:
            path: 加载路径
            
        Returns:
            bool: 加载是否成功
        """
        try:
            # 加载告警阈值
            thresholds_path = os.path.join(path, "alert_thresholds.json")
            if os.path.exists(thresholds_path):
                with open(thresholds_path, "r") as f:
                    self.alert_thresholds = json.load(f)
            
            # 加载预测历史
            history_path = os.path.join(path, "prediction_history.json")
            if os.path.exists(history_path):
                with open(history_path, "r") as f:
                    self.prediction_history = json.load(f)
            
            return True
        
        except Exception as e:
            logger.error(f"Error loading daily predictor state: {e}")
            return False
