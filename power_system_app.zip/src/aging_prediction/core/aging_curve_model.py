"""
老化曲线模型基类定义
"""
from abc import ABC, abstractmethod
from typing import Any, Dict, List, Optional, Union, Tuple

import numpy as np
import pandas as pd
from pydantic import BaseModel
from datetime import datetime, timedelta


class AgingCurveConfig(BaseModel):
    """老化曲线模型配置基类"""
    model_id: str
    model_type: str
    name: str
    description: Optional[str] = None
    parameters: Dict[str, Any] = {}
    enabled: bool = True
    metadata: Optional[Dict[str, Any]] = None


class AgingCurvePrediction(BaseModel):
    """老化曲线预测结果基类"""
    model_id: str
    device_id: str
    success: bool
    message: Optional[str] = None
    current_health_index: float
    predicted_health_indices: Dict[str, float]  # 日期字符串 -> 健康指数
    failure_probability: Dict[str, float]  # 日期字符串 -> 故障概率
    estimated_remaining_life: Optional[int] = None  # 剩余寿命（天）
    confidence_interval: Optional[Dict[str, Tuple[float, float]]] = None  # 日期字符串 -> (下限, 上限)
    metadata: Optional[Dict[str, Any]] = None


class AgingCurveModel(ABC):
    """老化曲线模型抽象基类"""
    
    def __init__(self, config: AgingCurveConfig):
        """
        初始化老化曲线模型
        
        Args:
            config: 模型配置
        """
        self.config = config
    
    @abstractmethod
    async def fit_aging_curve(self, 
                             historical_data: pd.DataFrame, 
                             device_id: str) -> Dict[str, Any]:
        """
        拟合设备老化曲线
        
        Args:
            historical_data: 历史数据DataFrame
            device_id: 设备ID
            
        Returns:
            Dict[str, Any]: 拟合结果
        """
        pass
    
    @abstractmethod
    async def predict_health_index(self, 
                                  current_data: pd.DataFrame,
                                  device_id: str,
                                  days_ahead: int = 30) -> AgingCurvePrediction:
        """
        预测设备健康指数和故障概率
        
        Args:
            current_data: 当前数据DataFrame
            device_id: 设备ID
            days_ahead: 预测未来天数
            
        Returns:
            AgingCurvePrediction: 预测结果
        """
        pass
    
    @abstractmethod
    async def save_model(self, path: str) -> bool:
        """
        保存老化曲线模型
        
        Args:
            path: 保存路径
            
        Returns:
            bool: 保存是否成功
        """
        pass
    
    @abstractmethod
    async def load_model(self, path: str) -> bool:
        """
        加载老化曲线模型
        
        Args:
            path: 加载路径
            
        Returns:
            bool: 加载是否成功
        """
        pass
    
    @abstractmethod
    def get_model_info(self) -> Dict[str, Any]:
        """
        获取模型信息
        
        Returns:
            Dict[str, Any]: 模型信息
        """
        pass
