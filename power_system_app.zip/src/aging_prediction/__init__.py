"""
设备老化曲线与每日故障概率预测模块初始化文件
"""
from importlib.metadata import version, PackageNotFoundError

try:
    __version__ = version("power_system_fault_prediction")
except PackageNotFoundError:
    __version__ = "0.1.0-dev"

from src.aging_prediction.api.prediction_api import PredictionAPI
from src.aging_prediction.core.aging_curve_model import AgingCurveModel
from src.aging_prediction.core.daily_predictor import DailyPredictor

__all__ = ["PredictionAPI", "AgingCurveModel", "DailyPredictor"]
