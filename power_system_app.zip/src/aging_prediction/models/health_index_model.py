"""
健康指数老化曲线模型 - 基于设备历史数据建立健康指数老化曲线
"""
import os
import json
import pickle
from typing import Any, Dict, List, Optional, Union, Tuple
from datetime import datetime, timedelta

import numpy as np
import pandas as pd
from loguru import logger
from scipy.optimize import curve_fit
from sklearn.ensemble import RandomForestRegressor
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import mean_squared_error, r2_score

from src.aging_prediction.core.aging_curve_model import AgingCurveModel, AgingCurveConfig, AgingCurvePrediction


class HealthIndexAgingModel(AgingCurveModel):
    """健康指数老化曲线模型"""
    
    def __init__(self, config: AgingCurveConfig):
        """
        初始化健康指数老化曲线模型
        
        Args:
            config: 模型配置
        """
        super().__init__(config)
        
        # 获取配置参数
        self.curve_type = config.parameters.get("curve_type", "weibull")  # weibull, exponential, linear, ml
        self.time_column = config.parameters.get("time_column", "timestamp")
        self.feature_columns = config.parameters.get("feature_columns", [])
        self.health_index_column = config.parameters.get("health_index_column", None)  # 如果有现成的健康指数列
        self.failure_threshold = config.parameters.get("failure_threshold", 0.3)  # 健康指数低于此值视为故障
        self.warning_threshold = config.parameters.get("warning_threshold", 0.6)  # 健康指数低于此值发出警告
        self.confidence_level = config.parameters.get("confidence_level", 0.95)  # 置信区间水平
        self.random_state = config.parameters.get("random_state", 42)
        
        # 模型参数
        self.model_params = config.parameters.get("model_params", {})
        
        # 初始化模型和数据处理器
        self.curve_params = {}  # 曲线参数
        self.health_index_model = None  # 健康指数计算模型
        self.aging_curve_model = None  # 老化曲线模型
        self.scaler = StandardScaler()
        self.device_models = {}  # 设备ID -> 模型参数
        self.performance_metrics = {}
    
    async def fit_aging_curve(self, 
                             historical_data: pd.DataFrame, 
                             device_id: str) -> Dict[str, Any]:
        """
        拟合设备老化曲线
        
        Args:
            historical_data: 历史数据DataFrame
            device_id: 设备ID
            
        Returns:
            Dict[str, Any]: 拟合结果
        """
        try:
            # 确保时间列存在
            if self.time_column not in historical_data.columns:
                return {
                    "success": False,
                    "message": f"Time column '{self.time_column}' not found in data"
                }
            
            # 确保时间列是datetime类型
            if not pd.api.types.is_datetime64_any_dtype(historical_data[self.time_column]):
                try:
                    historical_data[self.time_column] = pd.to_datetime(historical_data[self.time_column])
                except Exception as e:
                    return {
                        "success": False,
                        "message": f"Failed to convert time column to datetime: {str(e)}"
                    }
            
            # 按时间排序
            historical_data = historical_data.sort_values(by=self.time_column)
            
            # 计算或提取健康指数
            if self.health_index_column and self.health_index_column in historical_data.columns:
                # 使用现有的健康指数列
                health_indices = historical_data[self.health_index_column].values
            else:
                # 计算健康指数
                health_indices = await self._calculate_health_index(historical_data, device_id)
            
            if health_indices is None:
                return {
                    "success": False,
                    "message": "Failed to calculate health indices"
                }
            
            # 获取时间序列（转换为天数）
            start_time = historical_data[self.time_column].min()
            time_days = [(t - start_time).total_seconds() / (24 * 3600) for t in historical_data[self.time_column]]
            
            # 拟合老化曲线
            curve_params, curve_metrics = await self._fit_curve(time_days, health_indices)
            
            if not curve_params:
                return {
                    "success": False,
                    "message": "Failed to fit aging curve"
                }
            
            # 保存设备模型
            self.device_models[device_id] = {
                "start_time": start_time,
                "curve_params": curve_params,
                "curve_metrics": curve_metrics,
                "last_health_index": float(health_indices[-1]),
                "last_update_time": historical_data[self.time_column].max()
            }
            
            return {
                "success": True,
                "message": "Successfully fitted aging curve",
                "device_id": device_id,
                "curve_type": self.curve_type,
                "curve_params": curve_params,
                "performance": curve_metrics,
                "current_health_index": float(health_indices[-1])
            }
        
        except Exception as e:
            logger.error(f"Error fitting aging curve: {e}")
            return {
                "success": False,
                "message": f"Error fitting aging curve: {str(e)}"
            }
    
    async def predict_health_index(self, 
                                  current_data: pd.DataFrame,
                                  device_id: str,
                                  days_ahead: int = 30) -> AgingCurvePrediction:
        """
        预测设备健康指数和故障概率
        
        Args:
            current_data: 当前数据DataFrame
            device_id: 设备ID
            days_ahead: 预测未来天数
            
        Returns:
            AgingCurvePrediction: 预测结果
        """
        try:
            # 检查设备模型是否存在
            if device_id not in self.device_models:
                return AgingCurvePrediction(
                    model_id=self.config.model_id,
                    device_id=device_id,
                    success=False,
                    message=f"No aging curve model found for device {device_id}",
                    current_health_index=0.0,
                    predicted_health_indices={},
                    failure_probability={}
                )
            
            device_model = self.device_models[device_id]
            
            # 计算当前健康指数
            if self.health_index_column and self.health_index_column in current_data.columns:
                # 使用现有的健康指数列
                current_health_index = float(current_data[self.health_index_column].mean())
            else:
                # 计算健康指数
                health_indices = await self._calculate_health_index(current_data, device_id)
                if health_indices is None:
                    current_health_index = device_model["last_health_index"]
                else:
                    current_health_index = float(np.mean(health_indices))
            
            # 获取当前时间
            if self.time_column in current_data.columns:
                current_time = current_data[self.time_column].max()
            else:
                current_time = datetime.now()
            
            # 计算当前时间距离起始时间的天数
            start_time = device_model["start_time"]
            current_days = (current_time - start_time).total_seconds() / (24 * 3600)
            
            # 预测未来健康指数
            predicted_health_indices = {}
            confidence_interval = {}
            
            for day in range(1, days_ahead + 1):
                future_days = current_days + day
                future_date = (current_time + timedelta(days=day)).strftime("%Y-%m-%d")
                
                # 预测健康指数
                health_index, (lower_bound, upper_bound) = await self._predict_health_at_time(
                    future_days, device_model["curve_params"]
                )
                
                predicted_health_indices[future_date] = float(health_index)
                confidence_interval[future_date] = (float(lower_bound), float(upper_bound))
            
            # 计算故障概率
            failure_probability = {}
            
            for date, health_index in predicted_health_indices.items():
                # 基于健康指数计算故障概率
                # 使用sigmoid函数将健康指数映射到故障概率
                if health_index <= self.failure_threshold:
                    # 健康指数低于故障阈值，高故障概率
                    prob = 0.9 + 0.1 * (1 - health_index / self.failure_threshold)
                elif health_index <= self.warning_threshold:
                    # 健康指数在警告和故障阈值之间，中等故障概率
                    prob = 0.5 + 0.4 * (self.warning_threshold - health_index) / (self.warning_threshold - self.failure_threshold)
                else:
                    # 健康指数高于警告阈值，低故障概率
                    prob = 0.1 * (1 - (health_index - self.warning_threshold) / (1 - self.warning_threshold))
                
                failure_probability[date] = float(min(max(prob, 0.0), 1.0))
            
            # 估计剩余寿命
            remaining_life = None
            for day in range(1, 365 * 5):  # 最多预测5年
                future_days = current_days + day
                health_index, _ = await self._predict_health_at_time(
                    future_days, device_model["curve_params"]
                )
                
                if health_index <= self.failure_threshold:
                    remaining_life = day
                    break
            
            return AgingCurvePrediction(
                model_id=self.config.model_id,
                device_id=device_id,
                success=True,
                message="Successfully predicted health indices",
                current_health_index=current_health_index,
                predicted_health_indices=predicted_health_indices,
                failure_probability=failure_probability,
                estimated_remaining_life=remaining_life,
                confidence_interval=confidence_interval,
                metadata={
                    "curve_type": self.curve_type,
                    "curve_params": device_model["curve_params"],
                    "failure_threshold": self.failure_threshold,
                    "warning_threshold": self.warning_threshold
                }
            )
        
        except Exception as e:
            logger.error(f"Error predicting health index: {e}")
            return AgingCurvePrediction(
                model_id=self.config.model_id,
                device_id=device_id,
                success=False,
                message=f"Error predicting health index: {str(e)}",
                current_health_index=0.0,
                predicted_health_indices={},
                failure_probability={}
            )
    
    async def _calculate_health_index(self, data: pd.DataFrame, device_id: str) -> Optional[np.ndarray]:
        """
        计算健康指数
        
        Args:
            data: 输入数据
            device_id: 设备ID
            
        Returns:
            Optional[np.ndarray]: 健康指数数组，如果失败则返回None
        """
        try:
            # 确定要使用的特征列
            if self.feature_columns:
                feature_cols = [col for col in self.feature_columns if col in data.columns]
            else:
                # 默认使用所有数值列，排除时间列
                exclude_cols = [self.time_column]
                feature_cols = [col for col in data.select_dtypes(include=np.number).columns 
                               if col not in exclude_cols]
            
            if not feature_cols:
                logger.error("No feature columns found for health index calculation")
                return None
            
            # 提取特征
            X = data[feature_cols].values
            
            # 标准化特征
            X = self.scaler.fit_transform(X)
            
            # 计算健康指数
            # 方法1：使用主成分分析（PCA）的第一主成分
            from sklearn.decomposition import PCA
            pca = PCA(n_components=1)
            health_component = pca.fit_transform(X).flatten()
            
            # 归一化到[0,1]区间，1表示最健康
            health_min = np.min(health_component)
            health_max = np.max(health_component)
            
            if health_max > health_min:
                health_indices = (health_component - health_min) / (health_max - health_min)
            else:
                health_indices = np.ones_like(health_component)
            
            # 如果健康指数应该随时间递减（老化过程），检查趋势并在必要时反转
            time_values = np.arange(len(health_indices))
            slope, _ = np.polyfit(time_values, health_indices, 1)
            
            if slope > 0:  # 如果健康指数随时间增加，反转它
                health_indices = 1 - health_indices
            
            return health_indices
        
        except Exception as e:
            logger.error(f"Error calculating health index: {e}")
            return None
    
    async def _fit_curve(self, time_days: List[float], health_indices: np.ndarray) -> Tuple[Dict[str, float], Dict[str, float]]:
        """
        拟合老化曲线
        
        Args:
            time_days: 时间序列（天数）
            health_indices: 健康指数序列
            
        Returns:
            Tuple[Dict[str, float], Dict[str, float]]: (曲线参数, 性能指标)
        """
        try:
            # 转换为numpy数组
            x = np.array(time_days)
            y = np.array(health_indices)
            
            # 根据曲线类型选择拟合函数
            if self.curve_type == "weibull":
                # Weibull曲线: y = a * exp(-(x/b)^c)
                def weibull_curve(x, a, b, c):
                    return a * np.exp(-np.power(x / b, c))
                
                # 初始参数猜测
                p0 = [1.0, max(x) / 2, 1.0]
                
                # 拟合曲线
                params, pcov = curve_fit(weibull_curve, x, y, p0=p0, bounds=([0.5, 1, 0.1], [1.5, 10000, 10]))
                
                # 提取参数
                a, b, c = params
                
                # 计算拟合值
                y_fit = weibull_curve(x, a, b, c)
                
                # 计算性能指标
                mse = mean_squared_error(y, y_fit)
                r2 = r2_score(y, y_fit)
                
                # 计算参数标准差（用于置信区间）
                param_std = np.sqrt(np.diag(pcov))
                
                return {
                    "curve_type": "weibull",
                    "a": float(a),
                    "b": float(b),
                    "c": float(c),
                    "param_std": param_std.tolist()
                }, {
                    "mse": float(mse),
                    "r2": float(r2)
                }
            
            elif self.curve_type == "exponential":
                # 指数曲线: y = a * exp(-b * x) + c
                def exp_curve(x, a, b, c):
                    return a * np.exp(-b * x) + c
                
                # 初始参数猜测
                p0 = [1.0, 0.01, 0.0]
                
                # 拟合曲线
                params, pcov = curve_fit(exp_curve, x, y, p0=p0, bounds=([0.5, 0.0001, -0.5], [1.5, 0.1, 0.5]))
                
                # 提取参数
                a, b, c = params
                
                # 计算拟合值
                y_fit = exp_curve(x, a, b, c)
                
                # 计算性能指标
                mse = mean_squared_error(y, y_fit)
                r2 = r2_score(y, y_fit)
                
                # 计算参数标准差（用于置信区间）
                param_std = np.sqrt(np.diag(pcov))
                
                return {
                    "curve_type": "exponential",
                    "a": float(a),
                    "b": float(b),
                    "c": float(c),
                    "param_std": param_std.tolist()
                }, {
                    "mse": float(mse),
                    "r2": float(r2)
                }
            
            elif self.curve_type == "linear":
                # 线性曲线: y = a * x + b
                def linear_curve(x, a, b):
                    return a * x + b
                
                # 拟合曲线
                params, pcov = curve_fit(linear_curve, x, y)
                
                # 提取参数
                a, b = params
                
                # 计算拟合值
                y_fit = linear_curve(x, a, b)
                
                # 计算性能指标
                mse = mean_squared_error(y, y_fit)
                r2 = r2_score(y, y_fit)
                
                # 计算参数标准差（用于置信区间）
                param_std = np.sqrt(np.diag(pcov))
                
                return {
                    "curve_type": "linear",
                    "a": float(a),
                    "b": float(b),
                    "param_std": param_std.tolist()
                }, {
                    "mse": float(mse),
                    "r2": float(r2)
                }
            
            elif self.curve_type == "ml":
                # 机器学习模型（随机森林回归）
                model = RandomForestRegressor(
                    n_estimators=self.model_params.get("n_estimators", 100),
                    max_depth=self.model_params.get("max_depth", None),
                    random_state=self.random_state
                )
                
                # 重塑特征
                X = x.reshape(-1, 1)
                
                # 拟合模型
                model.fit(X, y)
                
                # 计算拟合值
                y_fit = model.predict(X)
                
                # 计算性能指标
                mse = mean_squared_error(y, y_fit)
                r2 = r2_score(y, y_fit)
                
                # 保存模型
                self.aging_curve_model = model
                
                return {
                    "curve_type": "ml",
                    "model": "random_forest"
                }, {
                    "mse": float(mse),
                    "r2": float(r2)
                }
            
            else:
                logger.error(f"Unknown curve type: {self.curve_type}")
                return {}, {}
        
        except Exception as e:
            logger.error(f"Error fitting curve: {e}")
            return {}, {}
    
    async def _predict_health_at_time(self, time_days: float, curve_params: Dict[str, Any]) -> Tuple[float, Tuple[float, float]]:
        """
        预测指定时间点的健康指数
        
        Args:
            time_days: 时间点（天数）
            curve_params: 曲线参数
            
        Returns:
            Tuple[float, Tuple[float, float]]: (健康指数, (下限, 上限))
        """
        curve_type = curve_params.get("curve_type")
        
        if curve_type == "weibull":
            a = curve_params.get("a")
            b = curve_params.get("b")
            c = curve_params.get("c")
            param_std = curve_params.get("param_std", [0, 0, 0])
            
            # 预测健康指数
            health_index = a * np.exp(-np.power(time_days / b, c))
            
            # 计算置信区间
            # 简化处理：使用参数标准差估计预测的标准差
            std_dev = np.abs(health_index) * np.sqrt(
                (param_std[0] / a) ** 2 + 
                (param_std[1] / b * time_days / b) ** 2 * c ** 2 + 
                (param_std[2] / c * np.log(time_days / b)) ** 2
            )
            
            # 计算置信区间
            z_score = 1.96  # 95%置信区间
            lower_bound = max(0, health_index - z_score * std_dev)
            upper_bound = min(1, health_index + z_score * std_dev)
            
            return health_index, (lower_bound, upper_bound)
        
        elif curve_type == "exponential":
            a = curve_params.get("a")
            b = curve_params.get("b")
            c = curve_params.get("c")
            param_std = curve_params.get("param_std", [0, 0, 0])
            
            # 预测健康指数
            health_index = a * np.exp(-b * time_days) + c
            
            # 计算置信区间
            # 简化处理：使用参数标准差估计预测的标准差
            std_dev = np.sqrt(
                (param_std[0] * np.exp(-b * time_days)) ** 2 + 
                (param_std[1] * a * time_days * np.exp(-b * time_days)) ** 2 + 
                param_std[2] ** 2
            )
            
            # 计算置信区间
            z_score = 1.96  # 95%置信区间
            lower_bound = max(0, health_index - z_score * std_dev)
            upper_bound = min(1, health_index + z_score * std_dev)
            
            return health_index, (lower_bound, upper_bound)
        
        elif curve_type == "linear":
            a = curve_params.get("a")
            b = curve_params.get("b")
            param_std = curve_params.get("param_std", [0, 0])
            
            # 预测健康指数
            health_index = a * time_days + b
            
            # 计算置信区间
            # 简化处理：使用参数标准差估计预测的标准差
            std_dev = np.sqrt(
                (param_std[0] * time_days) ** 2 + 
                param_std[1] ** 2
            )
            
            # 计算置信区间
            z_score = 1.96  # 95%置信区间
            lower_bound = max(0, health_index - z_score * std_dev)
            upper_bound = min(1, health_index + z_score * std_dev)
            
            return health_index, (lower_bound, upper_bound)
        
        elif curve_type == "ml":
            if self.aging_curve_model is None:
                return 0.5, (0.3, 0.7)
            
            # 预测健康指数
            X = np.array([[time_days]])
            health_index = self.aging_curve_model.predict(X)[0]
            
            # 对于随机森林，可以使用预测的标准差估计置信区间
            if hasattr(self.aging_curve_model, "estimators_"):
                predictions = np.array([tree.predict(X)[0] for tree in self.aging_curve_model.estimators_])
                std_dev = np.std(predictions)
                
                # 计算置信区间
                z_score = 1.96  # 95%置信区间
                lower_bound = max(0, health_index - z_score * std_dev)
                upper_bound = min(1, health_index + z_score * std_dev)
            else:
                # 默认置信区间
                lower_bound = max(0, health_index - 0.1)
                upper_bound = min(1, health_index + 0.1)
            
            return health_index, (lower_bound, upper_bound)
        
        else:
            logger.error(f"Unknown curve type: {curve_type}")
            return 0.5, (0.3, 0.7)
    
    async def save_model(self, path: str) -> bool:
        """
        保存老化曲线模型
        
        Args:
            path: 保存路径
            
        Returns:
            bool: 保存是否成功
        """
        try:
            os.makedirs(path, exist_ok=True)
            
            # 保存配置和元数据
            metadata = {
                "curve_type": self.curve_type,
                "time_column": self.time_column,
                "feature_columns": self.feature_columns,
                "health_index_column": self.health_index_column,
                "failure_threshold": self.failure_threshold,
                "warning_threshold": self.warning_threshold,
                "confidence_level": self.confidence_level,
                "random_state": self.random_state,
                "model_params": self.model_params,
                "performance_metrics": self.performance_metrics
            }
            
            with open(os.path.join(path, "metadata.json"), "w") as f:
                json.dump(metadata, f, indent=2, default=str)
            
            # 保存设备模型
            with open(os.path.join(path, "device_models.json"), "w") as f:
                # 转换datetime对象为字符串
                serializable_models = {}
                for device_id, model in self.device_models.items():
                    serializable_model = model.copy()
                    serializable_model["start_time"] = serializable_model["start_time"].isoformat()
                    serializable_model["last_update_time"] = serializable_model["last_update_time"].isoformat()
                    serializable_models[device_id] = serializable_model
                
                json.dump(serializable_models, f, indent=2, default=str)
            
            # 保存标准化器
            with open(os.path.join(path, "scaler.pkl"), "wb") as f:
                pickle.dump(self.scaler, f)
            
            # 如果使用ML模型，保存模型
            if self.curve_type == "ml" and self.aging_curve_model is not None:
                with open(os.path.join(path, "aging_curve_model.pkl"), "wb") as f:
                    pickle.dump(self.aging_curve_model, f)
            
            return True
        
        except Exception as e:
            logger.error(f"Error saving aging curve model: {e}")
            return False
    
    async def load_model(self, path: str) -> bool:
        """
        加载老化曲线模型
        
        Args:
            path: 加载路径
            
        Returns:
            bool: 加载是否成功
        """
        try:
            # 加载配置和元数据
            with open(os.path.join(path, "metadata.json"), "r") as f:
                metadata = json.load(f)
            
            self.curve_type = metadata.get("curve_type", "weibull")
            self.time_column = metadata.get("time_column", "timestamp")
            self.feature_columns = metadata.get("feature_columns", [])
            self.health_index_column = metadata.get("health_index_column")
            self.failure_threshold = metadata.get("failure_threshold", 0.3)
            self.warning_threshold = metadata.get("warning_threshold", 0.6)
            self.confidence_level = metadata.get("confidence_level", 0.95)
            self.random_state = metadata.get("random_state", 42)
            self.model_params = metadata.get("model_params", {})
            self.performance_metrics = metadata.get("performance_metrics", {})
            
            # 加载设备模型
            with open(os.path.join(path, "device_models.json"), "r") as f:
                serializable_models = json.load(f)
                
                # 转换字符串为datetime对象
                self.device_models = {}
                for device_id, model in serializable_models.items():
                    deserializable_model = model.copy()
                    deserializable_model["start_time"] = pd.to_datetime(deserializable_model["start_time"])
                    deserializable_model["last_update_time"] = pd.to_datetime(deserializable_model["last_update_time"])
                    self.device_models[device_id] = deserializable_model
            
            # 加载标准化器
            scaler_path = os.path.join(path, "scaler.pkl")
            if os.path.exists(scaler_path):
                with open(scaler_path, "rb") as f:
                    self.scaler = pickle.load(f)
            
            # 如果使用ML模型，加载模型
            if self.curve_type == "ml":
                model_path = os.path.join(path, "aging_curve_model.pkl")
                if os.path.exists(model_path):
                    with open(model_path, "rb") as f:
                        self.aging_curve_model = pickle.load(f)
            
            return True
        
        except Exception as e:
            logger.error(f"Error loading aging curve model: {e}")
            return False
    
    def get_model_info(self) -> Dict[str, Any]:
        """
        获取模型信息
        
        Returns:
            Dict[str, Any]: 模型信息
        """
        return {
            "model_type": "health_index_aging_model",
            "curve_type": self.curve_type,
            "time_column": self.time_column,
            "feature_columns": self.feature_columns,
            "health_index_column": self.health_index_column,
            "failure_threshold": self.failure_threshold,
            "warning_threshold": self.warning_threshold,
            "device_count": len(self.device_models),
            "devices": list(self.device_models.keys()),
            "performance_metrics": self.performance_metrics
        }
