"""
模型训练与自动归类模块初始化文件
"""
from importlib.metadata import version, PackageNotFoundError

try:
    __version__ = version("power_system_fault_prediction")
except PackageNotFoundError:
    __version__ = "0.1.0-dev"

from src.model_training.api.training_api import TrainingAPI
from src.model_training.core.model_trainer import ModelTrainer
from src.model_training.core.auto_classifier import AutoClassifier

__all__ = ["TrainingAPI", "ModelTrainer", "AutoClassifier"]
