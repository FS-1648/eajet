"""
通用模型训练器实现 - 支持多种模型类型的训练和管理
"""
import os
import json
import pickle
import time
from typing import Any, Dict, List, Optional, Union, Tuple
from datetime import datetime

import numpy as np
import pandas as pd
from loguru import logger
from sklearn.model_selection import train_test_split, GridSearchCV
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, roc_auc_score
from sklearn.ensemble import RandomForestClassifier, GradientBoostingClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.svm import SVC
from sklearn.preprocessing import StandardScaler, LabelEncoder

from src.model_training.core.model_trainer import ModelTrainer, TrainingConfig, TrainingResult


class UniversalModelTrainer(ModelTrainer):
    """通用模型训练器"""
    
    def __init__(self, config: TrainingConfig):
        """
        初始化通用模型训练器
        
        Args:
            config: 训练器配置
        """
        super().__init__(config)
        
        # 获取配置参数
        self.test_size = config.parameters.get("test_size", 0.2)
        self.random_state = config.parameters.get("random_state", 42)
        self.auto_tune = config.parameters.get("auto_tune", True)
        self.cv_folds = config.parameters.get("cv_folds", 5)
        self.feature_selection = config.parameters.get("feature_selection", True)
        self.max_features = config.parameters.get("max_features", 20)
        
        # 初始化模型存储
        self.models = {}  # 模型ID -> 模型对象
        self.model_configs = {}  # 模型ID -> 模型配置
        self.model_metrics = {}  # 模型ID -> 性能指标
        self.scalers = {}  # 模型ID -> 标准化器
        self.label_encoders = {}  # 模型ID -> 标签编码器
        self.feature_importances = {}  # 模型ID -> 特征重要性
    
    async def train_model(self, 
                         training_data: pd.DataFrame, 
                         target_column: str,
                         model_type: str,
                         model_params: Dict[str, Any] = None) -> TrainingResult:
        """
        训练模型
        
        Args:
            training_data: 训练数据DataFrame
            target_column: 目标列名
            model_type: 模型类型
            model_params: 模型参数
            
        Returns:
            TrainingResult: 训练结果
        """
        try:
            start_time = time.time()
            
            # 生成模型ID
            model_id = f"{model_type}_{datetime.now().strftime('%Y%m%d%H%M%S')}"
            
            # 检查目标列是否存在
            if target_column not in training_data.columns:
                return TrainingResult(
                    trainer_id=self.config.trainer_id,
                    success=False,
                    message=f"Target column '{target_column}' not found in data",
                    model_id=model_id,
                    model_type=model_type,
                    performance_metrics={},
                    training_time=0.0
                )
            
            # 分离特征和目标
            y = training_data[target_column]
            X = training_data.drop(columns=[target_column])
            
            # 只保留数值列
            numeric_cols = X.select_dtypes(include=np.number).columns.tolist()
            X = X[numeric_cols]
            
            if X.empty:
                return TrainingResult(
                    trainer_id=self.config.trainer_id,
                    success=False,
                    message="No numeric feature columns found in data",
                    model_id=model_id,
                    model_type=model_type,
                    performance_metrics={},
                    training_time=0.0
                )
            
            # 标准化特征
            scaler = StandardScaler()
            X_scaled = scaler.fit_transform(X)
            
            # 编码标签（如果是分类问题）
            if model_type in ["random_forest", "gradient_boosting", "logistic_regression", "svm"]:
                label_encoder = LabelEncoder()
                y_encoded = label_encoder.fit_transform(y)
                self.label_encoders[model_id] = label_encoder
            else:
                y_encoded = y.values
            
            # 特征选择（如果启用）
            selected_features = numeric_cols
            if self.feature_selection and len(numeric_cols) > self.max_features:
                selected_features = await self._select_features(X_scaled, y_encoded, model_type, n_features=self.max_features)
                
                # 更新特征矩阵
                feature_indices = [numeric_cols.index(feature) for feature in selected_features]
                X_scaled = X_scaled[:, feature_indices]
            
            # 划分训练集和测试集
            X_train, X_test, y_train, y_test = train_test_split(
                X_scaled, y_encoded, test_size=self.test_size, random_state=self.random_state, stratify=y_encoded if model_type != "regression" else None
            )
            
            # 创建并训练模型
            model, params = await self._create_and_train_model(
                X_train, y_train, model_type, model_params, X_test, y_test
            )
            
            if model is None:
                return TrainingResult(
                    trainer_id=self.config.trainer_id,
                    success=False,
                    message=f"Failed to create model of type {model_type}",
                    model_id=model_id,
                    model_type=model_type,
                    performance_metrics={},
                    training_time=0.0
                )
            
            # 评估模型
            y_pred = model.predict(X_test)
            
            # 计算性能指标
            metrics = {}
            
            if model_type in ["random_forest", "gradient_boosting", "logistic_regression", "svm"]:
                # 分类指标
                metrics["accuracy"] = float(accuracy_score(y_test, y_pred))
                
                # 多分类问题使用macro平均
                metrics["precision"] = float(precision_score(y_test, y_pred, average="macro", zero_division=0))
                metrics["recall"] = float(recall_score(y_test, y_pred, average="macro", zero_division=0))
                metrics["f1"] = float(f1_score(y_test, y_pred, average="macro", zero_division=0))
                
                # 如果是二分类问题且模型支持概率输出，计算AUC
                if len(np.unique(y_encoded)) == 2 and hasattr(model, "predict_proba"):
                    y_proba = model.predict_proba(X_test)[:, 1]
                    metrics["auc"] = float(roc_auc_score(y_test, y_proba))
            else:
                # 回归指标
                metrics["mse"] = float(np.mean((y_test - y_pred) ** 2))
                metrics["rmse"] = float(np.sqrt(metrics["mse"]))
                metrics["mae"] = float(np.mean(np.abs(y_test - y_pred)))
                metrics["r2"] = float(model.score(X_test, y_test))
            
            # 提取特征重要性（如果模型支持）
            feature_importances = {}
            if hasattr(model, "feature_importances_"):
                importances = model.feature_importances_
                feature_importances = dict(zip(selected_features, importances))
            
            # 保存模型和相关信息
            self.models[model_id] = model
            self.scalers[model_id] = scaler
            self.model_configs[model_id] = {
                "model_type": model_type,
                "target_column": target_column,
                "feature_columns": selected_features,
                "model_params": params,
                "created_at": datetime.now().isoformat()
            }
            self.model_metrics[model_id] = metrics
            self.feature_importances[model_id] = feature_importances
            
            # 计算训练时间
            training_time = time.time() - start_time
            
            return TrainingResult(
                trainer_id=self.config.trainer_id,
                success=True,
                message=f"Successfully trained {model_type} model",
                model_id=model_id,
                model_type=model_type,
                performance_metrics=metrics,
                training_time=training_time,
                metadata={
                    "feature_columns": selected_features,
                    "feature_importances": feature_importances,
                    "model_params": params
                }
            )
        
        except Exception as e:
            logger.error(f"Error training model: {e}")
            return TrainingResult(
                trainer_id=self.config.trainer_id,
                success=False,
                message=f"Error training model: {str(e)}",
                model_id=model_id if 'model_id' in locals() else f"error_{datetime.now().strftime('%Y%m%d%H%M%S')}",
                model_type=model_type,
                performance_metrics={},
                training_time=time.time() - start_time if 'start_time' in locals() else 0.0
            )
    
    async def evaluate_model(self, 
                            model_id: str,
                            test_data: pd.DataFrame,
                            target_column: str) -> Dict[str, Any]:
        """
        评估模型
        
        Args:
            model_id: 模型ID
            test_data: 测试数据DataFrame
            target_column: 目标列名
            
        Returns:
            Dict[str, Any]: 评估结果
        """
        try:
            # 检查模型是否存在
            if model_id not in self.models:
                return {
                    "success": False,
                    "message": f"Model {model_id} not found"
                }
            
            # 检查目标列是否存在
            if target_column not in test_data.columns:
                return {
                    "success": False,
                    "message": f"Target column '{target_column}' not found in data"
                }
            
            # 获取模型和相关信息
            model = self.models[model_id]
            model_config = self.model_configs[model_id]
            scaler = self.scalers[model_id]
            
            # 分离特征和目标
            y_true = test_data[target_column]
            
            # 获取特征列
            feature_columns = model_config["feature_columns"]
            
            # 检查特征列是否存在
            missing_features = [col for col in feature_columns if col not in test_data.columns]
            if missing_features:
                return {
                    "success": False,
                    "message": f"Missing feature columns: {missing_features}"
                }
            
            X = test_data[feature_columns]
            
            # 标准化特征
            X_scaled = scaler.transform(X)
            
            # 编码标签（如果是分类问题）
            model_type = model_config["model_type"]
            if model_type in ["random_forest", "gradient_boosting", "logistic_regression", "svm"]:
                if model_id in self.label_encoders:
                    label_encoder = self.label_encoders[model_id]
                    y_true_encoded = label_encoder.transform(y_true)
                else:
                    return {
                        "success": False,
                        "message": f"Label encoder not found for model {model_id}"
                    }
            else:
                y_true_encoded = y_true.values
            
            # 预测
            y_pred = model.predict(X_scaled)
            
            # 计算性能指标
            metrics = {}
            
            if model_type in ["random_forest", "gradient_boosting", "logistic_regression", "svm"]:
                # 分类指标
                metrics["accuracy"] = float(accuracy_score(y_true_encoded, y_pred))
                
                # 多分类问题使用macro平均
                metrics["precision"] = float(precision_score(y_true_encoded, y_pred, average="macro", zero_division=0))
                metrics["recall"] = float(recall_score(y_true_encoded, y_pred, average="macro", zero_division=0))
                metrics["f1"] = float(f1_score(y_true_encoded, y_pred, average="macro", zero_division=0))
                
                # 如果是二分类问题且模型支持概率输出，计算AUC
                if len(np.unique(y_true_encoded)) == 2 and hasattr(model, "predict_proba"):
                    y_proba = model.predict_proba(X_scaled)[:, 1]
                    metrics["auc"] = float(roc_auc_score(y_true_encoded, y_proba))
                
                # 如果有标签编码器，将预测结果转换回原始标签
                y_pred_original = label_encoder.inverse_transform(y_pred)
                
                # 计算混淆矩阵
                from sklearn.metrics import confusion_matrix
                cm = confusion_matrix(y_true, y_pred_original)
                
                # 将混淆矩阵转换为字典格式
                labels = label_encoder.classes_
                cm_dict = {}
                for i, true_label in enumerate(labels):
                    cm_dict[str(true_label)] = {}
                    for j, pred_label in enumerate(labels):
                        cm_dict[str(true_label)][str(pred_label)] = int(cm[i, j])
                
                metrics["confusion_matrix"] = cm_dict
            else:
                # 回归指标
                metrics["mse"] = float(np.mean((y_true_encoded - y_pred) ** 2))
                metrics["rmse"] = float(np.sqrt(metrics["mse"]))
                metrics["mae"] = float(np.mean(np.abs(y_true_encoded - y_pred)))
                metrics["r2"] = float(model.score(X_scaled, y_true_encoded))
            
            return {
                "success": True,
                "message": "Successfully evaluated model",
                "model_id": model_id,
                "model_type": model_type,
                "metrics": metrics
            }
        
        except Exception as e:
            logger.error(f"Error evaluating model: {e}")
            return {
                "success": False,
                "message": f"Error evaluating model: {str(e)}"
            }
    
    async def save_model(self, model_id: str, path: str) -> bool:
        """
        保存模型
        
        Args:
            model_id: 模型ID
            path: 保存路径
            
        Returns:
            bool: 保存是否成功
        """
        try:
            # 检查模型是否存在
            if model_id not in self.models:
                logger.error(f"Model {model_id} not found")
                return False
            
            # 创建保存目录
            model_dir = os.path.join(path, model_id)
            os.makedirs(model_dir, exist_ok=True)
            
            # 保存模型
            with open(os.path.join(model_dir, "model.pkl"), "wb") as f:
                pickle.dump(self.models[model_id], f)
            
            # 保存标准化器
            with open(os.path.join(model_dir, "scaler.pkl"), "wb") as f:
                pickle.dump(self.scalers[model_id], f)
            
            # 保存标签编码器（如果存在）
            if model_id in self.label_encoders:
                with open(os.path.join(model_dir, "label_encoder.pkl"), "wb") as f:
                    pickle.dump(self.label_encoders[model_id], f)
            
            # 保存模型配置
            with open(os.path.join(model_dir, "config.json"), "w") as f:
                json.dump(self.model_configs[model_id], f, indent=2)
            
            # 保存性能指标
            with open(os.path.join(model_dir, "metrics.json"), "w") as f:
                json.dump(self.model_metrics[model_id], f, indent=2)
            
            # 保存特征重要性
            with open(os.path.join(model_dir, "feature_importances.json"), "w") as f:
                json.dump(self.feature_importances[model_id], f, indent=2)
            
            logger.info(f"Successfully saved model {model_id} to {model_dir}")
            return True
        
        except Exception as e:
            logger.error(f"Error saving model {model_id}: {e}")
            return False
    
    async def load_model(self, model_id: str, path: str) -> bool:
        """
        加载模型
        
        Args:
            model_id: 模型ID
            path: 加载路径
            
        Returns:
            bool: 加载是否成功
        """
        try:
            # 检查模型目录是否存在
            model_dir = os.path.join(path, model_id)
            if not os.path.exists(model_dir):
                logger.error(f"Model directory {model_dir} not found")
                return False
            
            # 加载模型
            with open(os.path.join(model_dir, "model.pkl"), "rb") as f:
                self.models[model_id] = pickle.load(f)
            
            # 加载标准化器
            with open(os.path.join(model_dir, "scaler.pkl"), "rb") as f:
                self.scalers[model_id] = pickle.load(f)
            
            # 加载标签编码器（如果存在）
            label_encoder_path = os.path.join(model_dir, "label_encoder.pkl")
            if os.path.exists(label_encoder_path):
                with open(label_encoder_path, "rb") as f:
                    self.label_encoders[model_id] = pickle.load(f)
            
            # 加载模型配置
            with open(os.path.join(model_dir, "config.json"), "r") as f:
                self.model_configs[model_id] = json.load(f)
            
            # 加载性能指标
            with open(os.path.join(model_dir, "metrics.json"), "r") as f:
                self.model_metrics[model_id] = json.load(f)
            
            # 加载特征重要性
            with open(os.path.join(model_dir, "feature_importances.json"), "r") as f:
                self.feature_importances[model_id] = json.load(f)
            
            logger.info(f"Successfully loaded model {model_id} from {model_dir}")
            return True
        
        except Exception as e:
            logger.error(f"Error loading model {model_id}: {e}")
            return False
    
    def get_model_info(self, model_id: str) -> Dict[str, Any]:
        """
        获取模型信息
        
        Args:
            model_id: 模型ID
            
        Returns:
            Dict[str, Any]: 模型信息
        """
        if model_id not in self.models:
            return {
                "success": False,
                "message": f"Model {model_id} not found"
            }
        
        return {
            "success": True,
            "model_id": model_id,
            "model_type": self.model_configs[model_id]["model_type"],
            "target_column": self.model_configs[model_id]["target_column"],
            "feature_columns": self.model_configs[model_id]["feature_columns"],
            "model_params": self.model_configs[model_id]["model_params"],
            "created_at": self.model_configs[model_id]["created_at"],
            "metrics": self.model_metrics[model_id],
            "top_features": sorted(
                self.feature_importances[model_id].items(),
                key=lambda x: x[1],
                reverse=True
            )[:10] if model_id in self.feature_importances else []
        }
    
    async def _select_features(self, 
                              X: np.ndarray, 
                              y: np.ndarray, 
                              model_type: str,
                              n_features: int = 20) -> List[str]:
        """
        特征选择
        
        Args:
            X: 特征矩阵
            y: 目标向量
            model_type: 模型类型
            n_features: 选择的特征数量
            
        Returns:
            List[str]: 选择的特征列名
        """
        try:
            from sklearn.feature_selection import SelectKBest, f_classif, f_regression
            
            # 根据模型类型选择特征选择方法
            if model_type in ["random_forest", "gradient_boosting", "logistic_regression", "svm"]:
                # 分类问题
                selector = SelectKBest(f_classif, k=min(n_features, X.shape[1]))
            else:
                # 回归问题
                selector = SelectKBest(f_regression, k=min(n_features, X.shape[1]))
            
            # 应用特征选择
            selector.fit(X, y)
            
            # 获取选择的特征索引
            selected_indices = selector.get_support(indices=True)
            
            # 返回选择的特征列名
            return [self.model_configs[model_id]["feature_columns"][i] for i in selected_indices]
        
        except Exception as e:
            logger.error(f"Error selecting features: {e}")
            # 如果特征选择失败，返回所有特征
            return self.model_configs[model_id]["feature_columns"]
    
    async def _create_and_train_model(self,
                                     X_train: np.ndarray,
                                     y_train: np.ndarray,
                                     model_type: str,
                                     model_params: Dict[str, Any],
                                     X_val: np.ndarray = None,
                                     y_val: np.ndarray = None) -> Tuple[Any, Dict[str, Any]]:
        """
        创建并训练模型
        
        Args:
            X_train: 训练特征
            y_train: 训练标签
            model_type: 模型类型
            model_params: 模型参数
            X_val: 验证特征
            y_val: 验证标签
            
        Returns:
            Tuple[Any, Dict[str, Any]]: (模型, 参数)
        """
        try:
            # 初始化默认参数
            params = model_params or {}
            
            # 根据模型类型创建模型
            if model_type == "random_forest":
                # 随机森林分类器
                default_params = {
                    "n_estimators": 100,
                    "max_depth": None,
                    "min_samples_split": 2,
                    "random_state": self.random_state
                }
                
                # 合并默认参数和用户参数
                for key, value in default_params.items():
                    if key not in params:
                        params[key] = value
                
                if self.auto_tune:
                    # 自动调参
                    param_grid = {
                        "n_estimators": [50, 100, 200],
                        "max_depth": [None, 10, 20, 30],
                        "min_samples_split": [2, 5, 10]
                    }
                    
                    base_model = RandomForestClassifier(random_state=self.random_state)
                    grid_search = GridSearchCV(base_model, param_grid, cv=self.cv_folds, scoring="accuracy")
                    grid_search.fit(X_train, y_train)
                    
                    # 更新参数
                    params.update(grid_search.best_params_)
                
                # 创建最终模型
                model = RandomForestClassifier(**params)
            
            elif model_type == "gradient_boosting":
                # 梯度提升分类器
                default_params = {
                    "n_estimators": 100,
                    "learning_rate": 0.1,
                    "max_depth": 3,
                    "random_state": self.random_state
                }
                
                # 合并默认参数和用户参数
                for key, value in default_params.items():
                    if key not in params:
                        params[key] = value
                
                if self.auto_tune:
                    # 自动调参
                    param_grid = {
                        "n_estimators": [50, 100, 200],
                        "learning_rate": [0.01, 0.1, 0.2],
                        "max_depth": [3, 5, 7]
                    }
                    
                    base_model = GradientBoostingClassifier(random_state=self.random_state)
                    grid_search = GridSearchCV(base_model, param_grid, cv=self.cv_folds, scoring="accuracy")
                    grid_search.fit(X_train, y_train)
                    
                    # 更新参数
                    params.update(grid_search.best_params_)
                
                # 创建最终模型
                model = GradientBoostingClassifier(**params)
            
            elif model_type == "logistic_regression":
                # 逻辑回归
                default_params = {
                    "C": 1.0,
                    "solver": "liblinear",
                    "random_state": self.random_state
                }
                
                # 合并默认参数和用户参数
                for key, value in default_params.items():
                    if key not in params:
                        params[key] = value
                
                if self.auto_tune:
                    # 自动调参
                    param_grid = {
                        "C": [0.1, 1.0, 10.0],
                        "solver": ["liblinear", "saga"]
                    }
                    
                    base_model = LogisticRegression(random_state=self.random_state)
                    grid_search = GridSearchCV(base_model, param_grid, cv=self.cv_folds, scoring="accuracy")
                    grid_search.fit(X_train, y_train)
                    
                    # 更新参数
                    params.update(grid_search.best_params_)
                
                # 创建最终模型
                model = LogisticRegression(**params)
            
            elif model_type == "svm":
                # 支持向量机
                default_params = {
                    "C": 1.0,
                    "kernel": "rbf",
                    "probability": True,
                    "random_state": self.random_state
                }
                
                # 合并默认参数和用户参数
                for key, value in default_params.items():
                    if key not in params:
                        params[key] = value
                
                if self.auto_tune:
                    # 自动调参
                    param_grid = {
                        "C": [0.1, 1.0, 10.0],
                        "kernel": ["linear", "rbf", "poly"]
                    }
                    
                    base_model = SVC(probability=True, random_state=self.random_state)
                    grid_search = GridSearchCV(base_model, param_grid, cv=self.cv_folds, scoring="accuracy")
                    grid_search.fit(X_train, y_train)
                    
                    # 更新参数
                    params.update(grid_search.best_params_)
                
                # 创建最终模型
                model = SVC(**params)
            
            else:
                logger.error(f"Unknown model type: {model_type}")
                return None, {}
            
            # 训练模型
            model.fit(X_train, y_train)
            
            return model, params
        
        except Exception as e:
            logger.error(f"Error creating and training model: {e}")
            return None, {}
