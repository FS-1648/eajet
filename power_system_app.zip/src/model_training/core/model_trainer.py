"""
模型训练器基类定义
"""
from abc import ABC, abstractmethod
from typing import Any, Dict, List, Optional, Union, Tuple

import numpy as np
import pandas as pd
from pydantic import BaseModel


class TrainingConfig(BaseModel):
    """模型训练配置基类"""
    trainer_id: str
    trainer_type: str
    name: str
    description: Optional[str] = None
    parameters: Dict[str, Any] = {}
    enabled: bool = True
    metadata: Optional[Dict[str, Any]] = None


class TrainingResult(BaseModel):
    """模型训练结果基类"""
    trainer_id: str
    success: bool
    message: Optional[str] = None
    model_id: str
    model_type: str
    performance_metrics: Dict[str, Any]
    training_time: float  # 训练时间（秒）
    metadata: Optional[Dict[str, Any]] = None


class ModelTrainer(ABC):
    """模型训练器抽象基类"""
    
    def __init__(self, config: TrainingConfig):
        """
        初始化模型训练器
        
        Args:
            config: 训练器配置
        """
        self.config = config
    
    @abstractmethod
    async def train_model(self, 
                         training_data: pd.DataFrame, 
                         target_column: str,
                         model_type: str,
                         model_params: Dict[str, Any] = None) -> TrainingResult:
        """
        训练模型
        
        Args:
            training_data: 训练数据DataFrame
            target_column: 目标列名
            model_type: 模型类型
            model_params: 模型参数
            
        Returns:
            TrainingResult: 训练结果
        """
        pass
    
    @abstractmethod
    async def evaluate_model(self, 
                            model_id: str,
                            test_data: pd.DataFrame,
                            target_column: str) -> Dict[str, Any]:
        """
        评估模型
        
        Args:
            model_id: 模型ID
            test_data: 测试数据DataFrame
            target_column: 目标列名
            
        Returns:
            Dict[str, Any]: 评估结果
        """
        pass
    
    @abstractmethod
    async def save_model(self, model_id: str, path: str) -> bool:
        """
        保存模型
        
        Args:
            model_id: 模型ID
            path: 保存路径
            
        Returns:
            bool: 保存是否成功
        """
        pass
    
    @abstractmethod
    async def load_model(self, model_id: str, path: str) -> bool:
        """
        加载模型
        
        Args:
            model_id: 模型ID
            path: 加载路径
            
        Returns:
            bool: 加载是否成功
        """
        pass
    
    @abstractmethod
    def get_model_info(self, model_id: str) -> Dict[str, Any]:
        """
        获取模型信息
        
        Args:
            model_id: 模型ID
            
        Returns:
            Dict[str, Any]: 模型信息
        """
        pass
