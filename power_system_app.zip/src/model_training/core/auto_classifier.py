"""
自动归类器基类定义
"""
from abc import ABC, abstractmethod
from typing import Any, Dict, List, Optional, Union, Tuple

import numpy as np
import pandas as pd
from pydantic import BaseModel


class ClassificationConfig(BaseModel):
    """自动归类配置基类"""
    classifier_id: str
    classifier_type: str
    name: str
    description: Optional[str] = None
    parameters: Dict[str, Any] = {}
    enabled: bool = True
    metadata: Optional[Dict[str, Any]] = None


class ClassificationResult(BaseModel):
    """自动归类结果基类"""
    classifier_id: str
    success: bool
    message: Optional[str] = None
    classifications: Dict[str, str]  # 数据ID -> 分类结果
    confidence_scores: Dict[str, float]  # 数据ID -> 置信度
    metadata: Optional[Dict[str, Any]] = None


class AutoClassifier(ABC):
    """自动归类器抽象基类"""
    
    def __init__(self, config: ClassificationConfig):
        """
        初始化自动归类器
        
        Args:
            config: 归类器配置
        """
        self.config = config
    
    @abstractmethod
    async def classify_data(self, 
                           data: pd.DataFrame,
                           id_column: str) -> ClassificationResult:
        """
        对数据进行自动归类
        
        Args:
            data: 输入数据DataFrame
            id_column: ID列名
            
        Returns:
            ClassificationResult: 归类结果
        """
        pass
    
    @abstractmethod
    async def train_classifier(self, 
                              training_data: pd.DataFrame,
                              id_column: str,
                              label_column: str) -> Dict[str, Any]:
        """
        训练归类器
        
        Args:
            training_data: 训练数据DataFrame
            id_column: ID列名
            label_column: 标签列名
            
        Returns:
            Dict[str, Any]: 训练结果
        """
        pass
    
    @abstractmethod
    async def update_classifier(self,
                               update_data: pd.DataFrame,
                               id_column: str,
                               label_column: str) -> Dict[str, Any]:
        """
        更新归类器（增量学习）
        
        Args:
            update_data: 更新数据DataFrame
            id_column: ID列名
            label_column: 标签列名
            
        Returns:
            Dict[str, Any]: 更新结果
        """
        pass
    
    @abstractmethod
    async def save_classifier(self, path: str) -> bool:
        """
        保存归类器
        
        Args:
            path: 保存路径
            
        Returns:
            bool: 保存是否成功
        """
        pass
    
    @abstractmethod
    async def load_classifier(self, path: str) -> bool:
        """
        加载归类器
        
        Args:
            path: 加载路径
            
        Returns:
            bool: 加载是否成功
        """
        pass
    
    @abstractmethod
    def get_classifier_info(self) -> Dict[str, Any]:
        """
        获取归类器信息
        
        Returns:
            Dict[str, Any]: 归类器信息
        """
        pass
