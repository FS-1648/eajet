"""
概率模型基类定义
"""
from abc import ABC, abstractmethod
from typing import Any, Dict, List, Optional, Union

import numpy as np
import pandas as pd
from pydantic import BaseModel


class ProbabilityModelConfig(BaseModel):
    """概率模型配置基类"""
    model_id: str
    model_type: str
    name: str
    description: Optional[str] = None
    parameters: Dict[str, Any] = {}
    enabled: bool = True
    metadata: Optional[Dict[str, Any]] = None


class ProbabilityResult(BaseModel):
    """概率计算结果基类"""
    model_id: str
    success: bool
    message: Optional[str] = None
    probabilities: Dict[str, float]
    confidence: Optional[float] = None
    factors: Optional[Dict[str, float]] = None
    metadata: Optional[Dict[str, Any]] = None


class ProbabilityModel(ABC):
    """概率模型抽象基类"""
    
    def __init__(self, config: ProbabilityModelConfig):
        """
        初始化概率模型
        
        Args:
            config: 模型配置
        """
        self.config = config
    
    @abstractmethod
    async def calculate_probability(self, data: pd.DataFrame) -> ProbabilityResult:
        """
        计算故障概率
        
        Args:
            data: 输入数据DataFrame
            
        Returns:
            ProbabilityResult: 概率计算结果
        """
        pass
    
    @abstractmethod
    async def train(self, data: pd.DataFrame, fault_labels: pd.Series) -> Dict[str, Any]:
        """
        训练概率模型
        
        Args:
            data: 训练数据DataFrame
            fault_labels: 故障标签
            
        Returns:
            Dict[str, Any]: 训练结果
        """
        pass
    
    @abstractmethod
    async def save_model(self, path: str) -> bool:
        """
        保存概率模型
        
        Args:
            path: 保存路径
            
        Returns:
            bool: 保存是否成功
        """
        pass
    
    @abstractmethod
    async def load_model(self, path: str) -> bool:
        """
        加载概率模型
        
        Args:
            path: 加载路径
            
        Returns:
            bool: 加载是否成功
        """
        pass
    
    @abstractmethod
    def get_model_info(self) -> Dict[str, Any]:
        """
        获取模型信息
        
        Returns:
            Dict[str, Any]: 模型信息
        """
        pass
