"""
因子分析器 - 分析各因子对故障概率的影响
"""
from typing import Any, Dict, List, Optional, Union, Tuple

import numpy as np
import pandas as pd
from loguru import logger
from scipy import stats
import statsmodels.api as sm
from sklearn.feature_selection import mutual_info_classif
from sklearn.ensemble import RandomForestClassifier
from sklearn.preprocessing import StandardScaler

from src.fault_probability.core.probability_model import ProbabilityResult


class FactorAnalyzer:
    """因子分析器类"""
    
    def __init__(self, methods: List[str] = None):
        """
        初始化因子分析器
        
        Args:
            methods: 分析方法列表，默认为["correlation", "mutual_info", "importance"]
        """
        self.methods = methods or ["correlation", "mutual_info", "importance"]
        self.factor_weights = {}
        self.factor_scores = {}
        self.factor_rankings = {}
        self.combined_weights = {}
    
    async def analyze_factors(self, 
                             data: pd.DataFrame, 
                             fault_labels: pd.Series,
                             factor_columns: List[str] = None) -> Dict[str, Any]:
        """
        分析各因子对故障概率的影响
        
        Args:
            data: 输入数据DataFrame
            fault_labels: 故障标签
            factor_columns: 要分析的因子列，默认为所有数值列
            
        Returns:
            Dict[str, Any]: 分析结果
        """
        try:
            # 确定要分析的因子列
            if factor_columns:
                columns = [col for col in factor_columns if col in data.columns]
            else:
                columns = data.select_dtypes(include=np.number).columns.tolist()
            
            if not columns:
                return {
                    "success": False,
                    "message": "No factor columns found in data"
                }
            
            # 重置分析结果
            self.factor_weights = {}
            self.factor_scores = {}
            self.factor_rankings = {}
            self.combined_weights = {}
            
            # 对每种方法进行分析
            for method in self.methods:
                if method == "correlation":
                    weights = await self._analyze_correlation(data[columns], fault_labels)
                elif method == "mutual_info":
                    weights = await self._analyze_mutual_info(data[columns], fault_labels)
                elif method == "importance":
                    weights = await self._analyze_feature_importance(data[columns], fault_labels)
                elif method == "logistic":
                    weights = await self._analyze_logistic_regression(data[columns], fault_labels)
                else:
                    logger.warning(f"Unknown analysis method: {method}")
                    continue
                
                self.factor_weights[method] = weights
            
            # 计算每个因子的综合得分
            await self._calculate_combined_weights(columns)
            
            return {
                "success": True,
                "message": "Successfully analyzed factors",
                "factor_weights": self.factor_weights,
                "factor_scores": self.factor_scores,
                "factor_rankings": self.factor_rankings,
                "combined_weights": self.combined_weights
            }
        
        except Exception as e:
            logger.error(f"Error analyzing factors: {e}")
            return {
                "success": False,
                "message": f"Error analyzing factors: {str(e)}"
            }
    
    async def _analyze_correlation(self, data: pd.DataFrame, fault_labels: pd.Series) -> Dict[str, float]:
        """
        使用相关性分析方法
        
        Args:
            data: 输入数据
            fault_labels: 故障标签
            
        Returns:
            Dict[str, float]: 因子权重
        """
        weights = {}
        
        for column in data.columns:
            # 计算点二列相关系数
            corr = stats.pointbiserialr(data[column], fault_labels)[0]
            
            # 取绝对值作为权重
            weights[column] = abs(corr)
        
        return weights
    
    async def _analyze_mutual_info(self, data: pd.DataFrame, fault_labels: pd.Series) -> Dict[str, float]:
        """
        使用互信息分析方法
        
        Args:
            data: 输入数据
            fault_labels: 故障标签
            
        Returns:
            Dict[str, float]: 因子权重
        """
        # 计算互信息
        mi_values = mutual_info_classif(data, fault_labels, random_state=42)
        
        # 创建权重字典
        weights = dict(zip(data.columns, mi_values))
        
        return weights
    
    async def _analyze_feature_importance(self, data: pd.DataFrame, fault_labels: pd.Series) -> Dict[str, float]:
        """
        使用特征重要性分析方法
        
        Args:
            data: 输入数据
            fault_labels: 故障标签
            
        Returns:
            Dict[str, float]: 因子权重
        """
        # 使用随机森林计算特征重要性
        rf = RandomForestClassifier(n_estimators=100, random_state=42)
        rf.fit(data, fault_labels)
        
        # 创建权重字典
        weights = dict(zip(data.columns, rf.feature_importances_))
        
        return weights
    
    async def _analyze_logistic_regression(self, data: pd.DataFrame, fault_labels: pd.Series) -> Dict[str, float]:
        """
        使用逻辑回归分析方法
        
        Args:
            data: 输入数据
            fault_labels: 故障标签
            
        Returns:
            Dict[str, float]: 因子权重
        """
        weights = {}
        
        try:
            # 标准化数据
            scaler = StandardScaler()
            X = scaler.fit_transform(data)
            
            # 添加常数项
            X = sm.add_constant(X)
            
            # 拟合逻辑回归模型
            model = sm.Logit(fault_labels, X)
            result = model.fit(disp=0)
            
            # 提取系数
            coefs = result.params[1:]  # 跳过常数项
            
            # 取绝对值作为权重
            weights = dict(zip(data.columns, np.abs(coefs)))
        
        except Exception as e:
            logger.warning(f"Error in logistic regression analysis: {e}")
            # 如果逻辑回归失败，使用相关性分析作为备选
            weights = await self._analyze_correlation(data, fault_labels)
        
        return weights
    
    async def _calculate_combined_weights(self, columns: List[str]) -> None:
        """
        计算综合权重
        
        Args:
            columns: 因子列
        """
        # 初始化
        self.factor_scores = {method: {} for method in self.methods}
        self.factor_rankings = {method: {} for method in self.methods}
        self.combined_weights = {}
        
        # 对每种方法的权重进行归一化和排序
        for method, weights in self.factor_weights.items():
            # 归一化权重
            total_weight = sum(weights.values())
            if total_weight > 0:
                normalized_weights = {col: weight / total_weight for col, weight in weights.items()}
            else:
                normalized_weights = {col: 1.0 / len(weights) for col in weights}
            
            self.factor_scores[method] = normalized_weights
            
            # 排序因子
            sorted_factors = sorted(normalized_weights.items(), key=lambda x: x[1], reverse=True)
            self.factor_rankings[method] = {col: i+1 for i, (col, _) in enumerate(sorted_factors)}
        
        # 计算综合权重
        for column in columns:
            # 计算每个因子在各方法中的平均得分
            scores = [self.factor_scores[method].get(column, 0) for method in self.methods]
            self.combined_weights[column] = sum(scores) / len(scores)
    
    def get_factor_weights(self, method: str = "combined") -> Dict[str, float]:
        """
        获取因子权重
        
        Args:
            method: 分析方法，默认为"combined"
            
        Returns:
            Dict[str, float]: 因子权重
        """
        if method == "combined":
            return self.combined_weights
        else:
            return self.factor_weights.get(method, {})
    
    def get_top_factors(self, n: int = 5, method: str = "combined") -> List[Tuple[str, float]]:
        """
        获取前N个重要因子
        
        Args:
            n: 返回的因子数量
            method: 分析方法，默认为"combined"
            
        Returns:
            List[Tuple[str, float]]: 因子及其权重
        """
        weights = self.get_factor_weights(method)
        sorted_factors = sorted(weights.items(), key=lambda x: x[1], reverse=True)
        return sorted_factors[:n]
    
    def calculate_weighted_probability(self, 
                                      data: pd.DataFrame, 
                                      thresholds: Dict[str, float] = None,
                                      method: str = "combined") -> pd.Series:
        """
        计算加权故障概率
        
        Args:
            data: 输入数据
            thresholds: 各因子的阈值
            method: 使用的权重方法
            
        Returns:
            pd.Series: 故障概率
        """
        weights = self.get_factor_weights(method)
        
        if not weights:
            return pd.Series([0.5] * len(data), index=data.index)
        
        # 初始化概率
        probabilities = pd.Series([0.0] * len(data), index=data.index)
        
        # 计算每个因子的贡献
        for column, weight in weights.items():
            if column not in data.columns:
                continue
            
            # 如果提供了阈值，计算超过阈值的概率贡献
            if thresholds and column in thresholds:
                threshold = thresholds[column]
                factor_prob = (data[column] > threshold).astype(float) * weight
            else:
                # 否则，将数据归一化到[0,1]区间作为概率贡献
                min_val = data[column].min()
                max_val = data[column].max()
                if max_val > min_val:
                    factor_prob = ((data[column] - min_val) / (max_val - min_val)) * weight
                else:
                    factor_prob = pd.Series([0.0] * len(data), index=data.index)
            
            probabilities += factor_prob
        
        # 归一化到[0,1]区间
        total_weight = sum(weight for column, weight in weights.items() if column in data.columns)
        if total_weight > 0:
            probabilities = probabilities / total_weight
        
        return probabilities
