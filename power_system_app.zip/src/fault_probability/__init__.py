"""
故障影响概率分析与建模模块初始化文件
"""
from importlib.metadata import version, PackageNotFoundError

try:
    __version__ = version("power_system_fault_prediction")
except PackageNotFoundError:
    __version__ = "0.1.0-dev"

from src.fault_probability.api.probability_api import ProbabilityAPI
from src.fault_probability.core.probability_model import ProbabilityModel
from src.fault_probability.core.factor_analyzer import FactorAnalyzer

__all__ = ["ProbabilityAPI", "ProbabilityModel", "FactorAnalyzer"]
