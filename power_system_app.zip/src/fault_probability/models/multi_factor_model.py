"""
多因子概率模型 - 基于多种因子计算故障概率
"""
import os
import json
import pickle
from typing import Any, Dict, List, Optional, Union, Tuple

import numpy as np
import pandas as pd
from loguru import logger
from sklearn.ensemble import RandomForestClassifier, GradientBoostingClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.naive_bayes import GaussianNB
from sklearn.svm import SVC
from sklearn.metrics import roc_auc_score, precision_recall_curve, auc
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler

from src.fault_probability.core.probability_model import ProbabilityModel, ProbabilityModelConfig, ProbabilityResult
from src.fault_probability.core.factor_analyzer import FactorAnalyzer


class MultiFactorProbabilityModel(ProbabilityModel):
    """多因子概率模型"""
    
    def __init__(self, config: ProbabilityModelConfig):
        """
        初始化多因子概率模型
        
        Args:
            config: 模型配置
        """
        super().__init__(config)
        
        # 获取配置参数
        self.algorithm = config.parameters.get("algorithm", "random_forest")
        self.feature_columns = config.parameters.get("feature_columns", [])
        self.fault_type_column = config.parameters.get("fault_type_column", "fault_type")
        self.test_size = config.parameters.get("test_size", 0.2)
        self.random_state = config.parameters.get("random_state", 42)
        self.threshold = config.parameters.get("threshold", 0.5)
        self.use_factor_weights = config.parameters.get("use_factor_weights", True)
        self.factor_analysis_methods = config.parameters.get("factor_analysis_methods", ["correlation", "mutual_info", "importance"])
        
        # 模型参数
        self.model_params = config.parameters.get("model_params", {})
        
        # 初始化模型和因子分析器
        self.model = None
        self.scaler = StandardScaler()
        self.factor_analyzer = FactorAnalyzer(methods=self.factor_analysis_methods)
        self.factor_weights = {}
        self.fault_types = []
        self.performance_metrics = {}
    
    async def calculate_probability(self, data: pd.DataFrame) -> ProbabilityResult:
        """
        计算故障概率
        
        Args:
            data: 输入数据DataFrame
            
        Returns:
            ProbabilityResult: 概率计算结果
        """
        try:
            # 检查模型是否已训练
            if self.model is None:
                return ProbabilityResult(
                    model_id=self.config.model_id,
                    success=False,
                    message="Model not trained yet",
                    probabilities={}
                )
            
            # 确定要使用的特征列
            if self.feature_columns:
                feature_cols = [col for col in self.feature_columns if col in data.columns]
            else:
                # 默认使用所有数值列，排除故障类型列
                exclude_cols = [self.fault_type_column]
                feature_cols = [col for col in data.select_dtypes(include=np.number).columns 
                               if col not in exclude_cols]
            
            if not feature_cols:
                return ProbabilityResult(
                    model_id=self.config.model_id,
                    success=False,
                    message="No feature columns found in data",
                    probabilities={}
                )
            
            # 提取特征
            X = data[feature_cols].values
            
            # 标准化特征
            X = self.scaler.transform(X)
            
            # 预测概率
            if hasattr(self.model, 'predict_proba'):
                y_proba = self.model.predict_proba(X)
                
                # 对于二分类问题，取正类的概率
                if len(self.fault_types) == 2:
                    fault_proba = y_proba[:, 1]
                else:
                    # 对于多分类问题，计算任意故障的概率（1 - 正常的概率）
                    normal_idx = self.fault_types.index("normal") if "normal" in self.fault_types else None
                    if normal_idx is not None:
                        fault_proba = 1 - y_proba[:, normal_idx]
                    else:
                        # 如果没有"normal"类，取所有概率的最大值
                        fault_proba = np.max(y_proba, axis=1)
            else:
                # 如果模型不支持概率输出，使用二分类预测
                y_pred = self.model.predict(X)
                fault_proba = y_pred.astype(float)
            
            # 计算每种故障类型的概率
            fault_type_probabilities = {}
            
            if len(self.fault_types) > 2 and hasattr(self.model, 'predict_proba'):
                for i, fault_type in enumerate(self.fault_types):
                    if fault_type != "normal":
                        fault_type_probabilities[fault_type] = float(np.mean(y_proba[:, i]))
            
            # 计算总体故障概率
            overall_probability = float(np.mean(fault_proba))
            
            # 如果使用因子权重，计算每个因子的贡献
            factors = {}
            if self.use_factor_weights and self.factor_weights:
                # 计算每个因子的归一化值
                for i, col in enumerate(feature_cols):
                    if col in self.factor_weights:
                        # 计算该因子的平均贡献
                        factor_contribution = np.mean(X[:, i]) * self.factor_weights[col]
                        factors[col] = float(factor_contribution)
            
            # 创建结果
            result = ProbabilityResult(
                model_id=self.config.model_id,
                success=True,
                message="Successfully calculated fault probability",
                probabilities={"overall": overall_probability, **fault_type_probabilities},
                confidence=float(self.performance_metrics.get("auc", 0.5)),
                factors=factors,
                metadata={
                    "feature_columns": feature_cols,
                    "algorithm": self.algorithm,
                    "threshold": self.threshold,
                    "fault_types": self.fault_types
                }
            )
            
            return result
        
        except Exception as e:
            logger.error(f"Error calculating fault probability: {e}")
            return ProbabilityResult(
                model_id=self.config.model_id,
                success=False,
                message=f"Error calculating fault probability: {str(e)}",
                probabilities={}
            )
    
    async def train(self, data: pd.DataFrame, fault_labels: pd.Series) -> Dict[str, Any]:
        """
        训练概率模型
        
        Args:
            data: 训练数据DataFrame
            fault_labels: 故障标签
            
        Returns:
            Dict[str, Any]: 训练结果
        """
        try:
            # 确定要使用的特征列
            if self.feature_columns:
                feature_cols = [col for col in self.feature_columns if col in data.columns]
            else:
                # 默认使用所有数值列，排除故障类型列
                exclude_cols = [self.fault_type_column]
                feature_cols = [col for col in data.select_dtypes(include=np.number).columns 
                               if col not in exclude_cols]
            
            if not feature_cols:
                return {
                    "success": False,
                    "message": "No feature columns found in data"
                }
            
            # 提取特征和标签
            X = data[feature_cols].values
            y = fault_labels.values
            
            # 记录故障类型
            self.fault_types = sorted(np.unique(y))
            
            # 标准化特征
            X = self.scaler.fit_transform(X)
            
            # 划分训练集和测试集
            X_train, X_test, y_train, y_test = train_test_split(
                X, y, test_size=self.test_size, random_state=self.random_state, stratify=y
            )
            
            # 创建并训练模型
            self.model = self._create_model()
            self.model.fit(X_train, y_train)
            
            # 评估模型
            if hasattr(self.model, 'predict_proba'):
                y_proba = self.model.predict_proba(X_test)
                
                # 计算AUC
                if len(self.fault_types) == 2:
                    # 二分类问题
                    auc_score = roc_auc_score(y_test, y_proba[:, 1])
                    
                    # 计算PR曲线下面积
                    precision, recall, _ = precision_recall_curve(y_test, y_proba[:, 1])
                    pr_auc = auc(recall, precision)
                    
                    self.performance_metrics = {
                        "auc": float(auc_score),
                        "pr_auc": float(pr_auc)
                    }
                else:
                    # 多分类问题，计算每个类别的AUC
                    auc_scores = {}
                    for i, fault_type in enumerate(self.fault_types):
                        try:
                            # 将当前类别作为正类，其他类别作为负类
                            binary_y_test = (y_test == fault_type).astype(int)
                            auc_scores[fault_type] = float(roc_auc_score(binary_y_test, y_proba[:, i]))
                        except Exception:
                            auc_scores[fault_type] = 0.5
                    
                    # 计算平均AUC
                    avg_auc = sum(auc_scores.values()) / len(auc_scores)
                    
                    self.performance_metrics = {
                        "auc": float(avg_auc),
                        "class_auc": auc_scores
                    }
            else:
                # 如果模型不支持概率输出，使用准确率
                y_pred = self.model.predict(X_test)
                accuracy = np.mean(y_pred == y_test)
                
                self.performance_metrics = {
                    "accuracy": float(accuracy)
                }
            
            # 分析因子影响
            if self.use_factor_weights:
                factor_analysis = await self.factor_analyzer.analyze_factors(data[feature_cols], fault_labels)
                
                if factor_analysis["success"]:
                    self.factor_weights = self.factor_analyzer.get_factor_weights("combined")
                    
                    # 添加因子分析结果到性能指标
                    self.performance_metrics["top_factors"] = [
                        {"name": name, "weight": float(weight)}
                        for name, weight in self.factor_analyzer.get_top_factors(10)
                    ]
            
            return {
                "success": True,
                "message": "Successfully trained probability model",
                "performance": self.performance_metrics,
                "feature_columns": feature_cols,
                "fault_types": self.fault_types,
                "factor_weights": self.factor_weights
            }
        
        except Exception as e:
            logger.error(f"Error training probability model: {e}")
            return {
                "success": False,
                "message": f"Error training probability model: {str(e)}"
            }
    
    def _create_model(self) -> Any:
        """
        创建指定算法的模型
        
        Returns:
            Any: 模型实例
        """
        if self.algorithm == "random_forest":
            return RandomForestClassifier(
                n_estimators=self.model_params.get("n_estimators", 100),
                max_depth=self.model_params.get("max_depth", None),
                min_samples_split=self.model_params.get("min_samples_split", 2),
                random_state=self.random_state
            )
        elif self.algorithm == "gradient_boosting":
            return GradientBoostingClassifier(
                n_estimators=self.model_params.get("n_estimators", 100),
                learning_rate=self.model_params.get("learning_rate", 0.1),
                max_depth=self.model_params.get("max_depth", 3),
                random_state=self.random_state
            )
        elif self.algorithm == "logistic_regression":
            return LogisticRegression(
                C=self.model_params.get("C", 1.0),
                solver=self.model_params.get("solver", "liblinear"),
                random_state=self.random_state
            )
        elif self.algorithm == "svm":
            return SVC(
                C=self.model_params.get("C", 1.0),
                kernel=self.model_params.get("kernel", "rbf"),
                probability=True,
                random_state=self.random_state
            )
        elif self.algorithm == "naive_bayes":
            return GaussianNB()
        else:
            raise ValueError(f"Unknown algorithm: {self.algorithm}")
    
    async def save_model(self, path: str) -> bool:
        """
        保存概率模型
        
        Args:
            path: 保存路径
            
        Returns:
            bool: 保存是否成功
        """
        try:
            os.makedirs(path, exist_ok=True)
            
            # 保存配置和元数据
            metadata = {
                "algorithm": self.algorithm,
                "feature_columns": self.feature_columns,
                "fault_type_column": self.fault_type_column,
                "test_size": self.test_size,
                "random_state": self.random_state,
                "threshold": self.threshold,
                "use_factor_weights": self.use_factor_weights,
                "factor_analysis_methods": self.factor_analysis_methods,
                "model_params": self.model_params,
                "fault_types": self.fault_types,
                "performance_metrics": self.performance_metrics,
                "factor_weights": self.factor_weights
            }
            
            with open(os.path.join(path, "metadata.json"), "w") as f:
                json.dump(metadata, f, indent=2, default=str)
            
            # 保存模型
            if self.model is not None:
                with open(os.path.join(path, "model.pkl"), "wb") as f:
                    pickle.dump(self.model, f)
            
            # 保存标准化器
            with open(os.path.join(path, "scaler.pkl"), "wb") as f:
                pickle.dump(self.scaler, f)
            
            return True
        
        except Exception as e:
            logger.error(f"Error saving probability model: {e}")
            return False
    
    async def load_model(self, path: str) -> bool:
        """
        加载概率模型
        
        Args:
            path: 加载路径
            
        Returns:
            bool: 加载是否成功
        """
        try:
            # 加载配置和元数据
            with open(os.path.join(path, "metadata.json"), "r") as f:
                metadata = json.load(f)
            
            self.algorithm = metadata.get("algorithm", "random_forest")
            self.feature_columns = metadata.get("feature_columns", [])
            self.fault_type_column = metadata.get("fault_type_column", "fault_type")
            self.test_size = metadata.get("test_size", 0.2)
            self.random_state = metadata.get("random_state", 42)
            self.threshold = metadata.get("threshold", 0.5)
            self.use_factor_weights = metadata.get("use_factor_weights", True)
            self.factor_analysis_methods = metadata.get("factor_analysis_methods", ["correlation", "mutual_info", "importance"])
            self.model_params = metadata.get("model_params", {})
            self.fault_types = metadata.get("fault_types", [])
            self.performance_metrics = metadata.get("performance_metrics", {})
            self.factor_weights = metadata.get("factor_weights", {})
            
            # 加载模型
            model_path = os.path.join(path, "model.pkl")
            if os.path.exists(model_path):
                with open(model_path, "rb") as f:
                    self.model = pickle.load(f)
            
            # 加载标准化器
            scaler_path = os.path.join(path, "scaler.pkl")
            if os.path.exists(scaler_path):
                with open(scaler_path, "rb") as f:
                    self.scaler = pickle.load(f)
            
            # 重新初始化因子分析器
            self.factor_analyzer = FactorAnalyzer(methods=self.factor_analysis_methods)
            
            return True
        
        except Exception as e:
            logger.error(f"Error loading probability model: {e}")
            return False
    
    def get_model_info(self) -> Dict[str, Any]:
        """
        获取模型信息
        
        Returns:
            Dict[str, Any]: 模型信息
        """
        return {
            "model_type": "multi_factor_probability_model",
            "algorithm": self.algorithm,
            "feature_columns": self.feature_columns,
            "fault_type_column": self.fault_type_column,
            "threshold": self.threshold,
            "fault_types": self.fault_types,
            "performance_metrics": self.performance_metrics,
            "top_factors": [
                {"name": name, "weight": float(weight)}
                for name, weight in sorted(self.factor_weights.items(), key=lambda x: x[1], reverse=True)[:5]
            ] if self.factor_weights else [],
            "is_trained": self.model is not None
        }
