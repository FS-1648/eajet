"""
数据源管理器，负责管理所有数据源
"""
from typing import Dict, List, Optional, Type, Any
import importlib
import inspect
import os
import json
from datetime import datetime

from loguru import logger
from pydantic import ValidationError

from src.data_acquisition.core.data_source import DataSource, DataSourceConfig, DataPoint


class DataSourceManager:
    """数据源管理器类"""
    
    def __init__(self):
        """初始化数据源管理器"""
        self.data_sources: Dict[str, DataSource] = {}
        self.data_source_types: Dict[str, Type[DataSource]] = {}
        
    def register_data_source_type(self, source_type: str, source_class: Type[DataSource]) -> None:
        """
        注册数据源类型
        
        Args:
            source_type: 数据源类型标识
            source_class: 数据源类
        """
        if not issubclass(source_class, DataSource):
            raise TypeError(f"Class {source_class.__name__} is not a subclass of DataSource")
        
        self.data_source_types[source_type] = source_class
        logger.info(f"Registered data source type: {source_type}")
    
    def discover_data_source_types(self, package_path: str = "src.data_acquisition.connectors") -> None:
        """
        自动发现并注册数据源类型
        
        Args:
            package_path: 数据源连接器包路径
        """
        try:
            package = importlib.import_module(package_path)
            package_dir = os.path.dirname(package.__file__)
            
            for filename in os.listdir(package_dir):
                if filename.endswith(".py") and not filename.startswith("__"):
                    module_name = filename[:-3]  # 去掉.py后缀
                    module_path = f"{package_path}.{module_name}"
                    
                    try:
                        module = importlib.import_module(module_path)
                        
                        for name, obj in inspect.getmembers(module):
                            if (inspect.isclass(obj) and 
                                issubclass(obj, DataSource) and 
                                obj != DataSource):
                                
                                # 使用模块名作为数据源类型标识
                                source_type = module_name.lower()
                                self.register_data_source_type(source_type, obj)
                    except (ImportError, AttributeError) as e:
                        logger.error(f"Error loading module {module_path}: {e}")
        except ImportError as e:
            logger.error(f"Error discovering data source types: {e}")
    
    async def create_data_source(self, config: DataSourceConfig) -> DataSource:
        """
        创建数据源实例
        
        Args:
            config: 数据源配置
            
        Returns:
            DataSource: 数据源实例
            
        Raises:
            ValueError: 如果数据源类型未注册
        """
        if config.source_type not in self.data_source_types:
            raise ValueError(f"Unknown data source type: {config.source_type}")
        
        source_class = self.data_source_types[config.source_type]
        data_source = source_class(config)
        
        return data_source
    
    async def add_data_source(self, config: DataSourceConfig) -> str:
        """
        添加数据源
        
        Args:
            config: 数据源配置
            
        Returns:
            str: 数据源ID
            
        Raises:
            ValueError: 如果数据源ID已存在
        """
        if config.source_id in self.data_sources:
            raise ValueError(f"Data source with ID {config.source_id} already exists")
        
        data_source = await self.create_data_source(config)
        self.data_sources[config.source_id] = data_source
        
        logger.info(f"Added data source: {config.source_id} ({config.source_type})")
        return config.source_id
    
    async def remove_data_source(self, source_id: str) -> bool:
        """
        移除数据源
        
        Args:
            source_id: 数据源ID
            
        Returns:
            bool: 是否成功移除
        """
        if source_id not in self.data_sources:
            logger.warning(f"Data source {source_id} not found")
            return False
        
        data_source = self.data_sources[source_id]
        if data_source.is_connected:
            await data_source.disconnect()
        
        del self.data_sources[source_id]
        logger.info(f"Removed data source: {source_id}")
        return True
    
    async def get_data_source(self, source_id: str) -> Optional[DataSource]:
        """
        获取数据源
        
        Args:
            source_id: 数据源ID
            
        Returns:
            Optional[DataSource]: 数据源实例，如果不存在则返回None
        """
        return self.data_sources.get(source_id)
    
    async def collect_data_from_source(self, 
                                     source_id: str,
                                     start_time: Optional[datetime] = None,
                                     end_time: Optional[datetime] = None,
                                     device_ids: Optional[List[str]] = None,
                                     parameters: Optional[List[str]] = None) -> List[DataPoint]:
        """
        从指定数据源采集数据
        
        Args:
            source_id: 数据源ID
            start_time: 开始时间
            end_time: 结束时间
            device_ids: 设备ID列表
            parameters: 参数列表
            
        Returns:
            List[DataPoint]: 采集到的数据点列表
            
        Raises:
            ValueError: 如果数据源不存在
        """
        data_source = await self.get_data_source(source_id)
        if not data_source:
            raise ValueError(f"Data source {source_id} not found")
        
        try:
            if not data_source.is_connected:
                connected = await data_source.connect()
                if not connected:
                    raise ConnectionError(f"Failed to connect to data source {source_id}")
            
            data_points = await data_source.collect_data(
                start_time=start_time,
                end_time=end_time,
                device_ids=device_ids,
                parameters=parameters
            )
            
            logger.info(f"Collected {len(data_points)} data points from source {source_id}")
            return data_points
        
        except Exception as e:
            logger.error(f"Error collecting data from source {source_id}: {e}")
            raise
        finally:
            if data_source.is_connected:
                await data_source.disconnect()
    
    async def collect_data_from_all_sources(self,
                                          start_time: Optional[datetime] = None,
                                          end_time: Optional[datetime] = None) -> Dict[str, List[DataPoint]]:
        """
        从所有启用的数据源采集数据
        
        Args:
            start_time: 开始时间
            end_time: 结束时间
            
        Returns:
            Dict[str, List[DataPoint]]: 按数据源ID组织的数据点列表
        """
        results: Dict[str, List[DataPoint]] = {}
        
        for source_id, data_source in self.data_sources.items():
            if not data_source.config.enabled:
                continue
            
            try:
                data_points = await self.collect_data_from_source(
                    source_id=source_id,
                    start_time=start_time,
                    end_time=end_time
                )
                results[source_id] = data_points
            except Exception as e:
                logger.error(f"Error collecting data from source {source_id}: {e}")
                results[source_id] = []
        
        return results
    
    async def test_data_source_connection(self, source_id: str) -> Dict[str, Any]:
        """
        测试数据源连接
        
        Args:
            source_id: 数据源ID
            
        Returns:
            Dict[str, Any]: 测试结果
            
        Raises:
            ValueError: 如果数据源不存在
        """
        data_source = await self.get_data_source(source_id)
        if not data_source:
            raise ValueError(f"Data source {source_id} not found")
        
        return await data_source.test_connection()
    
    async def get_all_data_sources(self) -> List[DataSourceConfig]:
        """
        获取所有数据源配置
        
        Returns:
            List[DataSourceConfig]: 数据源配置列表
        """
        return [data_source.config for data_source in self.data_sources.values()]
    
    async def get_available_data_source_types(self) -> List[str]:
        """
        获取可用的数据源类型
        
        Returns:
            List[str]: 数据源类型列表
        """
        return list(self.data_source_types.keys())
    
    def load_config_from_file(self, config_file: str) -> None:
        """
        从配置文件加载数据源配置
        
        Args:
            config_file: 配置文件路径
        """
        try:
            with open(config_file, 'r') as f:
                configs = json.load(f)
            
            for config_dict in configs:
                try:
                    config = DataSourceConfig(**config_dict)
                    self.add_data_source(config)
                except ValidationError as e:
                    logger.error(f"Invalid data source configuration: {e}")
        except Exception as e:
            logger.error(f"Error loading data source configurations: {e}")
    
    def save_config_to_file(self, config_file: str) -> None:
        """
        保存数据源配置到文件
        
        Args:
            config_file: 配置文件路径
        """
        try:
            configs = [data_source.config.dict() for data_source in self.data_sources.values()]
            with open(config_file, 'w') as f:
                json.dump(configs, f, indent=2, default=str)
            
            logger.info(f"Saved {len(configs)} data source configurations to {config_file}")
        except Exception as e:
            logger.error(f"Error saving data source configurations: {e}")
