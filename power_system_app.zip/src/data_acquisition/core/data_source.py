"""
数据源基类定义
"""
from abc import ABC, abstractmethod
from datetime import datetime
from typing import Any, Dict, List, Optional, Union

from pydantic import BaseModel


class DataSourceConfig(BaseModel):
    """数据源配置基类"""
    source_id: str
    source_type: str
    name: str
    description: Optional[str] = None
    connection_params: Dict[str, Any]
    collection_interval: Optional[int] = None  # 采集间隔，单位为秒
    enabled: bool = True
    metadata: Optional[Dict[str, Any]] = None


class DataPoint(BaseModel):
    """数据点基类"""
    source_id: str
    device_id: str
    timestamp: datetime
    values: Dict[str, Any]
    quality: Optional[str] = "good"
    metadata: Optional[Dict[str, Any]] = None


class DataSource(ABC):
    """数据源抽象基类"""
    
    def __init__(self, config: DataSourceConfig):
        """
        初始化数据源
        
        Args:
            config: 数据源配置
        """
        self.config = config
        self.is_connected = False
    
    @abstractmethod
    async def connect(self) -> bool:
        """
        连接到数据源
        
        Returns:
            bool: 连接是否成功
        """
        pass
    
    @abstractmethod
    async def disconnect(self) -> bool:
        """
        断开与数据源的连接
        
        Returns:
            bool: 断开连接是否成功
        """
        pass
    
    @abstractmethod
    async def collect_data(self, 
                          start_time: Optional[datetime] = None, 
                          end_time: Optional[datetime] = None,
                          device_ids: Optional[List[str]] = None,
                          parameters: Optional[List[str]] = None) -> List[DataPoint]:
        """
        从数据源采集数据
        
        Args:
            start_time: 开始时间
            end_time: 结束时间
            device_ids: 设备ID列表
            parameters: 参数列表
            
        Returns:
            List[DataPoint]: 采集到的数据点列表
        """
        pass
    
    @abstractmethod
    async def get_available_devices(self) -> List[Dict[str, Any]]:
        """
        获取可用设备列表
        
        Returns:
            List[Dict[str, Any]]: 设备信息列表
        """
        pass
    
    @abstractmethod
    async def get_available_parameters(self, device_id: Optional[str] = None) -> List[Dict[str, Any]]:
        """
        获取可用参数列表
        
        Args:
            device_id: 设备ID
            
        Returns:
            List[Dict[str, Any]]: 参数信息列表
        """
        pass
    
    @abstractmethod
    async def validate_connection(self) -> bool:
        """
        验证连接是否有效
        
        Returns:
            bool: 连接是否有效
        """
        pass
    
    async def test_connection(self) -> Dict[str, Any]:
        """
        测试连接并返回结果
        
        Returns:
            Dict[str, Any]: 测试结果
        """
        try:
            start_time = datetime.now()
            connected = await self.connect()
            if not connected:
                return {
                    "success": False,
                    "message": "Failed to connect to data source",
                    "elapsed_time": (datetime.now() - start_time).total_seconds()
                }
            
            valid = await self.validate_connection()
            if not valid:
                await self.disconnect()
                return {
                    "success": False,
                    "message": "Connection validation failed",
                    "elapsed_time": (datetime.now() - start_time).total_seconds()
                }
            
            devices = await self.get_available_devices()
            await self.disconnect()
            
            return {
                "success": True,
                "message": "Connection test successful",
                "device_count": len(devices),
                "elapsed_time": (datetime.now() - start_time).total_seconds()
            }
        except Exception as e:
            return {
                "success": False,
                "message": f"Connection test failed: {str(e)}",
                "elapsed_time": (datetime.now() - start_time).total_seconds()
            }
