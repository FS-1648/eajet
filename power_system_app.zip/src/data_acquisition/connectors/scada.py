"""
SCADA系统数据源连接器
"""
import asyncio
from datetime import datetime, timedelta
from typing import Any, Dict, List, Optional

import httpx
from loguru import logger

from src.data_acquisition.core.data_source import DataSource, DataSourceConfig, DataPoint


class ScadaDataSource(DataSource):
    """SCADA系统数据源实现"""
    
    def __init__(self, config: DataSourceConfig):
        """
        初始化SCADA数据源
        
        Args:
            config: 数据源配置
        """
        super().__init__(config)
        self.client: Optional[httpx.AsyncClient] = None
        self.auth_token: Optional[str] = None
        self.token_expiry: Optional[datetime] = None
    
    async def connect(self) -> bool:
        """
        连接到SCADA系统
        
        Returns:
            bool: 连接是否成功
        """
        try:
            # 创建HTTP客户端
            self.client = httpx.AsyncClient(
                base_url=self.config.connection_params.get("base_url"),
                timeout=self.config.connection_params.get("timeout", 30.0)
            )
            
            # 获取认证令牌
            auth_result = await self._authenticate()
            if not auth_result:
                logger.error(f"Failed to authenticate with SCADA system: {self.config.source_id}")
                return False
            
            self.is_connected = True
            logger.info(f"Connected to SCADA system: {self.config.source_id}")
            return True
        
        except Exception as e:
            logger.error(f"Error connecting to SCADA system: {e}")
            await self.disconnect()
            return False
    
    async def disconnect(self) -> bool:
        """
        断开与SCADA系统的连接
        
        Returns:
            bool: 断开连接是否成功
        """
        try:
            if self.client:
                await self.client.aclose()
                self.client = None
            
            self.auth_token = None
            self.token_expiry = None
            self.is_connected = False
            
            logger.info(f"Disconnected from SCADA system: {self.config.source_id}")
            return True
        
        except Exception as e:
            logger.error(f"Error disconnecting from SCADA system: {e}")
            return False
    
    async def collect_data(self, 
                          start_time: Optional[datetime] = None, 
                          end_time: Optional[datetime] = None,
                          device_ids: Optional[List[str]] = None,
                          parameters: Optional[List[str]] = None) -> List[DataPoint]:
        """
        从SCADA系统采集数据
        
        Args:
            start_time: 开始时间，默认为当前时间前1小时
            end_time: 结束时间，默认为当前时间
            device_ids: 设备ID列表，默认为所有设备
            parameters: 参数列表，默认为所有参数
            
        Returns:
            List[DataPoint]: 采集到的数据点列表
        """
        if not self.is_connected or not self.client:
            raise ConnectionError("Not connected to SCADA system")
        
        # 设置默认时间范围
        if not start_time:
            start_time = datetime.now() - timedelta(hours=1)
        if not end_time:
            end_time = datetime.now()
        
        # 检查并更新认证令牌
        if not self.auth_token or (self.token_expiry and datetime.now() >= self.token_expiry):
            auth_result = await self._authenticate()
            if not auth_result:
                raise ConnectionError("Failed to authenticate with SCADA system")
        
        try:
            # 构建请求参数
            params = {
                "start_time": start_time.isoformat(),
                "end_time": end_time.isoformat(),
            }
            
            if device_ids:
                params["device_ids"] = ",".join(device_ids)
            if parameters:
                params["parameters"] = ",".join(parameters)
            
            # 发送数据请求
            headers = {"Authorization": f"Bearer {self.auth_token}"}
            response = await self.client.get(
                "/api/data",
                params=params,
                headers=headers
            )
            
            response.raise_for_status()
            data = response.json()
            
            # 解析响应数据
            data_points = []
            for item in data.get("items", []):
                try:
                    data_point = DataPoint(
                        source_id=self.config.source_id,
                        device_id=item["device_id"],
                        timestamp=datetime.fromisoformat(item["timestamp"]),
                        values=item["values"],
                        quality=item.get("quality", "good"),
                        metadata=item.get("metadata")
                    )
                    data_points.append(data_point)
                except (KeyError, ValueError) as e:
                    logger.warning(f"Error parsing data point: {e}")
            
            logger.info(f"Collected {len(data_points)} data points from SCADA system: {self.config.source_id}")
            return data_points
        
        except httpx.HTTPStatusError as e:
            logger.error(f"HTTP error collecting data from SCADA system: {e.response.status_code} - {e.response.text}")
            raise
        except Exception as e:
            logger.error(f"Error collecting data from SCADA system: {e}")
            raise
    
    async def get_available_devices(self) -> List[Dict[str, Any]]:
        """
        获取SCADA系统中可用的设备列表
        
        Returns:
            List[Dict[str, Any]]: 设备信息列表
        """
        if not self.is_connected or not self.client:
            raise ConnectionError("Not connected to SCADA system")
        
        # 检查并更新认证令牌
        if not self.auth_token or (self.token_expiry and datetime.now() >= self.token_expiry):
            auth_result = await self._authenticate()
            if not auth_result:
                raise ConnectionError("Failed to authenticate with SCADA system")
        
        try:
            # 发送设备请求
            headers = {"Authorization": f"Bearer {self.auth_token}"}
            response = await self.client.get(
                "/api/devices",
                headers=headers
            )
            
            response.raise_for_status()
            data = response.json()
            
            return data.get("devices", [])
        
        except httpx.HTTPStatusError as e:
            logger.error(f"HTTP error getting devices from SCADA system: {e.response.status_code} - {e.response.text}")
            raise
        except Exception as e:
            logger.error(f"Error getting devices from SCADA system: {e}")
            raise
    
    async def get_available_parameters(self, device_id: Optional[str] = None) -> List[Dict[str, Any]]:
        """
        获取SCADA系统中可用的参数列表
        
        Args:
            device_id: 设备ID，如果提供则返回该设备的参数
            
        Returns:
            List[Dict[str, Any]]: 参数信息列表
        """
        if not self.is_connected or not self.client:
            raise ConnectionError("Not connected to SCADA system")
        
        # 检查并更新认证令牌
        if not self.auth_token or (self.token_expiry and datetime.now() >= self.token_expiry):
            auth_result = await self._authenticate()
            if not auth_result:
                raise ConnectionError("Failed to authenticate with SCADA system")
        
        try:
            # 构建请求参数
            params = {}
            if device_id:
                params["device_id"] = device_id
            
            # 发送参数请求
            headers = {"Authorization": f"Bearer {self.auth_token}"}
            response = await self.client.get(
                "/api/parameters",
                params=params,
                headers=headers
            )
            
            response.raise_for_status()
            data = response.json()
            
            return data.get("parameters", [])
        
        except httpx.HTTPStatusError as e:
            logger.error(f"HTTP error getting parameters from SCADA system: {e.response.status_code} - {e.response.text}")
            raise
        except Exception as e:
            logger.error(f"Error getting parameters from SCADA system: {e}")
            raise
    
    async def validate_connection(self) -> bool:
        """
        验证与SCADA系统的连接是否有效
        
        Returns:
            bool: 连接是否有效
        """
        if not self.is_connected or not self.client:
            return False
        
        try:
            # 检查并更新认证令牌
            if not self.auth_token or (self.token_expiry and datetime.now() >= self.token_expiry):
                auth_result = await self._authenticate()
                if not auth_result:
                    return False
            
            # 发送简单请求验证连接
            headers = {"Authorization": f"Bearer {self.auth_token}"}
            response = await self.client.get(
                "/api/status",
                headers=headers
            )
            
            response.raise_for_status()
            data = response.json()
            
            return data.get("status") == "ok"
        
        except Exception as e:
            logger.error(f"Error validating connection to SCADA system: {e}")
            return False
    
    async def _authenticate(self) -> bool:
        """
        向SCADA系统进行认证
        
        Returns:
            bool: 认证是否成功
        """
        if not self.client:
            return False
        
        try:
            # 获取认证参数
            username = self.config.connection_params.get("username")
            password = self.config.connection_params.get("password")
            
            if not username or not password:
                logger.error("Missing authentication credentials for SCADA system")
                return False
            
            # 发送认证请求
            response = await self.client.post(
                "/api/auth",
                json={
                    "username": username,
                    "password": password
                }
            )
            
            response.raise_for_status()
            data = response.json()
            
            # 保存认证令牌
            self.auth_token = data.get("token")
            
            # 设置令牌过期时间
            expires_in = data.get("expires_in", 3600)  # 默认1小时
            self.token_expiry = datetime.now() + timedelta(seconds=expires_in)
            
            return bool(self.auth_token)
        
        except httpx.HTTPStatusError as e:
            logger.error(f"HTTP error authenticating with SCADA system: {e.response.status_code} - {e.response.text}")
            return False
        except Exception as e:
            logger.error(f"Error authenticating with SCADA system: {e}")
            return False
