"""
数据采集与接入模块初始化文件
"""
from importlib.metadata import version, PackageNotFoundError

try:
    __version__ = version("power_system_fault_prediction")
except PackageNotFoundError:
    __version__ = "0.1.0-dev"

from src.data_acquisition.api.data_source import DataSourceAPI
from src.data_acquisition.core.data_source_manager import DataSourceManager

__all__ = ["DataSourceAPI", "DataSourceManager"]
