"""
数据采集模块API接口
"""
from typing import Dict, List, Optional, Any
from datetime import datetime

from fastapi import APIRouter, HTTPException, Depends, Query, Path
from pydantic import BaseModel

from src.data_acquisition.core.data_source import DataSourceConfig, DataPoint
from src.data_acquisition.core.data_source_manager import DataSourceManager


# 依赖注入函数，获取数据源管理器实例
async def get_data_source_manager() -> DataSourceManager:
    """获取数据源管理器实例"""
    manager = DataSourceManager()
    # 自动发现数据源类型
    manager.discover_data_source_types()
    return manager


class DataSourceAPI:
    """数据源API类"""
    
    def __init__(self, router: APIRouter):
        """
        初始化数据源API
        
        Args:
            router: FastAPI路由器
        """
        self.router = router
        self._register_routes()
    
    def _register_routes(self) -> None:
        """注册API路由"""
        
        # 数据源类型相关接口
        @self.router.get("/types", response_model=List[str])
        async def get_data_source_types(
            manager: DataSourceManager = Depends(get_data_source_manager)
        ):
            """获取所有可用的数据源类型"""
            return await manager.get_available_data_source_types()
        
        # 数据源管理接口
        @self.router.get("/", response_model=List[DataSourceConfig])
        async def get_all_data_sources(
            manager: DataSourceManager = Depends(get_data_source_manager)
        ):
            """获取所有数据源配置"""
            return await manager.get_all_data_sources()
        
        @self.router.post("/", response_model=str)
        async def add_data_source(
            config: DataSourceConfig,
            manager: DataSourceManager = Depends(get_data_source_manager)
        ):
            """添加数据源"""
            try:
                source_id = await manager.add_data_source(config)
                return source_id
            except ValueError as e:
                raise HTTPException(status_code=400, detail=str(e))
            except Exception as e:
                raise HTTPException(status_code=500, detail=f"Failed to add data source: {str(e)}")
        
        @self.router.get("/{source_id}", response_model=DataSourceConfig)
        async def get_data_source(
            source_id: str = Path(..., description="数据源ID"),
            manager: DataSourceManager = Depends(get_data_source_manager)
        ):
            """获取指定数据源的配置"""
            data_source = await manager.get_data_source(source_id)
            if not data_source:
                raise HTTPException(status_code=404, detail=f"Data source {source_id} not found")
            return data_source.config
        
        @self.router.delete("/{source_id}", response_model=bool)
        async def remove_data_source(
            source_id: str = Path(..., description="数据源ID"),
            manager: DataSourceManager = Depends(get_data_source_manager)
        ):
            """移除数据源"""
            result = await manager.remove_data_source(source_id)
            if not result:
                raise HTTPException(status_code=404, detail=f"Data source {source_id} not found")
            return result
        
        # 数据采集接口
        @self.router.get("/{source_id}/data", response_model=List[DataPoint])
        async def collect_data(
            source_id: str = Path(..., description="数据源ID"),
            start_time: Optional[datetime] = Query(None, description="开始时间"),
            end_time: Optional[datetime] = Query(None, description="结束时间"),
            device_ids: Optional[List[str]] = Query(None, description="设备ID列表"),
            parameters: Optional[List[str]] = Query(None, description="参数列表"),
            manager: DataSourceManager = Depends(get_data_source_manager)
        ):
            """从指定数据源采集数据"""
            try:
                data_points = await manager.collect_data_from_source(
                    source_id=source_id,
                    start_time=start_time,
                    end_time=end_time,
                    device_ids=device_ids,
                    parameters=parameters
                )
                return data_points
            except ValueError as e:
                raise HTTPException(status_code=404, detail=str(e))
            except ConnectionError as e:
                raise HTTPException(status_code=503, detail=str(e))
            except Exception as e:
                raise HTTPException(status_code=500, detail=f"Failed to collect data: {str(e)}")
        
        # 数据源测试接口
        @self.router.post("/{source_id}/test", response_model=Dict[str, Any])
        async def test_data_source(
            source_id: str = Path(..., description="数据源ID"),
            manager: DataSourceManager = Depends(get_data_source_manager)
        ):
            """测试数据源连接"""
            try:
                result = await manager.test_data_source_connection(source_id)
                return result
            except ValueError as e:
                raise HTTPException(status_code=404, detail=str(e))
            except Exception as e:
                raise HTTPException(status_code=500, detail=f"Failed to test data source: {str(e)}")
        
        # 设备和参数查询接口
        @self.router.get("/{source_id}/devices", response_model=List[Dict[str, Any]])
        async def get_devices(
            source_id: str = Path(..., description="数据源ID"),
            manager: DataSourceManager = Depends(get_data_source_manager)
        ):
            """获取指定数据源的可用设备列表"""
            try:
                data_source = await manager.get_data_source(source_id)
                if not data_source:
                    raise HTTPException(status_code=404, detail=f"Data source {source_id} not found")
                
                connected = await data_source.connect()
                if not connected:
                    raise HTTPException(status_code=503, detail=f"Failed to connect to data source {source_id}")
                
                try:
                    devices = await data_source.get_available_devices()
                    return devices
                finally:
                    await data_source.disconnect()
            except Exception as e:
                raise HTTPException(status_code=500, detail=f"Failed to get devices: {str(e)}")
        
        @self.router.get("/{source_id}/parameters", response_model=List[Dict[str, Any]])
        async def get_parameters(
            source_id: str = Path(..., description="数据源ID"),
            device_id: Optional[str] = Query(None, description="设备ID"),
            manager: DataSourceManager = Depends(get_data_source_manager)
        ):
            """获取指定数据源的可用参数列表"""
            try:
                data_source = await manager.get_data_source(source_id)
                if not data_source:
                    raise HTTPException(status_code=404, detail=f"Data source {source_id} not found")
                
                connected = await data_source.connect()
                if not connected:
                    raise HTTPException(status_code=503, detail=f"Failed to connect to data source {source_id}")
                
                try:
                    parameters = await data_source.get_available_parameters(device_id)
                    return parameters
                finally:
                    await data_source.disconnect()
            except Exception as e:
                raise HTTPException(status_code=500, detail=f"Failed to get parameters: {str(e)}")
