"""
标准化处理器 - 实现数据标准化
"""
import os
import json
from typing import Any, Dict, List, Optional, Union

import numpy as np
import pandas as pd
from loguru import logger
from sklearn.preprocessing import StandardScaler, MinMaxScaler, RobustScaler

from src.data_preprocessing.core.data_processor import DataProcessor, PreprocessingConfig, PreprocessingResult


class DataNormalizer(DataProcessor):
    """数据标准化处理器"""
    
    def __init__(self, config: PreprocessingConfig):
        """
        初始化数据标准化处理器
        
        Args:
            config: 处理器配置
        """
        super().__init__(config)
        self.scalers: Dict[str, Any] = {}
        self.fitted_columns: List[str] = []
        
        # 获取配置参数
        self.method = config.parameters.get("method", "standard")  # standard, minmax, robust
        self.target_columns = config.parameters.get("target_columns", [])
        self.exclude_columns = config.parameters.get("exclude_columns", [])
        self.group_by_column = config.parameters.get("group_by_column", None)
        self.clip_values = config.parameters.get("clip_values", False)
        self.clip_min = config.parameters.get("clip_min", -5.0)
        self.clip_max = config.parameters.get("clip_max", 5.0)
    
    async def process(self, data: pd.DataFrame) -> tuple[pd.DataFrame, PreprocessingResult]:
        """
        对数据进行标准化处理
        
        Args:
            data: 输入数据DataFrame
            
        Returns:
            tuple: (处理后的数据DataFrame, 处理结果)
        """
        try:
            # 复制数据，避免修改原始数据
            processed_data = data.copy()
            
            # 确定要处理的列
            if self.target_columns:
                columns_to_normalize = [col for col in self.target_columns if col in processed_data.columns]
            else:
                # 默认处理所有数值列
                columns_to_normalize = processed_data.select_dtypes(include=np.number).columns.tolist()
                # 排除指定列
                columns_to_normalize = [col for col in columns_to_normalize if col not in self.exclude_columns]
            
            # 如果没有要处理的列，直接返回
            if not columns_to_normalize:
                return processed_data, PreprocessingResult(
                    processor_id=self.config.processor_id,
                    success=True,
                    message="No columns to normalize",
                    stats={"normalized_columns": []}
                )
            
            # 如果按组进行标准化
            if self.group_by_column and self.group_by_column in processed_data.columns:
                groups = processed_data[self.group_by_column].unique()
                
                for group in groups:
                    group_mask = processed_data[self.group_by_column] == group
                    group_key = str(group)
                    
                    # 如果没有该组的scaler，创建并训练
                    if group_key not in self.scalers:
                        self._create_and_fit_scaler(group_key, processed_data.loc[group_mask, columns_to_normalize])
                    
                    # 应用标准化
                    scaler = self.scalers[group_key]
                    normalized_values = scaler.transform(processed_data.loc[group_mask, columns_to_normalize])
                    
                    # 如果需要裁剪值
                    if self.clip_values:
                        normalized_values = np.clip(normalized_values, self.clip_min, self.clip_max)
                    
                    processed_data.loc[group_mask, columns_to_normalize] = normalized_values
            else:
                # 全局标准化
                if "global" not in self.scalers:
                    self._create_and_fit_scaler("global", processed_data[columns_to_normalize])
                
                # 应用标准化
                scaler = self.scalers["global"]
                normalized_values = scaler.transform(processed_data[columns_to_normalize])
                
                # 如果需要裁剪值
                if self.clip_values:
                    normalized_values = np.clip(normalized_values, self.clip_min, self.clip_max)
                
                processed_data[columns_to_normalize] = normalized_values
            
            # 计算处理统计信息
            stats = {
                "normalized_columns": columns_to_normalize,
                "normalization_method": self.method,
                "group_by_column": self.group_by_column,
                "groups_count": len(self.scalers) if self.group_by_column else 1
            }
            
            result = PreprocessingResult(
                processor_id=self.config.processor_id,
                success=True,
                message="Successfully normalized data",
                stats=stats
            )
            
            return processed_data, result
        
        except Exception as e:
            logger.error(f"Error normalizing data: {e}")
            return data, PreprocessingResult(
                processor_id=self.config.processor_id,
                success=False,
                message=f"Error normalizing data: {str(e)}"
            )
    
    async def fit(self, data: pd.DataFrame) -> PreprocessingResult:
        """
        训练标准化处理器
        
        Args:
            data: 训练数据DataFrame
            
        Returns:
            PreprocessingResult: 训练结果
        """
        try:
            # 重置scalers
            self.scalers = {}
            self.fitted_columns = []
            
            # 确定要处理的列
            if self.target_columns:
                columns_to_normalize = [col for col in self.target_columns if col in data.columns]
            else:
                # 默认处理所有数值列
                columns_to_normalize = data.select_dtypes(include=np.number).columns.tolist()
                # 排除指定列
                columns_to_normalize = [col for col in columns_to_normalize if col not in self.exclude_columns]
            
            # 如果没有要处理的列，直接返回
            if not columns_to_normalize:
                return PreprocessingResult(
                    processor_id=self.config.processor_id,
                    success=True,
                    message="No columns to fit for normalization",
                    stats={"fitted_columns": []}
                )
            
            # 如果按组进行标准化
            if self.group_by_column and self.group_by_column in data.columns:
                groups = data[self.group_by_column].unique()
                
                for group in groups:
                    group_mask = data[self.group_by_column] == group
                    group_key = str(group)
                    
                    self._create_and_fit_scaler(group_key, data.loc[group_mask, columns_to_normalize])
            else:
                # 全局标准化
                self._create_and_fit_scaler("global", data[columns_to_normalize])
            
            self.fitted_columns = columns_to_normalize
            
            return PreprocessingResult(
                processor_id=self.config.processor_id,
                success=True,
                message="Successfully fitted normalizer",
                stats={
                    "fitted_columns": columns_to_normalize,
                    "normalization_method": self.method,
                    "group_by_column": self.group_by_column,
                    "groups_count": len(self.scalers) if self.group_by_column else 1
                }
            )
        
        except Exception as e:
            logger.error(f"Error fitting normalizer: {e}")
            return PreprocessingResult(
                processor_id=self.config.processor_id,
                success=False,
                message=f"Error fitting normalizer: {str(e)}"
            )
    
    def _create_and_fit_scaler(self, key: str, data: pd.DataFrame) -> None:
        """
        创建并训练指定类型的scaler
        
        Args:
            key: scaler的键名
            data: 训练数据
        """
        if self.method == "standard":
            scaler = StandardScaler()
        elif self.method == "minmax":
            scaler = MinMaxScaler()
        elif self.method == "robust":
            scaler = RobustScaler()
        else:
            raise ValueError(f"Unknown normalization method: {self.method}")
        
        scaler.fit(data)
        self.scalers[key] = scaler
    
    async def save_state(self, path: str) -> bool:
        """
        保存处理器状态
        
        Args:
            path: 保存路径
            
        Returns:
            bool: 保存是否成功
        """
        try:
            os.makedirs(path, exist_ok=True)
            
            # 保存配置和元数据
            metadata = {
                "fitted_columns": self.fitted_columns,
                "method": self.method,
                "target_columns": self.target_columns,
                "exclude_columns": self.exclude_columns,
                "group_by_column": self.group_by_column,
                "clip_values": self.clip_values,
                "clip_min": self.clip_min,
                "clip_max": self.clip_max
            }
            
            with open(os.path.join(path, "metadata.json"), "w") as f:
                json.dump(metadata, f, indent=2, default=str)
            
            # 保存每个scaler的参数
            scalers_data = {}
            
            for key, scaler in self.scalers.items():
                scaler_data = {}
                
                if hasattr(scaler, "mean_") and hasattr(scaler, "scale_"):
                    # StandardScaler
                    scaler_data["mean"] = scaler.mean_.tolist()
                    scaler_data["scale"] = scaler.scale_.tolist()
                elif hasattr(scaler, "min_") and hasattr(scaler, "scale_"):
                    # MinMaxScaler
                    scaler_data["min"] = scaler.min_.tolist()
                    scaler_data["scale"] = scaler.scale_.tolist()
                elif hasattr(scaler, "center_") and hasattr(scaler, "scale_"):
                    # RobustScaler
                    scaler_data["center"] = scaler.center_.tolist()
                    scaler_data["scale"] = scaler.scale_.tolist()
                
                scalers_data[key] = scaler_data
            
            with open(os.path.join(path, "scalers.json"), "w") as f:
                json.dump(scalers_data, f, indent=2, default=str)
            
            return True
        
        except Exception as e:
            logger.error(f"Error saving normalizer state: {e}")
            return False
    
    async def load_state(self, path: str) -> bool:
        """
        加载处理器状态
        
        Args:
            path: 加载路径
            
        Returns:
            bool: 加载是否成功
        """
        try:
            # 加载配置和元数据
            with open(os.path.join(path, "metadata.json"), "r") as f:
                metadata = json.load(f)
            
            self.fitted_columns = metadata.get("fitted_columns", [])
            self.method = metadata.get("method", "standard")
            self.target_columns = metadata.get("target_columns", [])
            self.exclude_columns = metadata.get("exclude_columns", [])
            self.group_by_column = metadata.get("group_by_column")
            self.clip_values = metadata.get("clip_values", False)
            self.clip_min = metadata.get("clip_min", -5.0)
            self.clip_max = metadata.get("clip_max", 5.0)
            
            # 加载scaler参数
            with open(os.path.join(path, "scalers.json"), "r") as f:
                scalers_data = json.load(f)
            
            self.scalers = {}
            
            for key, scaler_data in scalers_data.items():
                if self.method == "standard":
                    scaler = StandardScaler()
                    if "mean" in scaler_data and "scale" in scaler_data:
                        scaler.mean_ = np.array(scaler_data["mean"])
                        scaler.scale_ = np.array(scaler_data["scale"])
                        scaler.var_ = np.square(scaler.scale_)
                        self.scalers[key] = scaler
                
                elif self.method == "minmax":
                    scaler = MinMaxScaler()
                    if "min" in scaler_data and "scale" in scaler_data:
                        scaler.min_ = np.array(scaler_data["min"])
                        scaler.scale_ = np.array(scaler_data["scale"])
                        scaler.data_min_ = np.array(scaler_data["min"])
                        scaler.data_max_ = scaler.data_min_ + 1.0 / scaler.scale_
                        scaler.data_range_ = scaler.data_max_ - scaler.data_min_
                        self.scalers[key] = scaler
                
                elif self.method == "robust":
                    scaler = RobustScaler()
                    if "center" in scaler_data and "scale" in scaler_data:
                        scaler.center_ = np.array(scaler_data["center"])
                        scaler.scale_ = np.array(scaler_data["scale"])
                        self.scalers[key] = scaler
            
            return True
        
        except Exception as e:
            logger.error(f"Error loading normalizer state: {e}")
            return False
    
    def get_metadata(self) -> Dict[str, Any]:
        """
        获取处理器元数据
        
        Returns:
            Dict[str, Any]: 处理器元数据
        """
        return {
            "processor_type": "data_normalizer",
            "method": self.method,
            "fitted_columns": self.fitted_columns,
            "target_columns": self.target_columns,
            "exclude_columns": self.exclude_columns,
            "group_by_column": self.group_by_column,
            "clip_values": self.clip_values,
            "clip_min": self.clip_min,
            "clip_max": self.clip_max,
            "scalers_count": len(self.scalers)
        }
