"""
预处理流水线管理器
"""
from typing import Dict, List, Optional, Type, Any
import importlib
import inspect
import os
import json
import asyncio

import pandas as pd
from loguru import logger
from pydantic import ValidationError

from src.data_preprocessing.core.data_processor import DataProcessor, PreprocessingConfig, PreprocessingResult


class PreprocessingPipeline:
    """数据预处理流水线类"""
    
    def __init__(self, name: str = "default_pipeline"):
        """
        初始化预处理流水线
        
        Args:
            name: 流水线名称
        """
        self.name = name
        self.processors: Dict[str, DataProcessor] = {}
        self.processor_types: Dict[str, Type[DataProcessor]] = {}
        self.execution_order: List[str] = []
    
    def register_processor_type(self, processor_type: str, processor_class: Type[DataProcessor]) -> None:
        """
        注册处理器类型
        
        Args:
            processor_type: 处理器类型标识
            processor_class: 处理器类
        """
        if not issubclass(processor_class, DataProcessor):
            raise TypeError(f"Class {processor_class.__name__} is not a subclass of DataProcessor")
        
        self.processor_types[processor_type] = processor_class
        logger.info(f"Registered processor type: {processor_type}")
    
    def discover_processor_types(self, package_paths: List[str] = None) -> None:
        """
        自动发现并注册处理器类型
        
        Args:
            package_paths: 处理器包路径列表，默认为清洗、标准化和特征提取模块
        """
        if package_paths is None:
            package_paths = [
                "src.data_preprocessing.cleaners",
                "src.data_preprocessing.normalizers",
                "src.data_preprocessing.feature_extractors"
            ]
        
        for package_path in package_paths:
            try:
                package = importlib.import_module(package_path)
                package_dir = os.path.dirname(package.__file__)
                
                for filename in os.listdir(package_dir):
                    if filename.endswith(".py") and not filename.startswith("__"):
                        module_name = filename[:-3]  # 去掉.py后缀
                        module_path = f"{package_path}.{module_name}"
                        
                        try:
                            module = importlib.import_module(module_path)
                            
                            for name, obj in inspect.getmembers(module):
                                if (inspect.isclass(obj) and 
                                    issubclass(obj, DataProcessor) and 
                                    obj != DataProcessor):
                                    
                                    # 使用模块名作为处理器类型标识
                                    processor_type = module_name.lower()
                                    self.register_processor_type(processor_type, obj)
                        except (ImportError, AttributeError) as e:
                            logger.error(f"Error loading module {module_path}: {e}")
            except ImportError as e:
                logger.error(f"Error discovering processor types in {package_path}: {e}")
    
    async def create_processor(self, config: PreprocessingConfig) -> DataProcessor:
        """
        创建处理器实例
        
        Args:
            config: 处理器配置
            
        Returns:
            DataProcessor: 处理器实例
            
        Raises:
            ValueError: 如果处理器类型未注册
        """
        if config.processor_type not in self.processor_types:
            raise ValueError(f"Unknown processor type: {config.processor_type}")
        
        processor_class = self.processor_types[config.processor_type]
        processor = processor_class(config)
        
        return processor
    
    async def add_processor(self, config: PreprocessingConfig, position: Optional[int] = None) -> str:
        """
        添加处理器到流水线
        
        Args:
            config: 处理器配置
            position: 处理器在执行顺序中的位置，默认添加到末尾
            
        Returns:
            str: 处理器ID
            
        Raises:
            ValueError: 如果处理器ID已存在
        """
        if config.processor_id in self.processors:
            raise ValueError(f"Processor with ID {config.processor_id} already exists")
        
        processor = await self.create_processor(config)
        self.processors[config.processor_id] = processor
        
        # 更新执行顺序
        if position is not None:
            self.execution_order.insert(position, config.processor_id)
        else:
            self.execution_order.append(config.processor_id)
        
        logger.info(f"Added processor: {config.processor_id} ({config.processor_type}) at position {position if position is not None else len(self.execution_order) - 1}")
        return config.processor_id
    
    async def remove_processor(self, processor_id: str) -> bool:
        """
        从流水线移除处理器
        
        Args:
            processor_id: 处理器ID
            
        Returns:
            bool: 是否成功移除
        """
        if processor_id not in self.processors:
            logger.warning(f"Processor {processor_id} not found")
            return False
        
        del self.processors[processor_id]
        
        # 更新执行顺序
        if processor_id in self.execution_order:
            self.execution_order.remove(processor_id)
        
        logger.info(f"Removed processor: {processor_id}")
        return True
    
    async def get_processor(self, processor_id: str) -> Optional[DataProcessor]:
        """
        获取处理器
        
        Args:
            processor_id: 处理器ID
            
        Returns:
            Optional[DataProcessor]: 处理器实例，如果不存在则返回None
        """
        return self.processors.get(processor_id)
    
    async def reorder_processors(self, new_order: List[str]) -> bool:
        """
        重新排序处理器执行顺序
        
        Args:
            new_order: 新的处理器ID顺序
            
        Returns:
            bool: 是否成功重新排序
            
        Raises:
            ValueError: 如果新顺序包含不存在的处理器ID或缺少现有处理器ID
        """
        # 检查新顺序是否包含所有现有处理器
        if set(new_order) != set(self.execution_order):
            missing = set(self.execution_order) - set(new_order)
            extra = set(new_order) - set(self.execution_order)
            
            error_msg = ""
            if missing:
                error_msg += f"Missing processor IDs: {missing}. "
            if extra:
                error_msg += f"Unknown processor IDs: {extra}."
            
            raise ValueError(error_msg)
        
        self.execution_order = new_order
        logger.info(f"Reordered processors: {new_order}")
        return True
    
    async def process_data(self, data: pd.DataFrame) -> tuple[pd.DataFrame, Dict[str, PreprocessingResult]]:
        """
        按顺序执行所有处理器处理数据
        
        Args:
            data: 输入数据DataFrame
            
        Returns:
            tuple: (处理后的数据DataFrame, 处理结果字典)
        """
        results: Dict[str, PreprocessingResult] = {}
        processed_data = data.copy()
        
        for processor_id in self.execution_order:
            processor = self.processors.get(processor_id)
            if not processor or not processor.config.enabled:
                continue
            
            try:
                logger.info(f"Processing data with processor: {processor_id}")
                processed_data, result = await processor.process(processed_data)
                results[processor_id] = result
                
                if not result.success:
                    logger.warning(f"Processor {processor_id} reported failure: {result.message}")
            except Exception as e:
                logger.error(f"Error processing data with processor {processor_id}: {e}")
                results[processor_id] = PreprocessingResult(
                    processor_id=processor_id,
                    success=False,
                    message=f"Error: {str(e)}"
                )
        
        return processed_data, results
    
    async def fit_processors(self, data: pd.DataFrame) -> Dict[str, PreprocessingResult]:
        """
        训练所有处理器
        
        Args:
            data: 训练数据DataFrame
            
        Returns:
            Dict[str, PreprocessingResult]: 训练结果字典
        """
        results: Dict[str, PreprocessingResult] = {}
        
        for processor_id in self.execution_order:
            processor = self.processors.get(processor_id)
            if not processor or not processor.config.enabled:
                continue
            
            try:
                logger.info(f"Fitting processor: {processor_id}")
                result = await processor.fit(data)
                results[processor_id] = result
                
                if not result.success:
                    logger.warning(f"Processor {processor_id} fitting failed: {result.message}")
            except Exception as e:
                logger.error(f"Error fitting processor {processor_id}: {e}")
                results[processor_id] = PreprocessingResult(
                    processor_id=processor_id,
                    success=False,
                    message=f"Error: {str(e)}"
                )
        
        return results
    
    async def save_pipeline_state(self, directory: str) -> bool:
        """
        保存流水线状态
        
        Args:
            directory: 保存目录
            
        Returns:
            bool: 保存是否成功
        """
        try:
            os.makedirs(directory, exist_ok=True)
            
            # 保存流水线配置
            pipeline_config = {
                "name": self.name,
                "execution_order": self.execution_order,
                "processors": [processor.config.dict() for processor in self.processors.values()]
            }
            
            with open(os.path.join(directory, "pipeline_config.json"), "w") as f:
                json.dump(pipeline_config, f, indent=2, default=str)
            
            # 保存各处理器状态
            for processor_id, processor in self.processors.items():
                processor_dir = os.path.join(directory, processor_id)
                os.makedirs(processor_dir, exist_ok=True)
                
                success = await processor.save_state(processor_dir)
                if not success:
                    logger.warning(f"Failed to save state for processor {processor_id}")
            
            logger.info(f"Saved pipeline state to {directory}")
            return True
        
        except Exception as e:
            logger.error(f"Error saving pipeline state: {e}")
            return False
    
    async def load_pipeline_state(self, directory: str) -> bool:
        """
        加载流水线状态
        
        Args:
            directory: 加载目录
            
        Returns:
            bool: 加载是否成功
        """
        try:
            # 加载流水线配置
            with open(os.path.join(directory, "pipeline_config.json"), "r") as f:
                pipeline_config = json.load(f)
            
            self.name = pipeline_config["name"]
            self.execution_order = pipeline_config["execution_order"]
            
            # 清空现有处理器
            self.processors = {}
            
            # 创建并加载各处理器
            for processor_config_dict in pipeline_config["processors"]:
                try:
                    processor_config = PreprocessingConfig(**processor_config_dict)
                    processor = await self.create_processor(processor_config)
                    
                    processor_dir = os.path.join(directory, processor_config.processor_id)
                    success = await processor.load_state(processor_dir)
                    
                    if not success:
                        logger.warning(f"Failed to load state for processor {processor_config.processor_id}")
                    
                    self.processors[processor_config.processor_id] = processor
                
                except ValidationError as e:
                    logger.error(f"Invalid processor configuration: {e}")
                except Exception as e:
                    logger.error(f"Error loading processor: {e}")
            
            logger.info(f"Loaded pipeline state from {directory}")
            return True
        
        except Exception as e:
            logger.error(f"Error loading pipeline state: {e}")
            return False
    
    def get_pipeline_info(self) -> Dict[str, Any]:
        """
        获取流水线信息
        
        Returns:
            Dict[str, Any]: 流水线信息
        """
        return {
            "name": self.name,
            "processor_count": len(self.processors),
            "execution_order": self.execution_order,
            "processors": {
                processor_id: {
                    "type": processor.config.processor_type,
                    "name": processor.config.name,
                    "enabled": processor.config.enabled,
                    "metadata": processor.get_metadata()
                }
                for processor_id, processor in self.processors.items()
            }
        }
