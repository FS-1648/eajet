"""
数据预处理基类定义
"""
from abc import ABC, abstractmethod
from typing import Any, Dict, List, Optional, Union

import numpy as np
import pandas as pd
from pydantic import BaseModel


class PreprocessingConfig(BaseModel):
    """预处理配置基类"""
    processor_id: str
    processor_type: str
    name: str
    description: Optional[str] = None
    parameters: Dict[str, Any] = {}
    enabled: bool = True
    metadata: Optional[Dict[str, Any]] = None


class PreprocessingResult(BaseModel):
    """预处理结果基类"""
    processor_id: str
    success: bool
    message: Optional[str] = None
    stats: Optional[Dict[str, Any]] = None
    metadata: Optional[Dict[str, Any]] = None


class DataProcessor(ABC):
    """数据处理器抽象基类"""
    
    def __init__(self, config: PreprocessingConfig):
        """
        初始化数据处理器
        
        Args:
            config: 处理器配置
        """
        self.config = config
    
    @abstractmethod
    async def process(self, data: pd.DataFrame) -> tuple[pd.DataFrame, PreprocessingResult]:
        """
        处理数据
        
        Args:
            data: 输入数据DataFrame
            
        Returns:
            tuple: (处理后的数据DataFrame, 处理结果)
        """
        pass
    
    @abstractmethod
    async def fit(self, data: pd.DataFrame) -> PreprocessingResult:
        """
        训练处理器（如果需要）
        
        Args:
            data: 训练数据DataFrame
            
        Returns:
            PreprocessingResult: 训练结果
        """
        pass
    
    @abstractmethod
    async def save_state(self, path: str) -> bool:
        """
        保存处理器状态
        
        Args:
            path: 保存路径
            
        Returns:
            bool: 保存是否成功
        """
        pass
    
    @abstractmethod
    async def load_state(self, path: str) -> bool:
        """
        加载处理器状态
        
        Args:
            path: 加载路径
            
        Returns:
            bool: 加载是否成功
        """
        pass
    
    @abstractmethod
    def get_metadata(self) -> Dict[str, Any]:
        """
        获取处理器元数据
        
        Returns:
            Dict[str, Any]: 处理器元数据
        """
        pass
