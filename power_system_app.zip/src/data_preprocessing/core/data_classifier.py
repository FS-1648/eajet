"""
数据归类器基类定义
"""
from abc import ABC, abstractmethod
from typing import Any, Dict, List, Optional, Union

import numpy as np
import pandas as pd
from pydantic import BaseModel


class ClassificationConfig(BaseModel):
    """归类配置基类"""
    classifier_id: str
    classifier_type: str
    name: str
    description: Optional[str] = None
    parameters: Dict[str, Any] = {}
    enabled: bool = True
    metadata: Optional[Dict[str, Any]] = None


class ClassificationResult(BaseModel):
    """归类结果基类"""
    classifier_id: str
    success: bool
    message: Optional[str] = None
    class_counts: Optional[Dict[str, int]] = None
    confidence_metrics: Optional[Dict[str, float]] = None
    metadata: Optional[Dict[str, Any]] = None


class DataClassifier(ABC):
    """数据归类器抽象基类"""
    
    def __init__(self, config: ClassificationConfig):
        """
        初始化数据归类器
        
        Args:
            config: 归类器配置
        """
        self.config = config
    
    @abstractmethod
    async def classify(self, data: pd.DataFrame) -> tuple[pd.DataFrame, ClassificationResult]:
        """
        对数据进行归类
        
        Args:
            data: 输入数据DataFrame
            
        Returns:
            tuple: (带有归类标签的数据DataFrame, 归类结果)
        """
        pass
    
    @abstractmethod
    async def train(self, data: pd.DataFrame, labels: Union[pd.Series, np.ndarray]) -> ClassificationResult:
        """
        训练归类器
        
        Args:
            data: 训练数据DataFrame
            labels: 训练数据标签
            
        Returns:
            ClassificationResult: 训练结果
        """
        pass
    
    @abstractmethod
    async def save_model(self, path: str) -> bool:
        """
        保存归类器模型
        
        Args:
            path: 保存路径
            
        Returns:
            bool: 保存是否成功
        """
        pass
    
    @abstractmethod
    async def load_model(self, path: str) -> bool:
        """
        加载归类器模型
        
        Args:
            path: 加载路径
            
        Returns:
            bool: 加载是否成功
        """
        pass
    
    @abstractmethod
    def get_model_info(self) -> Dict[str, Any]:
        """
        获取归类器模型信息
        
        Returns:
            Dict[str, Any]: 模型信息
        """
        pass
