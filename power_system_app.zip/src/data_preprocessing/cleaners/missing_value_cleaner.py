"""
缺失值清洗处理器
"""
import os
import json
from typing import Any, Dict, List, Optional, Union

import numpy as np
import pandas as pd
from loguru import logger
from sklearn.impute import SimpleImputer

from src.data_preprocessing.core.data_processor import DataProcessor, PreprocessingConfig, PreprocessingResult


class MissingValueCleaner(DataProcessor):
    """缺失值清洗处理器"""
    
    def __init__(self, config: PreprocessingConfig):
        """
        初始化缺失值清洗处理器
        
        Args:
            config: 处理器配置
        """
        super().__init__(config)
        self.imputers: Dict[str, SimpleImputer] = {}
        self.fitted_columns: List[str] = []
        self.strategy = config.parameters.get("strategy", "mean")
        self.fill_value = config.parameters.get("fill_value", None)
        self.numeric_columns = config.parameters.get("numeric_columns", [])
        self.categorical_columns = config.parameters.get("categorical_columns", [])
        self.max_missing_ratio = config.parameters.get("max_missing_ratio", 0.5)
        self.drop_columns = config.parameters.get("drop_columns", False)
    
    async def process(self, data: pd.DataFrame) -> tuple[pd.DataFrame, PreprocessingResult]:
        """
        处理数据中的缺失值
        
        Args:
            data: 输入数据DataFrame
            
        Returns:
            tuple: (处理后的数据DataFrame, 处理结果)
        """
        try:
            # 复制数据，避免修改原始数据
            processed_data = data.copy()
            
            # 计算每列的缺失值比例
            missing_ratios = processed_data.isna().mean()
            columns_to_drop = missing_ratios[missing_ratios > self.max_missing_ratio].index.tolist()
            
            # 如果配置为删除高缺失率的列
            if self.drop_columns and columns_to_drop:
                processed_data = processed_data.drop(columns=columns_to_drop)
                logger.info(f"Dropped {len(columns_to_drop)} columns with missing ratio > {self.max_missing_ratio}")
            
            # 处理数值型列
            numeric_columns = self.numeric_columns or processed_data.select_dtypes(include=np.number).columns.tolist()
            numeric_columns = [col for col in numeric_columns if col in processed_data.columns]
            
            if numeric_columns:
                if not self.imputers.get("numeric"):
                    # 如果没有训练过，创建并训练新的imputer
                    self.imputers["numeric"] = SimpleImputer(
                        strategy=self.strategy,
                        fill_value=self.fill_value if self.strategy == "constant" else None
                    )
                    self.imputers["numeric"].fit(processed_data[numeric_columns])
                    self.fitted_columns.extend(numeric_columns)
                
                # 填充缺失值
                processed_data[numeric_columns] = self.imputers["numeric"].transform(processed_data[numeric_columns])
            
            # 处理分类型列
            categorical_columns = self.categorical_columns or processed_data.select_dtypes(include=["object", "category"]).columns.tolist()
            categorical_columns = [col for col in categorical_columns if col in processed_data.columns]
            
            if categorical_columns:
                if not self.imputers.get("categorical"):
                    # 对分类型列使用众数填充
                    self.imputers["categorical"] = SimpleImputer(
                        strategy="most_frequent"
                    )
                    self.imputers["categorical"].fit(processed_data[categorical_columns])
                    self.fitted_columns.extend(categorical_columns)
                
                # 填充缺失值
                processed_data[categorical_columns] = self.imputers["categorical"].transform(processed_data[categorical_columns])
            
            # 计算处理统计信息
            initial_missing = data.isna().sum().sum()
            remaining_missing = processed_data.isna().sum().sum()
            
            result = PreprocessingResult(
                processor_id=self.config.processor_id,
                success=True,
                message="Successfully cleaned missing values",
                stats={
                    "initial_missing_count": int(initial_missing),
                    "remaining_missing_count": int(remaining_missing),
                    "cleaned_missing_count": int(initial_missing - remaining_missing),
                    "dropped_columns": columns_to_drop,
                    "processed_numeric_columns": numeric_columns,
                    "processed_categorical_columns": categorical_columns
                }
            )
            
            return processed_data, result
        
        except Exception as e:
            logger.error(f"Error cleaning missing values: {e}")
            return data, PreprocessingResult(
                processor_id=self.config.processor_id,
                success=False,
                message=f"Error cleaning missing values: {str(e)}"
            )
    
    async def fit(self, data: pd.DataFrame) -> PreprocessingResult:
        """
        训练缺失值填充器
        
        Args:
            data: 训练数据DataFrame
            
        Returns:
            PreprocessingResult: 训练结果
        """
        try:
            # 重置imputers
            self.imputers = {}
            self.fitted_columns = []
            
            # 处理数值型列
            numeric_columns = self.numeric_columns or data.select_dtypes(include=np.number).columns.tolist()
            if numeric_columns:
                self.imputers["numeric"] = SimpleImputer(
                    strategy=self.strategy,
                    fill_value=self.fill_value if self.strategy == "constant" else None
                )
                self.imputers["numeric"].fit(data[numeric_columns])
                self.fitted_columns.extend(numeric_columns)
            
            # 处理分类型列
            categorical_columns = self.categorical_columns or data.select_dtypes(include=["object", "category"]).columns.tolist()
            if categorical_columns:
                self.imputers["categorical"] = SimpleImputer(
                    strategy="most_frequent"
                )
                self.imputers["categorical"].fit(data[categorical_columns])
                self.fitted_columns.extend(categorical_columns)
            
            return PreprocessingResult(
                processor_id=self.config.processor_id,
                success=True,
                message="Successfully fitted missing value cleaner",
                stats={
                    "fitted_numeric_columns": numeric_columns,
                    "fitted_categorical_columns": categorical_columns,
                    "strategy": self.strategy
                }
            )
        
        except Exception as e:
            logger.error(f"Error fitting missing value cleaner: {e}")
            return PreprocessingResult(
                processor_id=self.config.processor_id,
                success=False,
                message=f"Error fitting missing value cleaner: {str(e)}"
            )
    
    async def save_state(self, path: str) -> bool:
        """
        保存处理器状态
        
        Args:
            path: 保存路径
            
        Returns:
            bool: 保存是否成功
        """
        try:
            os.makedirs(path, exist_ok=True)
            
            # 保存配置和元数据
            metadata = {
                "fitted_columns": self.fitted_columns,
                "strategy": self.strategy,
                "fill_value": self.fill_value,
                "numeric_columns": self.numeric_columns,
                "categorical_columns": self.categorical_columns,
                "max_missing_ratio": self.max_missing_ratio,
                "drop_columns": self.drop_columns
            }
            
            with open(os.path.join(path, "metadata.json"), "w") as f:
                json.dump(metadata, f, indent=2, default=str)
            
            # 保存imputer参数
            for imputer_type, imputer in self.imputers.items():
                imputer_data = {
                    "statistics_": imputer.statistics_.tolist() if hasattr(imputer, "statistics_") else None,
                    "strategy": imputer.strategy,
                    "fill_value": imputer.fill_value if hasattr(imputer, "fill_value") else None
                }
                
                with open(os.path.join(path, f"{imputer_type}_imputer.json"), "w") as f:
                    json.dump(imputer_data, f, indent=2, default=str)
            
            return True
        
        except Exception as e:
            logger.error(f"Error saving missing value cleaner state: {e}")
            return False
    
    async def load_state(self, path: str) -> bool:
        """
        加载处理器状态
        
        Args:
            path: 加载路径
            
        Returns:
            bool: 加载是否成功
        """
        try:
            # 加载配置和元数据
            with open(os.path.join(path, "metadata.json"), "r") as f:
                metadata = json.load(f)
            
            self.fitted_columns = metadata.get("fitted_columns", [])
            self.strategy = metadata.get("strategy", "mean")
            self.fill_value = metadata.get("fill_value")
            self.numeric_columns = metadata.get("numeric_columns", [])
            self.categorical_columns = metadata.get("categorical_columns", [])
            self.max_missing_ratio = metadata.get("max_missing_ratio", 0.5)
            self.drop_columns = metadata.get("drop_columns", False)
            
            # 加载imputer参数
            self.imputers = {}
            
            for imputer_type in ["numeric", "categorical"]:
                imputer_path = os.path.join(path, f"{imputer_type}_imputer.json")
                if os.path.exists(imputer_path):
                    with open(imputer_path, "r") as f:
                        imputer_data = json.load(f)
                    
                    imputer = SimpleImputer(
                        strategy=imputer_data.get("strategy", "mean"),
                        fill_value=imputer_data.get("fill_value")
                    )
                    
                    if imputer_data.get("statistics_") is not None:
                        imputer.statistics_ = np.array(imputer_data["statistics_"])
                        self.imputers[imputer_type] = imputer
            
            return True
        
        except Exception as e:
            logger.error(f"Error loading missing value cleaner state: {e}")
            return False
    
    def get_metadata(self) -> Dict[str, Any]:
        """
        获取处理器元数据
        
        Returns:
            Dict[str, Any]: 处理器元数据
        """
        return {
            "processor_type": "missing_value_cleaner",
            "strategy": self.strategy,
            "fitted_columns": self.fitted_columns,
            "numeric_columns": self.numeric_columns,
            "categorical_columns": self.categorical_columns,
            "max_missing_ratio": self.max_missing_ratio,
            "drop_columns": self.drop_columns
        }
