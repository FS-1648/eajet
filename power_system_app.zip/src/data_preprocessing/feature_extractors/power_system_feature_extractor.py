"""
电力系统特征提取处理器 - 从电力系统数据中提取关键特征
"""
import os
import json
from typing import Any, Dict, List, Optional, Union

import numpy as np
import pandas as pd
from loguru import logger
from scipy import stats, signal
from tsfresh.feature_extraction import feature_calculators

from src.data_preprocessing.core.data_processor import DataProcessor, PreprocessingConfig, PreprocessingResult


class PowerSystemFeatureExtractor(DataProcessor):
    """电力系统特征提取处理器"""
    
    def __init__(self, config: PreprocessingConfig):
        """
        初始化电力系统特征提取处理器
        
        Args:
            config: 处理器配置
        """
        super().__init__(config)
        
        # 获取配置参数
        self.time_column = config.parameters.get("time_column", "timestamp")
        self.device_id_column = config.parameters.get("device_id_column", "device_id")
        self.target_columns = config.parameters.get("target_columns", [])
        self.window_size = config.parameters.get("window_size", 24)  # 默认24小时窗口
        self.step_size = config.parameters.get("step_size", 1)  # 默认步长1小时
        self.feature_types = config.parameters.get("feature_types", [
            "basic_stats", "trend", "fft", "wavelet", "power_specific"
        ])
        self.drop_original = config.parameters.get("drop_original", False)
        self.feature_prefix = config.parameters.get("feature_prefix", "feat_")
        
        # 特征提取函数映射
        self.feature_extractors = {
            "basic_stats": self._extract_basic_stats,
            "trend": self._extract_trend_features,
            "fft": self._extract_fft_features,
            "wavelet": self._extract_wavelet_features,
            "power_specific": self._extract_power_specific_features
        }
    
    async def process(self, data: pd.DataFrame) -> tuple[pd.DataFrame, PreprocessingResult]:
        """
        从电力系统数据中提取特征
        
        Args:
            data: 输入数据DataFrame
            
        Returns:
            tuple: (处理后的数据DataFrame, 处理结果)
        """
        try:
            # 复制数据，避免修改原始数据
            processed_data = data.copy()
            
            # 确保时间列存在
            if self.time_column not in processed_data.columns:
                return data, PreprocessingResult(
                    processor_id=self.config.processor_id,
                    success=False,
                    message=f"Time column '{self.time_column}' not found in data"
                )
            
            # 确保时间列是datetime类型
            if not pd.api.types.is_datetime64_any_dtype(processed_data[self.time_column]):
                try:
                    processed_data[self.time_column] = pd.to_datetime(processed_data[self.time_column])
                except Exception as e:
                    return data, PreprocessingResult(
                        processor_id=self.config.processor_id,
                        success=False,
                        message=f"Failed to convert time column to datetime: {str(e)}"
                    )
            
            # 确定要处理的列
            if self.target_columns:
                columns_to_process = [col for col in self.target_columns if col in processed_data.columns]
            else:
                # 默认处理所有数值列，排除时间和ID列
                exclude_cols = [self.time_column, self.device_id_column]
                columns_to_process = [col for col in processed_data.select_dtypes(include=np.number).columns 
                                     if col not in exclude_cols]
            
            if not columns_to_process:
                return data, PreprocessingResult(
                    processor_id=self.config.processor_id,
                    success=False,
                    message="No columns to process for feature extraction"
                )
            
            # 按设备ID分组处理（如果存在）
            if self.device_id_column in processed_data.columns:
                device_groups = processed_data.groupby(self.device_id_column)
                result_dfs = []
                
                for device_id, device_data in device_groups:
                    # 按时间排序
                    device_data = device_data.sort_values(by=self.time_column)
                    
                    # 提取特征
                    device_features = self._extract_features_for_device(device_data, columns_to_process)
                    result_dfs.append(device_features)
                
                # 合并结果
                processed_data = pd.concat(result_dfs, ignore_index=False)
            else:
                # 按时间排序
                processed_data = processed_data.sort_values(by=self.time_column)
                
                # 提取特征
                processed_data = self._extract_features_for_device(processed_data, columns_to_process)
            
            # 如果配置为删除原始列
            if self.drop_original:
                processed_data = processed_data.drop(columns=columns_to_process)
            
            # 计算处理统计信息
            feature_columns = [col for col in processed_data.columns if col.startswith(self.feature_prefix)]
            
            result = PreprocessingResult(
                processor_id=self.config.processor_id,
                success=True,
                message="Successfully extracted features",
                stats={
                    "original_columns": columns_to_process,
                    "feature_columns": feature_columns,
                    "feature_count": len(feature_columns),
                    "feature_types": self.feature_types
                }
            )
            
            return processed_data, result
        
        except Exception as e:
            logger.error(f"Error extracting features: {e}")
            return data, PreprocessingResult(
                processor_id=self.config.processor_id,
                success=False,
                message=f"Error extracting features: {str(e)}"
            )
    
    def _extract_features_for_device(self, device_data: pd.DataFrame, columns_to_process: List[str]) -> pd.DataFrame:
        """
        为单个设备的数据提取特征
        
        Args:
            device_data: 设备数据
            columns_to_process: 要处理的列
            
        Returns:
            pd.DataFrame: 添加了特征的数据
        """
        result_data = device_data.copy()
        
        # 创建滑动窗口
        for i in range(0, len(device_data) - self.window_size + 1, self.step_size):
            window = device_data.iloc[i:i+self.window_size]
            
            # 窗口结束时间点
            end_time = window.iloc[-1][self.time_column]
            end_idx = device_data[device_data[self.time_column] == end_time].index[0]
            
            # 为每个目标列提取特征
            for col in columns_to_process:
                # 获取窗口内的列数据
                series = window[col].values
                
                # 应用每种特征提取方法
                for feature_type in self.feature_types:
                    if feature_type in self.feature_extractors:
                        features = self.feature_extractors[feature_type](series, col)
                        
                        # 将特征添加到结果数据中
                        for feat_name, feat_value in features.items():
                            result_data.loc[end_idx, feat_name] = feat_value
        
        return result_data
    
    def _extract_basic_stats(self, series: np.ndarray, col_name: str) -> Dict[str, float]:
        """
        提取基本统计特征
        
        Args:
            series: 时间序列数据
            col_name: 列名
            
        Returns:
            Dict[str, float]: 特征字典
        """
        features = {}
        
        # 过滤掉NaN值
        clean_series = series[~np.isnan(series)]
        
        if len(clean_series) == 0:
            return features
        
        # 基本统计量
        features[f"{self.feature_prefix}{col_name}_mean"] = np.mean(clean_series)
        features[f"{self.feature_prefix}{col_name}_std"] = np.std(clean_series)
        features[f"{self.feature_prefix}{col_name}_min"] = np.min(clean_series)
        features[f"{self.feature_prefix}{col_name}_max"] = np.max(clean_series)
        features[f"{self.feature_prefix}{col_name}_range"] = np.max(clean_series) - np.min(clean_series)
        features[f"{self.feature_prefix}{col_name}_median"] = np.median(clean_series)
        
        # 分位数
        features[f"{self.feature_prefix}{col_name}_q25"] = np.percentile(clean_series, 25)
        features[f"{self.feature_prefix}{col_name}_q75"] = np.percentile(clean_series, 75)
        features[f"{self.feature_prefix}{col_name}_iqr"] = features[f"{self.feature_prefix}{col_name}_q75"] - features[f"{self.feature_prefix}{col_name}_q25"]
        
        # 高阶统计量
        features[f"{self.feature_prefix}{col_name}_skew"] = stats.skew(clean_series)
        features[f"{self.feature_prefix}{col_name}_kurtosis"] = stats.kurtosis(clean_series)
        
        # 变异系数
        if features[f"{self.feature_prefix}{col_name}_mean"] != 0:
            features[f"{self.feature_prefix}{col_name}_cv"] = features[f"{self.feature_prefix}{col_name}_std"] / abs(features[f"{self.feature_prefix}{col_name}_mean"])
        else:
            features[f"{self.feature_prefix}{col_name}_cv"] = np.nan
        
        return features
    
    def _extract_trend_features(self, series: np.ndarray, col_name: str) -> Dict[str, float]:
        """
        提取趋势特征
        
        Args:
            series: 时间序列数据
            col_name: 列名
            
        Returns:
            Dict[str, float]: 特征字典
        """
        features = {}
        
        # 过滤掉NaN值
        clean_series = series[~np.isnan(series)]
        
        if len(clean_series) < 2:
            return features
        
        # 线性趋势
        x = np.arange(len(clean_series))
        slope, intercept, r_value, p_value, std_err = stats.linregress(x, clean_series)
        
        features[f"{self.feature_prefix}{col_name}_trend_slope"] = slope
        features[f"{self.feature_prefix}{col_name}_trend_intercept"] = intercept
        features[f"{self.feature_prefix}{col_name}_trend_r_value"] = r_value
        features[f"{self.feature_prefix}{col_name}_trend_p_value"] = p_value
        features[f"{self.feature_prefix}{col_name}_trend_std_err"] = std_err
        
        # 自相关特征
        if len(clean_series) > 10:
            acf = feature_calculators.autocorrelation(clean_series, 1)
            features[f"{self.feature_prefix}{col_name}_autocorrelation_1"] = acf
            
            if len(clean_series) > 20:
                acf = feature_calculators.autocorrelation(clean_series, 5)
                features[f"{self.feature_prefix}{col_name}_autocorrelation_5"] = acf
        
        # 变化率特征
        diff = np.diff(clean_series)
        if len(diff) > 0:
            features[f"{self.feature_prefix}{col_name}_diff_mean"] = np.mean(diff)
            features[f"{self.feature_prefix}{col_name}_diff_std"] = np.std(diff)
            features[f"{self.feature_prefix}{col_name}_diff_max"] = np.max(diff)
            features[f"{self.feature_prefix}{col_name}_diff_min"] = np.min(diff)
        
        return features
    
    def _extract_fft_features(self, series: np.ndarray, col_name: str) -> Dict[str, float]:
        """
        提取FFT频域特征
        
        Args:
            series: 时间序列数据
            col_name: 列名
            
        Returns:
            Dict[str, float]: 特征字典
        """
        features = {}
        
        # 过滤掉NaN值
        clean_series = series[~np.isnan(series)]
        
        if len(clean_series) < 4:
            return features
        
        # 应用FFT
        fft_values = np.abs(np.fft.rfft(clean_series))
        
        if len(fft_values) > 0:
            # 频域特征
            features[f"{self.feature_prefix}{col_name}_fft_max"] = np.max(fft_values)
            features[f"{self.feature_prefix}{col_name}_fft_mean"] = np.mean(fft_values)
            features[f"{self.feature_prefix}{col_name}_fft_std"] = np.std(fft_values)
            features[f"{self.feature_prefix}{col_name}_fft_sum"] = np.sum(fft_values)
            
            # 主频率特征
            if len(fft_values) > 1:
                dominant_freq_idx = np.argmax(fft_values[1:]) + 1  # 跳过直流分量
                features[f"{self.feature_prefix}{col_name}_fft_dominant_freq"] = dominant_freq_idx
                features[f"{self.feature_prefix}{col_name}_fft_dominant_amp"] = fft_values[dominant_freq_idx]
            
            # 频谱能量分布
            if len(fft_values) >= 3:
                # 低频能量占比
                low_freq_energy = np.sum(fft_values[:len(fft_values)//3])
                # 中频能量占比
                mid_freq_energy = np.sum(fft_values[len(fft_values)//3:2*len(fft_values)//3])
                # 高频能量占比
                high_freq_energy = np.sum(fft_values[2*len(fft_values)//3:])
                
                total_energy = low_freq_energy + mid_freq_energy + high_freq_energy
                
                if total_energy > 0:
                    features[f"{self.feature_prefix}{col_name}_fft_low_freq_ratio"] = low_freq_energy / total_energy
                    features[f"{self.feature_prefix}{col_name}_fft_mid_freq_ratio"] = mid_freq_energy / total_energy
                    features[f"{self.feature_prefix}{col_name}_fft_high_freq_ratio"] = high_freq_energy / total_energy
        
        return features
    
    def _extract_wavelet_features(self, series: np.ndarray, col_name: str) -> Dict[str, float]:
        """
        提取小波变换特征
        
        Args:
            series: 时间序列数据
            col_name: 列名
            
        Returns:
            Dict[str, float]: 特征字典
        """
        features = {}
        
        # 过滤掉NaN值
        clean_series = series[~np.isnan(series)]
        
        if len(clean_series) < 4:
            return features
        
        try:
            # 使用简单的小波变换（这里使用scipy的cwt作为示例）
            widths = np.arange(1, min(10, len(clean_series) // 2))
            cwtmatr = signal.cwt(clean_series, signal.ricker, widths)
            
            # 提取小波系数特征
            features[f"{self.feature_prefix}{col_name}_wavelet_mean"] = np.mean(cwtmatr)
            features[f"{self.feature_prefix}{col_name}_wavelet_std"] = np.std(cwtmatr)
            features[f"{self.feature_prefix}{col_name}_wavelet_max"] = np.max(cwtmatr)
            features[f"{self.feature_prefix}{col_name}_wavelet_min"] = np.min(cwtmatr)
            
            # 各尺度能量
            for i, width in enumerate(widths[:3]):  # 取前3个尺度
                if i < len(widths):
                    scale_energy = np.sum(cwtmatr[i, :] ** 2)
                    features[f"{self.feature_prefix}{col_name}_wavelet_scale_{width}_energy"] = scale_energy
        except Exception as e:
            logger.warning(f"Error extracting wavelet features: {e}")
        
        return features
    
    def _extract_power_specific_features(self, series: np.ndarray, col_name: str) -> Dict[str, float]:
        """
        提取电力系统特定特征
        
        Args:
            series: 时间序列数据
            col_name: 列名
            
        Returns:
            Dict[str, float]: 特征字典
        """
        features = {}
        
        # 过滤掉NaN值
        clean_series = series[~np.isnan(series)]
        
        if len(clean_series) == 0:
            return features
        
        # 电力系统特定特征
        
        # 1. 越限特征
        if "voltage" in col_name.lower():
            # 电压越限特征
            nominal_voltage = 220.0  # 假设标称电压为220V
            upper_limit = nominal_voltage * 1.1  # 上限为标称值的110%
            lower_limit = nominal_voltage * 0.9  # 下限为标称值的90%
            
            over_voltage_count = np.sum(clean_series > upper_limit)
            under_voltage_count = np.sum(clean_series < lower_limit)
            
            features[f"{self.feature_prefix}{col_name}_over_voltage_ratio"] = over_voltage_count / len(clean_series)
            features[f"{self.feature_prefix}{col_name}_under_voltage_ratio"] = under_voltage_count / len(clean_series)
            
            # 电压偏差
            features[f"{self.feature_prefix}{col_name}_voltage_deviation"] = np.mean(np.abs(clean_series - nominal_voltage) / nominal_voltage)
        
        elif "current" in col_name.lower():
            # 电流特征
            features[f"{self.feature_prefix}{col_name}_current_peak_factor"] = np.max(clean_series) / np.mean(clean_series) if np.mean(clean_series) > 0 else np.nan
            
            # 电流不平衡度（如果有三相电流）
            if "phase_a" in col_name.lower() or "phase_1" in col_name.lower():
                phase_num = "a" if "phase_a" in col_name.lower() else "1"
                other_phases = []
                
                # 尝试找到其他相的电流
                for phase in ["b", "c"] if "phase_a" in col_name.lower() else ["2", "3"]:
                    other_phase_name = col_name.replace(f"phase_{phase_num}", f"phase_{phase}")
                    if other_phase_name in self.target_columns:
                        other_phases.append(other_phase_name)
        
        elif "power" in col_name.lower():
            # 功率特征
            if "active" in col_name.lower() or "real" in col_name.lower():
                # 有功功率波动
                features[f"{self.feature_prefix}{col_name}_power_fluctuation"] = np.std(clean_series) / np.mean(clean_series) if np.mean(clean_series) != 0 else np.nan
                
                # 负载因子
                features[f"{self.feature_prefix}{col_name}_load_factor"] = np.mean(clean_series) / np.max(clean_series) if np.max(clean_series) > 0 else np.nan
            
            elif "reactive" in col_name.lower():
                # 无功功率特征
                features[f"{self.feature_prefix}{col_name}_reactive_ratio"] = np.mean(np.abs(clean_series)) / np.mean(np.abs(clean_series)) if np.mean(np.abs(clean_series)) > 0 else np.nan
        
        elif "temperature" in col_name.lower():
            # 温度特征
            if "oil" in col_name.lower() or "winding" in col_name.lower():
                # 变压器温度特征
                critical_temp = 90.0  # 假设临界温度为90℃
                over_temp_count = np.sum(clean_series > critical_temp)
                features[f"{self.feature_prefix}{col_name}_over_temp_ratio"] = over_temp_count / len(clean_series)
                
                # 温度上升率
                if len(clean_series) > 1:
                    temp_rise = np.diff(clean_series)
                    features[f"{self.feature_prefix}{col_name}_max_temp_rise"] = np.max(temp_rise) if len(temp_rise) > 0 else 0
                    features[f"{self.feature_prefix}{col_name}_mean_temp_rise"] = np.mean(temp_rise) if len(temp_rise) > 0 else 0
        
        elif "frequency" in col_name.lower():
            # 频率特征
            nominal_freq = 50.0  # 假设标称频率为50Hz
            freq_deviation = np.abs(clean_series - nominal_freq)
            features[f"{self.feature_prefix}{col_name}_freq_deviation_mean"] = np.mean(freq_deviation)
            features[f"{self.feature_prefix}{col_name}_freq_deviation_max"] = np.max(freq_deviation)
            
            # 频率越限
            freq_upper_limit = nominal_freq + 0.2  # 上限为标称值+0.2Hz
            freq_lower_limit = nominal_freq - 0.2  # 下限为标称值-0.2Hz
            
            over_freq_count = np.sum(clean_series > freq_upper_limit)
            under_freq_count = np.sum(clean_series < freq_lower_limit)
            
            features[f"{self.feature_prefix}{col_name}_over_freq_ratio"] = over_freq_count / len(clean_series)
            features[f"{self.feature_prefix}{col_name}_under_freq_ratio"] = under_freq_count / len(clean_series)
        
        # 2. 通用电力系统特征
        
        # 突变检测
        if len(clean_series) > 2:
            # 计算一阶差分
            diff = np.diff(clean_series)
            # 计算差分的标准差
            diff_std = np.std(diff)
            # 检测超过3倍标准差的突变
            if diff_std > 0:
                sudden_changes = np.abs(diff) > (3 * diff_std)
                features[f"{self.feature_prefix}{col_name}_sudden_change_count"] = np.sum(sudden_changes)
                features[f"{self.feature_prefix}{col_name}_sudden_change_ratio"] = np.sum(sudden_changes) / len(diff)
        
        # 稳定性指标
        features[f"{self.feature_prefix}{col_name}_stability_index"] = 1.0 - (np.std(clean_series) / (np.max(clean_series) - np.min(clean_series))) if (np.max(clean_series) - np.min(clean_series)) > 0 else 1.0
        
        return features
    
    async def fit(self, data: pd.DataFrame) -> PreprocessingResult:
        """
        训练特征提取器（对于此处理器，不需要训练）
        
        Args:
            data: 训练数据DataFrame
            
        Returns:
            PreprocessingResult: 训练结果
        """
        # 此处理器不需要训练，但我们可以验证配置和数据兼容性
        
        # 确保时间列存在
        if self.time_column not in data.columns:
            return PreprocessingResult(
                processor_id=self.config.processor_id,
                success=False,
                message=f"Time column '{self.time_column}' not found in data"
            )
        
        # 确定要处理的列
        if self.target_columns:
            columns_to_process = [col for col in self.target_columns if col in data.columns]
        else:
            # 默认处理所有数值列，排除时间和ID列
            exclude_cols = [self.time_column, self.device_id_column]
            columns_to_process = [col for col in data.select_dtypes(include=np.number).columns 
                                 if col not in exclude_cols]
        
        if not columns_to_process:
            return PreprocessingResult(
                processor_id=self.config.processor_id,
                success=False,
                message="No columns to process for feature extraction"
            )
        
        return PreprocessingResult(
            processor_id=self.config.processor_id,
            success=True,
            message="Feature extractor configuration validated",
            stats={
                "target_columns": columns_to_process,
                "feature_types": self.feature_types,
                "window_size": self.window_size,
                "step_size": self.step_size
            }
        )
    
    async def save_state(self, path: str) -> bool:
        """
        保存处理器状态
        
        Args:
            path: 保存路径
            
        Returns:
            bool: 保存是否成功
        """
        try:
            os.makedirs(path, exist_ok=True)
            
            # 保存配置和元数据
            metadata = {
                "time_column": self.time_column,
                "device_id_column": self.device_id_column,
                "target_columns": self.target_columns,
                "window_size": self.window_size,
                "step_size": self.step_size,
                "feature_types": self.feature_types,
                "drop_original": self.drop_original,
                "feature_prefix": self.feature_prefix
            }
            
            with open(os.path.join(path, "metadata.json"), "w") as f:
                json.dump(metadata, f, indent=2, default=str)
            
            return True
        
        except Exception as e:
            logger.error(f"Error saving feature extractor state: {e}")
            return False
    
    async def load_state(self, path: str) -> bool:
        """
        加载处理器状态
        
        Args:
            path: 加载路径
            
        Returns:
            bool: 加载是否成功
        """
        try:
            # 加载配置和元数据
            with open(os.path.join(path, "metadata.json"), "r") as f:
                metadata = json.load(f)
            
            self.time_column = metadata.get("time_column", "timestamp")
            self.device_id_column = metadata.get("device_id_column", "device_id")
            self.target_columns = metadata.get("target_columns", [])
            self.window_size = metadata.get("window_size", 24)
            self.step_size = metadata.get("step_size", 1)
            self.feature_types = metadata.get("feature_types", ["basic_stats", "trend", "fft", "wavelet", "power_specific"])
            self.drop_original = metadata.get("drop_original", False)
            self.feature_prefix = metadata.get("feature_prefix", "feat_")
            
            return True
        
        except Exception as e:
            logger.error(f"Error loading feature extractor state: {e}")
            return False
    
    def get_metadata(self) -> Dict[str, Any]:
        """
        获取处理器元数据
        
        Returns:
            Dict[str, Any]: 处理器元数据
        """
        return {
            "processor_type": "power_system_feature_extractor",
            "time_column": self.time_column,
            "device_id_column": self.device_id_column,
            "target_columns": self.target_columns,
            "window_size": self.window_size,
            "step_size": self.step_size,
            "feature_types": self.feature_types,
            "drop_original": self.drop_original,
            "feature_prefix": self.feature_prefix
        }
