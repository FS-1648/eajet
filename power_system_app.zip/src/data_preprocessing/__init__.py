"""
数据预处理与归类模块初始化文件
"""
from importlib.metadata import version, PackageNotFoundError

try:
    __version__ = version("power_system_fault_prediction")
except PackageNotFoundError:
    __version__ = "0.1.0-dev"

from src.data_preprocessing.api.preprocessing import PreprocessingAPI
from src.data_preprocessing.core.preprocessing_pipeline import PreprocessingPipeline
from src.data_preprocessing.core.data_classifier import DataClassifier

__all__ = ["PreprocessingAPI", "PreprocessingPipeline", "DataClassifier"]
