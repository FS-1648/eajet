"""
机器学习归类器 - 使用机器学习算法对电力系统数据进行自动归类
"""
import os
import json
import pickle
from typing import Any, Dict, List, Optional, Union, Tuple

import numpy as np
import pandas as pd
from loguru import logger
from sklearn.ensemble import RandomForestClassifier
from sklearn.svm import SVC
from sklearn.neighbors import KNeighborsClassifier
from sklearn.metrics import classification_report, confusion_matrix
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder

from src.data_preprocessing.core.data_classifier import DataClassifier, ClassificationConfig, ClassificationResult


class MLClassifier(DataClassifier):
    """机器学习归类器"""
    
    def __init__(self, config: ClassificationConfig):
        """
        初始化机器学习归类器
        
        Args:
            config: 归类器配置
        """
        super().__init__(config)
        
        # 获取配置参数
        self.algorithm = config.parameters.get("algorithm", "random_forest")
        self.feature_columns = config.parameters.get("feature_columns", [])
        self.target_column = config.parameters.get("target_column", "class")
        self.output_column = config.parameters.get("output_column", "predicted_class")
        self.probability_column_prefix = config.parameters.get("probability_column_prefix", "prob_")
        self.test_size = config.parameters.get("test_size", 0.2)
        self.random_state = config.parameters.get("random_state", 42)
        
        # 模型参数
        self.model_params = config.parameters.get("model_params", {})
        
        # 初始化模型和编码器
        self.model = None
        self.label_encoder = LabelEncoder()
        self.classes = None
        self.feature_importances = None
    
    async def classify(self, data: pd.DataFrame) -> tuple[pd.DataFrame, ClassificationResult]:
        """
        对数据进行归类
        
        Args:
            data: 输入数据DataFrame
            
        Returns:
            tuple: (带有归类标签的数据DataFrame, 归类结果)
        """
        try:
            # 复制数据，避免修改原始数据
            result_data = data.copy()
            
            # 检查模型是否已训练
            if self.model is None:
                return data, ClassificationResult(
                    classifier_id=self.config.classifier_id,
                    success=False,
                    message="Model not trained yet"
                )
            
            # 确定要使用的特征列
            if self.feature_columns:
                feature_cols = [col for col in self.feature_columns if col in result_data.columns]
            else:
                # 默认使用所有数值列，排除目标列和输出列
                exclude_cols = [self.target_column, self.output_column]
                feature_cols = [col for col in result_data.select_dtypes(include=np.number).columns 
                               if col not in exclude_cols]
            
            if not feature_cols:
                return data, ClassificationResult(
                    classifier_id=self.config.classifier_id,
                    success=False,
                    message="No feature columns found in data"
                )
            
            # 提取特征
            X = result_data[feature_cols].values
            
            # 预测类别
            y_pred = self.model.predict(X)
            
            # 将编码后的类别转换回原始标签
            if hasattr(self.label_encoder, 'classes_'):
                y_pred_labels = self.label_encoder.inverse_transform(y_pred)
            else:
                y_pred_labels = y_pred
            
            # 添加预测结果到数据
            result_data[self.output_column] = y_pred_labels
            
            # 如果模型支持概率预测，添加概率列
            if hasattr(self.model, 'predict_proba'):
                y_proba = self.model.predict_proba(X)
                
                for i, class_name in enumerate(self.classes):
                    prob_col = f"{self.probability_column_prefix}{class_name}"
                    result_data[prob_col] = y_proba[:, i]
            
            # 计算类别统计
            class_counts = {}
            for class_name in np.unique(y_pred_labels):
                class_counts[str(class_name)] = int(np.sum(y_pred_labels == class_name))
            
            # 创建结果
            result = ClassificationResult(
                classifier_id=self.config.classifier_id,
                success=True,
                message="Successfully classified data",
                class_counts=class_counts,
                metadata={
                    "feature_columns": feature_cols,
                    "algorithm": self.algorithm,
                    "classes": self.classes.tolist() if self.classes is not None else None
                }
            )
            
            return result_data, result
        
        except Exception as e:
            logger.error(f"Error classifying data: {e}")
            return data, ClassificationResult(
                classifier_id=self.config.classifier_id,
                success=False,
                message=f"Error classifying data: {str(e)}"
            )
    
    async def train(self, data: pd.DataFrame, labels: Union[pd.Series, np.ndarray]) -> ClassificationResult:
        """
        训练归类器
        
        Args:
            data: 训练数据DataFrame
            labels: 训练数据标签
            
        Returns:
            ClassificationResult: 训练结果
        """
        try:
            # 确定要使用的特征列
            if self.feature_columns:
                feature_cols = [col for col in self.feature_columns if col in data.columns]
            else:
                # 默认使用所有数值列，排除目标列和输出列
                exclude_cols = [self.target_column, self.output_column]
                feature_cols = [col for col in data.select_dtypes(include=np.number).columns 
                               if col not in exclude_cols]
            
            if not feature_cols:
                return ClassificationResult(
                    classifier_id=self.config.classifier_id,
                    success=False,
                    message="No feature columns found in data"
                )
            
            # 提取特征
            X = data[feature_cols].values
            
            # 处理标签
            if isinstance(labels, pd.Series):
                y = labels.values
            else:
                y = labels
            
            # 编码标签
            y_encoded = self.label_encoder.fit_transform(y)
            self.classes = self.label_encoder.classes_
            
            # 划分训练集和测试集
            X_train, X_test, y_train, y_test = train_test_split(
                X, y_encoded, test_size=self.test_size, random_state=self.random_state
            )
            
            # 创建并训练模型
            self.model = self._create_model()
            self.model.fit(X_train, y_train)
            
            # 评估模型
            y_pred = self.model.predict(X_test)
            
            # 计算评估指标
            accuracy = np.mean(y_pred == y_test)
            
            # 保存特征重要性（如果模型支持）
            if hasattr(self.model, 'feature_importances_'):
                self.feature_importances = dict(zip(feature_cols, self.model.feature_importances_))
            
            # 计算类别统计
            class_counts = {}
            for i, class_name in enumerate(self.classes):
                class_counts[str(class_name)] = int(np.sum(y == class_name))
            
            # 创建结果
            result = ClassificationResult(
                classifier_id=self.config.classifier_id,
                success=True,
                message="Successfully trained classifier",
                class_counts=class_counts,
                confidence_metrics={
                    "accuracy": float(accuracy),
                    "feature_count": len(feature_cols)
                },
                metadata={
                    "feature_columns": feature_cols,
                    "algorithm": self.algorithm,
                    "classes": self.classes.tolist(),
                    "feature_importances": self.feature_importances
                }
            )
            
            return result
        
        except Exception as e:
            logger.error(f"Error training classifier: {e}")
            return ClassificationResult(
                classifier_id=self.config.classifier_id,
                success=False,
                message=f"Error training classifier: {str(e)}"
            )
    
    def _create_model(self) -> Any:
        """
        创建指定算法的模型
        
        Returns:
            Any: 模型实例
        """
        if self.algorithm == "random_forest":
            return RandomForestClassifier(
                n_estimators=self.model_params.get("n_estimators", 100),
                max_depth=self.model_params.get("max_depth", None),
                min_samples_split=self.model_params.get("min_samples_split", 2),
                random_state=self.random_state
            )
        elif self.algorithm == "svm":
            return SVC(
                C=self.model_params.get("C", 1.0),
                kernel=self.model_params.get("kernel", "rbf"),
                probability=True,
                random_state=self.random_state
            )
        elif self.algorithm == "knn":
            return KNeighborsClassifier(
                n_neighbors=self.model_params.get("n_neighbors", 5),
                weights=self.model_params.get("weights", "uniform")
            )
        else:
            raise ValueError(f"Unknown algorithm: {self.algorithm}")
    
    async def save_model(self, path: str) -> bool:
        """
        保存归类器模型
        
        Args:
            path: 保存路径
            
        Returns:
            bool: 保存是否成功
        """
        try:
            os.makedirs(path, exist_ok=True)
            
            # 保存配置和元数据
            metadata = {
                "algorithm": self.algorithm,
                "feature_columns": self.feature_columns,
                "target_column": self.target_column,
                "output_column": self.output_column,
                "probability_column_prefix": self.probability_column_prefix,
                "test_size": self.test_size,
                "random_state": self.random_state,
                "model_params": self.model_params,
                "classes": self.classes.tolist() if self.classes is not None else None,
                "feature_importances": self.feature_importances
            }
            
            with open(os.path.join(path, "metadata.json"), "w") as f:
                json.dump(metadata, f, indent=2, default=str)
            
            # 保存模型
            if self.model is not None:
                with open(os.path.join(path, "model.pkl"), "wb") as f:
                    pickle.dump(self.model, f)
            
            # 保存标签编码器
            if hasattr(self.label_encoder, 'classes_'):
                with open(os.path.join(path, "label_encoder.pkl"), "wb") as f:
                    pickle.dump(self.label_encoder, f)
            
            return True
        
        except Exception as e:
            logger.error(f"Error saving classifier model: {e}")
            return False
    
    async def load_model(self, path: str) -> bool:
        """
        加载归类器模型
        
        Args:
            path: 加载路径
            
        Returns:
            bool: 加载是否成功
        """
        try:
            # 加载配置和元数据
            with open(os.path.join(path, "metadata.json"), "r") as f:
                metadata = json.load(f)
            
            self.algorithm = metadata.get("algorithm", "random_forest")
            self.feature_columns = metadata.get("feature_columns", [])
            self.target_column = metadata.get("target_column", "class")
            self.output_column = metadata.get("output_column", "predicted_class")
            self.probability_column_prefix = metadata.get("probability_column_prefix", "prob_")
            self.test_size = metadata.get("test_size", 0.2)
            self.random_state = metadata.get("random_state", 42)
            self.model_params = metadata.get("model_params", {})
            
            if metadata.get("classes") is not None:
                self.classes = np.array(metadata["classes"])
            
            self.feature_importances = metadata.get("feature_importances")
            
            # 加载模型
            model_path = os.path.join(path, "model.pkl")
            if os.path.exists(model_path):
                with open(model_path, "rb") as f:
                    self.model = pickle.load(f)
            
            # 加载标签编码器
            encoder_path = os.path.join(path, "label_encoder.pkl")
            if os.path.exists(encoder_path):
                with open(encoder_path, "rb") as f:
                    self.label_encoder = pickle.load(f)
            
            return True
        
        except Exception as e:
            logger.error(f"Error loading classifier model: {e}")
            return False
    
    def get_model_info(self) -> Dict[str, Any]:
        """
        获取归类器模型信息
        
        Returns:
            Dict[str, Any]: 模型信息
        """
        return {
            "classifier_type": "ml_classifier",
            "algorithm": self.algorithm,
            "feature_columns": self.feature_columns,
            "target_column": self.target_column,
            "output_column": self.output_column,
            "classes": self.classes.tolist() if self.classes is not None else None,
            "feature_importances": self.feature_importances,
            "is_trained": self.model is not None
        }
