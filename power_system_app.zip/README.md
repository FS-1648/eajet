# 电力系统故障预测应用程序

[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)
[![Python 3.8+](https://img.shields.io/badge/python-3.8+-blue.svg)](https://www.python.org/downloads/)
[![FastAPI](https://img.shields.io/badge/FastAPI-0.95.0-green.svg)](https://fastapi.tiangolo.com/)

## 项目概述

电力系统故障预测应用程序是一个基于多源数据分析的智能电力系统故障预测平台。该应用程序通过读取不同地区多年以内的设备数据，结合电气参数、设备状态、环境因素和故障记录，计算不同数据对于故障次数和故障问题所占的影响概率，并预测未来每天的可能故障概率和故障问题。

### 核心功能

- **多源数据采集与接入**：支持从SCADA系统、PMU、智能传感器、气象站API等多种数据源采集数据
- **数据预处理与归类**：对原始数据进行清洗、标准化、特征提取和归类
- **故障影响概率分析**：计算不同因素对故障的影响概率
- **设备老化曲线建模**：基于历史数据建立设备健康状态模型和老化曲线
- **每日故障概率预测**：结合实时数据和老化曲线预测未来故障概率
- **模型训练与自动归类**：支持自动化模型训练和数据归类，用于持续学习和优化

## 系统架构

![系统架构图](docs/images/system_architecture.png)

系统采用模块化、微服务架构设计，主要包括以下几个核心模块：

1. **数据采集与接入模块**：负责从各种数据源采集数据，支持实时和批量数据接入
2. **数据预处理与归类模块**：负责数据清洗、标准化、特征提取和归类
3. **故障影响概率分析与建模模块**：负责分析各因素对故障的影响概率
4. **设备老化曲线与故障预测模块**：负责建立设备老化曲线和预测故障概率
5. **模型训练与自动归类模块**：负责模型的自动训练和数据归类
6. **API服务与前端界面**：提供统一的API接口和用户界面

## 技术栈

- **后端**：Python 3.8+, FastAPI, Pandas, NumPy, Scikit-learn, PyTorch
- **数据库**：SQLite (开发环境), PostgreSQL (生产环境)
- **前端**：Vue.js, Element UI, ECharts
- **部署**：Docker, Docker Compose

## 快速开始

### 环境要求

- Python 3.8+
- pip
- Git

### 安装步骤

1. 克隆仓库

```bash
git clone https://github.com/yourusername/power-system-fault-prediction.git
cd power-system-fault-prediction
```

2. 创建虚拟环境

```bash
python -m venv venv
source venv/bin/activate  # Linux/Mac
# 或
venv\Scripts\activate  # Windows
```

3. 安装依赖

```bash
pip install -r requirements.txt
```

4. 初始化配置

```bash
python scripts/init_config.py
```

5. 启动应用

```bash
python src/main.py
```

应用将在 http://localhost:8000 启动，API文档可在 http://localhost:8000/docs 查看。

### 使用Docker

1. 构建Docker镜像

```bash
docker build -t power-system-fault-prediction .
```

2. 运行Docker容器

```bash
docker run -d -p 8000:8000 --name power-system-app power-system-fault-prediction
```

## 使用指南

### 数据源配置

1. 访问 http://localhost:8000/docs
2. 使用 `/api/data_sources` 接口添加数据源
3. 配置数据源参数，包括类型、连接信息等

### 数据处理与分析

1. 使用 `/api/preprocessing/process` 接口处理数据
2. 使用 `/api/probability/calculate` 接口计算故障概率
3. 使用 `/api/aging/predict` 接口预测设备老化和故障概率

### 模型训练

1. 使用 `/api/training/train` 接口训练模型
2. 使用 `/api/training/evaluate` 接口评估模型性能

## 项目结构

```
power-system-fault-prediction/
├── docs/                      # 文档
│   ├── images/                # 文档图片
│   └── api/                   # API文档
├── scripts/                   # 脚本文件
│   ├── init_config.py         # 初始化配置脚本
│   └── setup_db.py            # 数据库设置脚本
├── src/                       # 源代码
│   ├── data_acquisition/      # 数据采集与接入模块
│   ├── data_preprocessing/    # 数据预处理与归类模块
│   ├── fault_probability/     # 故障影响概率分析与建模模块
│   ├── aging_prediction/      # 设备老化曲线与故障预测模块
│   ├── model_training/        # 模型训练与自动归类模块
│   ├── api/                   # API接口
│   ├── utils/                 # 工具函数
│   └── main.py                # 主程序入口
├── tests/                     # 测试代码
│   ├── unit/                  # 单元测试
│   └── integration/           # 集成测试
├── .gitignore                 # Git忽略文件
├── Dockerfile                 # Docker配置文件
├── docker-compose.yml         # Docker Compose配置文件
├── LICENSE                    # 许可证文件
├── README.md                  # 项目说明文件
└── requirements.txt           # 项目依赖文件
```

## 开发指南

### 添加新的数据源

1. 在 `src/data_acquisition/connectors/` 目录下创建新的连接器类
2. 继承 `DataSource` 基类并实现必要的方法
3. 在 `src/data_acquisition/core/data_source_manager.py` 中注册新的数据源类型

### 添加新的预处理器

1. 在 `src/data_preprocessing/` 目录下创建新的预处理器类
2. 继承 `DataProcessor` 基类并实现必要的方法
3. 在 `src/data_preprocessing/core/preprocessing_pipeline.py` 中注册新的预处理器类型

### 添加新的模型

1. 在相应模块目录下创建新的模型类
2. 继承对应的基类并实现必要的方法
3. 在主程序中注册新的模型类型

## 贡献指南

1. Fork 项目
2. 创建特性分支 (`git checkout -b feature/amazing-feature`)
3. 提交更改 (`git commit -m 'Add some amazing feature'`)
4. 推送到分支 (`git push origin feature/amazing-feature`)
5. 创建 Pull Request

## 许可证

本项目采用 MIT 许可证 - 详情请参阅 [LICENSE](LICENSE) 文件

## 联系方式

项目维护者 - [your-email@example.com](mailto:your-email@example.com)

项目链接: [https://github.com/yourusername/power-system-fault-prediction](https://github.com/yourusername/power-system-fault-prediction)
