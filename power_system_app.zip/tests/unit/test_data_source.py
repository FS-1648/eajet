"""
基本单元测试示例 - 数据源模块
"""
import pytest
import asyncio
from datetime import datetime, timedelta

from src.data_acquisition.core.data_source import DataSourceConfig, DataPoint


# 模拟数据源配置
@pytest.fixture
def sample_config():
    return DataSourceConfig(
        source_id="test_source",
        source_type="test",
        name="测试数据源",
        description="用于单元测试的数据源",
        connection_params={
            "test_param": "test_value"
        },
        enabled=True
    )


# 模拟数据点
@pytest.fixture
def sample_data_points():
    now = datetime.now()
    return [
        DataPoint(
            source_id="test_source",
            device_id="device_001",
            timestamp=now - timedelta(hours=i),
            values={
                "voltage_a": 220.0 + i,
                "current_a": 10.0 - i * 0.1,
                "power_factor": 0.95
            },
            metadata={
                "location": "测试站点",
                "status": "normal"
            }
        )
        for i in range(5)
    ]


# 测试数据源配置
def test_data_source_config(sample_config):
    assert sample_config.source_id == "test_source"
    assert sample_config.source_type == "test"
    assert sample_config.name == "测试数据源"
    assert sample_config.enabled is True
    assert "test_param" in sample_config.connection_params


# 测试数据点
def test_data_point(sample_data_points):
    data_point = sample_data_points[0]
    assert data_point.source_id == "test_source"
    assert data_point.device_id == "device_001"
    assert isinstance(data_point.timestamp, datetime)
    assert "voltage_a" in data_point.values
    assert data_point.values["voltage_a"] == 220.0
    assert "location" in data_point.metadata
    assert data_point.metadata["location"] == "测试站点"
