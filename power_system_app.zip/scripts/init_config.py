#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
初始化配置脚本
用于初始化电力系统故障预测应用程序的配置
"""

import os
import json
import argparse
from datetime import datetime

# 默认配置
DEFAULT_CONFIG = {
    "data_sources": {
        "scada_source": {
            "source_id": "scada_source",
            "source_type": "scada",
            "name": "变电站SCADA系统",
            "description": "采集三相电压/电流、有功/无功功率、功率因数、零序电流、母线频率等数据",
            "connection_params": {
                "host": "localhost",
                "port": 502,
                "protocol": "modbus",
                "timeout": 10
            },
            "enabled": True
        },
        "sensor_source": {
            "source_id": "sensor_source",
            "source_type": "sensor",
            "name": "智能传感器系统",
            "description": "采集变压器油温、绕组温度、油色谱、断路器分合闸次数、SF₆压力等数据",
            "connection_params": {
                "api_url": "http://localhost:8080/api/sensors",
                "api_key": "demo_key",
                "polling_interval": 60
            },
            "enabled": True
        },
        "weather_source": {
            "source_id": "weather_source",
            "source_type": "weather",
            "name": "气象站系统",
            "description": "采集风速、湿度、温度、光照强度、雷暴预警信号等数据",
            "connection_params": {
                "api_url": "http://localhost:8081/api/weather",
                "api_key": "demo_key",
                "location": "default",
                "update_interval": 3600
            },
            "enabled": True
        },
        "fault_record_source": {
            "source_id": "fault_record_source",
            "source_type": "fault_record",
            "name": "故障记录系统",
            "description": "采集跳闸时间、故障类型、动作保护装置编号等数据",
            "connection_params": {
                "db_type": "sqlite",
                "db_path": "data/fault_records.db",
                "table_name": "fault_records"
            },
            "enabled": True
        }
    },
    "preprocessing": {
        "pipeline_config": {
            "processors": [
                {
                    "processor_id": "missing_value_cleaner",
                    "processor_type": "missing_value_cleaner",
                    "name": "缺失值清洗处理器",
                    "parameters": {
                        "strategy": "mean",
                        "threshold": 0.3
                    },
                    "enabled": True
                },
                {
                    "processor_id": "data_normalizer",
                    "processor_type": "data_normalizer",
                    "name": "数据标准化处理器",
                    "parameters": {
                        "method": "z-score",
                        "columns": []
                    },
                    "enabled": True
                },
                {
                    "processor_id": "power_system_feature_extractor",
                    "processor_type": "power_system_feature_extractor",
                    "name": "电力系统特征提取处理器",
                    "parameters": {
                        "window_size": 24,
                        "extract_trend": True,
                        "extract_seasonality": True,
                        "extract_statistics": True
                    },
                    "enabled": True
                }
            ]
        }
    },
    "probability_models": {
        "multi_factor_model": {
            "model_id": "multi_factor_model",
            "model_type": "multi_factor",
            "name": "多因子故障概率模型",
            "description": "基于多种因子计算故障概率的模型",
            "parameters": {
                "factor_weights": {
                    "electrical": 0.35,
                    "equipment": 0.25,
                    "environmental": 0.20,
                    "operational": 0.20
                },
                "threshold": 0.7,
                "use_historical_data": True
            },
            "enabled": True
        }
    },
    "aging_models": {
        "health_index_model": {
            "model_id": "health_index_model",
            "model_type": "health_index",
            "name": "健康指数老化曲线模型",
            "description": "基于设备健康指数的老化曲线模型",
            "parameters": {
                "curve_type": "weibull",
                "time_column": "timestamp",
                "feature_columns": [],
                "failure_threshold": 0.3,
                "warning_threshold": 0.6
            },
            "enabled": True
        }
    },
    "training": {
        "universal_trainer": {
            "trainer_id": "universal_trainer",
            "trainer_type": "universal",
            "name": "通用模型训练器",
            "description": "支持多种模型类型的训练和管理",
            "parameters": {
                "auto_tune": True,
                "cv_folds": 5,
                "feature_selection": True,
                "max_features": 20
            },
            "enabled": True
        }
    },
    "system": {
        "data_dir": "data",
        "model_dir": "models",
        "log_level": "INFO",
        "api_port": 8000,
        "debug_mode": False,
        "version": "1.0.0",
        "last_update": datetime.now().isoformat()
    }
}

def init_config(config_dir, force=False):
    """
    初始化配置
    
    Args:
        config_dir: 配置目录
        force: 是否强制覆盖现有配置
    """
    # 确保配置目录存在
    os.makedirs(config_dir, exist_ok=True)
    
    # 配置文件路径
    config_path = os.path.join(config_dir, "app_config.json")
    
    # 检查配置文件是否存在
    if os.path.exists(config_path) and not force:
        print(f"配置文件已存在: {config_path}")
        print("使用 --force 参数强制覆盖现有配置")
        return False
    
    # 写入配置文件
    with open(config_path, "w", encoding="utf-8") as f:
        json.dump(DEFAULT_CONFIG, f, indent=2, ensure_ascii=False)
    
    print(f"成功初始化配置: {config_path}")
    return True

def main():
    """主函数"""
    parser = argparse.ArgumentParser(description="初始化电力系统故障预测应用程序的配置")
    parser.add_argument("--config-dir", default="config", help="配置目录")
    parser.add_argument("--force", action="store_true", help="强制覆盖现有配置")
    
    args = parser.parse_args()
    
    # 初始化配置
    init_config(args.config_dir, args.force)

if __name__ == "__main__":
    main()
